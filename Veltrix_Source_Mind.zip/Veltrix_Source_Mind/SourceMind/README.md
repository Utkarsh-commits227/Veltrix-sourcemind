# 🧠 VELTRIX SourceMind

> **High-Assurance, Source-Grounded Generative AI Research & Study Studio**  
> *Inspired by Google NotebookLM — Engineered for Zero-Hallucination Academic & Enterprise Rigor.*

[![Python Version](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-88%2F88%20passed-brightgreen.svg)](tests/)
[![Architecture](https://img.shields.io/badge/architecture-Source--Grounded%20RAG-orange.svg)](ARCHITECTURE.md)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](Dockerfile)

---

## 📑 Table of Contents
1. [Overview & Philosophy](#-overview--philosophy)
2. [Key Capabilities & Subsystems](#-key-capabilities--subsystems)
3. [System Architecture Diagram](#-system-architecture-diagram)
4. [Quantitative Evaluation Benchmark](#-quantitative-evaluation-benchmark)
5. [Quickstart Guide](#-quickstart-guide)
   - [Prerequisites](#prerequisites)
   - [Local Development Setup](#local-development-setup)
   - [Docker Deployment](#docker-deployment)
6. [API & Studio Features](#-api--studio-features)
7. [Security & Anti-Hallucination Guardrails](#-security--anti-hallucination-guardrails)
8. [Project Structure](#-project-structure)
9. [Running Automated Tests](#-running-automated-tests)
10. [Documentation Sitemap](#-documentation-sitemap)

---

## 🎯 Overview & Philosophy

Modern Large Language Models (LLMs) suffer from two critical flaws when applied to technical, legal, and academic domains:
1. **Hallucination & Fabrication**: Models invent facts, synthesize plausible falsehoods, and fabricate references with convincing confidence.
2. **Context Leakage & Prompt Injection**: Untrusted user documents can hijack LLM reasoning through adversarial prompt breakouts.

**VELTRIX SourceMind** solves this by establishing a **Zero-Tolerance Hallucination Architecture**. Inspired by Google NotebookLM, SourceMind treats uploaded source documents as the sole source of ground truth:
- **Strict Grounding Enforcement**: The system strictly refuses to answer questions not present in the ingested sources.
- **Verifiable In-Text Citations**: Every factual statement is backed by bracketed citations `[Doc: page N]` verified algorithmically against source chunks.
- **Bi-Directional Context Enveloping**: Document content is quarantined in structured XML boundaries with indirect injection neutralization.
- **Full Study Suite**: Automatically generates executive summaries, smart structured notes, revision sheets, and interactive practice tests.

---

## 🚀 Key Capabilities & Subsystems

| Subsystem | Capabilities | Technology Stack |
| :--- | :--- | :--- |
| **Ingestion Engine** | Magic byte validation, path traversal prevention, PDF/TXT/MD parsing with per-page tracking and scanned blank detection. | `pypdf`, `hashlib`, Python standard library |
| **Chunking Engine** | Recursive semantic chunker preserving paragraph integrity, token overlap, and page-level metadata. | Custom recursive chunker with token budgeting |
| **Embedding Engine** | Deterministic semantic embeddings with caching layer and rate-limit backoff. | Google `text-embedding-004`, `google-genai` |
| **Vector Store** | In-memory and persistent vector index with cosine similarity filtering ($\ge 65\%$) and document-level isolation. | `ChromaDB` (HNSW SQLite backend) |
| **Grounded Chat** | Sub-second Time-To-First-Token (TTFT) streaming chat with Server-Sent Events (SSE) and honest refusal triggers. | `FastAPI`, `gemini-2.0-flash`, SSE protocol |
| **Study Suite** | Multi-length summary synthesis (Short, Medium, Detailed), smart key-concept notes, and high-yield revision sheets. | Structured Pydantic models, JSON generation |
| **Quiz & Test Engine** | Multiple-choice questions (MCQs), concept explanations, automated grading, and instant performance feedback. | Interactive Quiz Engine, score analytics |
| **Citation Verifier** | Post-generation guardrail auditing bracketed citations against ground truth chunks using fuzzy n-gram matching. | Multi-tier citation verifier |
| **Security & Telemetry** | Delimiter neutralization, jailbreak mitigation, sliding-window rate limiting, request tracing (`X-Request-ID`). | Custom middleware, thread-safe rate limiter |
| **Studio UI** | Dark-mode research workbench with live chat, source inspector, study tabs, and interactive quiz taking. | Semantic HTML5, Vanilla JavaScript, CSS variables |

---

## 🏗️ System Architecture Diagram

```mermaid
flowchart TD
    User["👤 Researcher / Student"] -->|"1. Uploads PDF/TXT/MD"| Ingestion["📥 Ingestion Engine\n(Magic Bytes & Path Sanitization)"]
    Ingestion -->|"2. Extracted Pages"| Chunker["✂️ Recursive Semantic Chunker\n(Chunking with Page Attribution)"]
    Chunker -->|"3. Clean Chunks"| Embedder["🧮 Embedding Service\n(Google text-embedding-004 + Cache)"]
    Embedder -->|"4. Vectors + Metadata"| VectorStore[("🗄️ ChromaDB Vector Vault\n(Cosine Similarity >= 0.65)")]

    User -->|"5. Submits Query"| Middleware["🛡️ Security & Tracing Middleware\n(Rate Limiter + X-Request-ID)"]
    Middleware -->|"6. Filtered Query"| Retriever["🔍 Semantic Retriever\n(Top-K Similarity Search)"]
    VectorStore -->|"7. Matched Chunks"| Retriever
    Retriever -->|"8. XML Enveloped Context"| ContextAssembler["📦 Context Assembler\n(Tag Escaping & Token Budgeting)"]
    ContextAssembler -->|"9. Grounded Prompt"| LLM["⚡ Gemini 2.0 Flash\n(Ground Truth Adherence)"]
    
    LLM -->|"10. Raw Generated Stream"| CitationVerifier["🔬 Citation Verifier Guardrail\n(Page & Substring Verification)"]
    CitationVerifier -->|"11. Verified Response + Citations"| StudioUI["🖥️ Modern Frontend Studio UI\n(SSE Stream, Notes, Quizzes)"]
```

---

## 📊 Quantitative Evaluation Benchmark

SourceMind features a 20-question golden evaluation benchmark evaluated against a comprehensive 7-page technical reference document (`evaluation/reference_os_systems.md`):

| Evaluation Metric | Target Benchmark | VELTRIX SourceMind Result | Status |
| :--- | :---: | :---: | :---: |
| **Context Recall Rate** | $\ge 90.0\%$ | **100.0%** (15/15 answerable queries) | **PASSED** |
| **Refusal Accuracy Rate** | $100.0\%$ | **100.0%** (5/5 out-of-domain queries) | **PASSED** |
| **Citation Validity Rate** | $100.0\%$ | **100.0%** (0 fake citations generated) | **PASSED** |
| **Mean Grounding Score** | $\ge 0.95$ | **1.000 / 1.000** | **PASSED** |
| **Retrieval Latency (P95)** | $< 50\text{ ms}$ | **14.41 ms** | **PASSED** |

Run the benchmark at any time:
```bash
python -m evaluation.run_rag_eval
```

---

## ⚡ Quickstart Guide

### Prerequisites
- Python 3.11 or higher
- Google Gemini API key ([Google AI Studio](https://aistudio.google.com/))
- (Optional) Docker & Docker Compose

### Local Development Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/veltrix-ai/sourcemind.git
   cd sourcemind
   ```

2. **Create and activate a virtual environment**:
   ```bash
   # Windows PowerShell
   python -m venv venv
   .\venv\Scripts\Activate.ps1

   # Linux / macOS
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements-dev.txt
   ```

4. **Configure environment credentials**:
   ```bash
   # Copy example environment configuration
   cp .env.example .env
   ```
   Open `.env` and set your `GEMINI_API_KEY`:
   ```ini
   GEMINI_API_KEY=AIzaSy...your_gemini_api_key_here
   ```

5. **Start the application**:
   ```bash
   uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
   ```
   Open your browser to:
   - **Studio UI**: `http://localhost:8000`
   - **Interactive API Docs (Swagger UI)**: `http://localhost:8000/docs`
   - **Healthcheck**: `http://localhost:8000/api/health`

---

### Docker Deployment

Deploy in production using Docker Compose with persistent data volumes:

```bash
# 1. Provide your Gemini API key in your environment or .env file
export GEMINI_API_KEY="AIzaSy..."

# 2. Build and run container stack
docker compose up -d --build

# 3. View live container logs
docker compose logs -f sourcemind

# 4. Check container health status
docker compose ps
```

The container automatically runs with:
- Dedicated unprivileged system user (`sourcemind`, UID 10001).
- Persistent volumes mapped to `sourcemind_uploads_data` and `sourcemind_chromadb_data`.
- Automated container healthchecks on `/api/health`.

---

## 🛠️ API & Studio Features

### 1. Document Ingestion
- Upload PDF, TXT, or Markdown documents via drag-and-drop UI or `POST /api/documents/upload`.
- Automatic page tracking preserves page numbers for every extracted chunk.

### 2. Grounded Chat & Streaming
- Ask complex questions across uploaded materials.
- Supports both standard JSON (`POST /api/chat`) and Server-Sent Events (`POST /api/chat/stream`).

### 3. Study Suite
- **Summaries**: Generate Short (1-paragraph), Medium (executive summary), or Detailed (in-depth analysis) overviews (`POST /api/study/summarize`).
- **Smart Notes**: Extract key definitions, architectural concepts, and high-yield takeaways (`POST /api/study/smart-notes`).
- **Revision Sheets**: Bulleted formula/concept sheets for rapid exam or meeting review (`POST /api/study/revision-sheet`).

### 4. Interactive Quiz Engine
- Generate customized practice tests with 3 to 10 questions (`POST /api/quiz/generate`).
- Submit responses for instant scoring, per-question explanations, and citation grounds (`POST /api/quiz/evaluate`).

---

## 🛡️ Security & Anti-Hallucination Guardrails

- **Indirect Prompt Injection Quarantine**: Sanitizes retrieved chunks to prevent XML escape breakouts (`&lt;/source_context&gt;`) and active prompt injection overrides (`SYSTEM OVERRIDE:`, `IGNORE ALL INSTRUCTIONS`).
- **Canary Leak Detection**: Scans generated outputs for system prompt canary tokens to prevent exfiltration.
- **Sliding-Window Rate Limiting**: Per-IP rate limiting (120 req/min default) preventing burst abuse on LLM endpoints.
- **Distributed Request Tracing**: Assigns and propagates `X-Request-ID` and `X-Process-Time-Ms` across all transactions.
- **Safe Error Shielding**: Catches unhandled exceptions and returns standardized error envelopes without leaking stack traces or environment variables.

---

## 📁 Project Structure

```
SourceMind/
├── backend/
│   ├── api/                     # REST & SSE route handlers
│   │   ├── routes/              # Modular route endpoints (docs, chat, study, quiz)
│   │   └── schemas/             # Pydantic request & response contracts
│   ├── core/                    # System configurations, security, rate limiting, logging
│   │   ├── config.py            # 12-factor BaseSettings configuration
│   │   ├── security.py          # Delimiter escaping & prompt injection neutralization
│   │   ├── rate_limiter.py      # Sliding-window IP rate limiter
│   │   └── middleware.py        # Request tracing & rate limit middleware
│   ├── embeddings/              # Embedding providers (Gemini & Mock) with caching
│   ├── generation/              # LLM adapters, prompts, and citation verification
│   │   ├── citation_verifier.py # Multi-tier citation grounding validator
│   │   └── gemini_generator.py  # Gemini 2.0 streaming generation adapter
│   ├── ingestion/               # Parsers, text cleaners, and security validators
│   ├── models/                  # Core domain models (documents, chunks, study notes)
│   ├── retrieval/               # Vector retriever & XML context assembler
│   ├── services/                # Business services (chat, study, quiz orchestration)
│   ├── vectorstore/             # ChromaDB adapter and base interfaces
│   └── main.py                  # FastAPI application entrypoint
├── evaluation/                  # Formal quantitative RAG evaluation harness
│   ├── reference_os_systems.md  # 7-page technical reference ground truth document
│   ├── benchmark_dataset.json   # 20-question golden evaluation dataset
│   └── run_rag_eval.py          # Automated benchmark runner CLI
├── frontend/                    # Modern Studio web application
│   ├── index.html               # Semantic HTML5 studio layout
│   └── static/
│       ├── css/styles.css       # Clean dark-mode stylesheet
│       └── js/app.js            # Vanilla JS application controller
├── tests/                       # Complete automated test suite (88 tests)
│   ├── e2e/                     # End-to-end benchmark quality gate tests
│   ├── integration/             # Ingestion and storage integration tests
│   └── unit/                    # Unit tests for all individual modules
├── Dockerfile                   # Multi-stage production container definition
├── docker-compose.yml           # Production container orchestration
├── .dockerignore                # Build context exclusion rules
├── .env.example                 # Documented configuration template
├── requirements.txt             # Pinned production dependencies
├── requirements-dev.txt         # Development & test dependencies
├── ARCHITECTURE.md              # Deep-dive architectural blueprint
├── API_DOCS.md                  # Comprehensive REST & SSE API documentation
└── STUDY_GUIDE_FOR_FOUNDER.md   # Executive & architectural guide for founders
```

---

## 🧪 Running Automated Tests

Run the full automated test suite (88 tests across 14 test modules):

```bash
# Run all tests with verbose output
pytest -v

# Run with test coverage reporting
pytest --cov=backend tests/
```

All 88 tests pass consistently without requiring active external internet connections or live API keys.

---

## 📚 Documentation Sitemap

- [ARCHITECTURE.md](ARCHITECTURE.md) — Comprehensive architectural blueprint and data flow specifications.
- [API_DOCS.md](API_DOCS.md) — Complete REST & SSE endpoint reference with request/response schemas.
- [STUDY_GUIDE_FOR_FOUNDER.md](STUDY_GUIDE_FOR_FOUNDER.md) — Strategic analysis of the NotebookLM paradigm and anti-hallucination engineering.

---

## 📄 License
This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.
