"""
Unit tests for FileValidator and Security validation rules.
"""

import pytest
from backend.core.config import settings
from backend.core.exceptions import (
    FileTooLargeError,
    UnsupportedFileError,
    EmptyDocumentError,
    CorruptedFileError,
    ValidationError
)
from backend.core.security import sanitize_filename
from backend.ingestion.validators import FileValidator


class TestFileValidator:
    def test_sanitize_filename_traversal(self):
        malicious = "../../../etc/passwd.pdf"
        sanitized = sanitize_filename(malicious)
        assert "/" not in sanitized
        assert ".." not in sanitized
        assert sanitized == "passwd.pdf"

    def test_sanitize_filename_special_chars(self):
        raw = "My Research & Notes (v1.0) [Final].pdf"
        sanitized = sanitize_filename(raw)
        assert " " not in sanitized
        assert "&" not in sanitized
        assert sanitized.endswith(".pdf")

    def test_validate_empty_file(self):
        with pytest.raises(EmptyDocumentError):
            FileValidator.validate_file_size(b"")

    def test_validate_oversized_file(self):
        oversized = b"A" * (settings.MAX_FILE_SIZE_BYTES + 1024)
        with pytest.raises(FileTooLargeError):
            FileValidator.validate_file_size(oversized)

    def test_validate_unsupported_extension(self):
        with pytest.raises(UnsupportedFileError):
            FileValidator.validate_filename_and_extension("document.exe")

        with pytest.raises(UnsupportedFileError):
            FileValidator.validate_filename_and_extension("data.csv")

    def test_validate_spoofed_pdf(self):
        # A text file renamed to .pdf without %PDF- magic bytes
        fake_pdf_content = b"This is just plain text masquerading as a PDF file."
        with pytest.raises(CorruptedFileError):
            FileValidator.validate_signature(fake_pdf_content, ".pdf")

    def test_validate_valid_pdf_signature(self):
        valid_pdf_header = b"%PDF-1.7\n1 0 obj\n<<>>\nendobj"
        mime = FileValidator.validate_signature(valid_pdf_header, ".pdf")
        assert mime == "application/pdf"

    def test_validate_valid_upload_flow(self):
        valid_content = b"# Machine Learning Guide\n\nChapter 1 Overview"
        name, ext, mime = FileValidator.validate_upload("guide.md", valid_content)
        assert name == "guide.md"
        assert ext == ".md"
        assert mime == "text/markdown"
