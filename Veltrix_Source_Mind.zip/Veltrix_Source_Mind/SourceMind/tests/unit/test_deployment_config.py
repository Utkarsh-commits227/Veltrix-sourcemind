"""
VELTRIX SourceMind - Deployment Configuration Validation Tests
Tests the structural integrity, security best practices, and schema validity
of Dockerfile, docker-compose.yml, .dockerignore, requirements.txt, and .env.example.
"""

from pathlib import Path
import pytest
import yaml

from backend.core.config import settings


@pytest.fixture
def repo_root() -> Path:
    """Returns absolute path to the repository root directory."""
    return settings.BASE_DIR


class TestDeploymentConfigurations:

    def test_dockerfile_multi_stage_and_security(self, repo_root: Path):
        """Verifies Dockerfile adheres to multi-stage build and non-root security standards."""
        dockerfile_path = repo_root / "Dockerfile"
        assert dockerfile_path.exists(), "Dockerfile must exist at repository root"

        content = dockerfile_path.read_text(encoding="utf-8")

        # Multi-stage verification
        assert "AS builder" in content, "Dockerfile must define a builder stage"
        assert "AS runner" in content, "Dockerfile must define a minimal runtime runner stage"
        assert "COPY --from=builder /opt/venv /opt/venv" in content, "Must copy virtualenv from builder"

        # Security: Least privilege user
        assert "groupadd" in content and "useradd" in content, "Must create dedicated system group and user"
        assert "USER sourcemind" in content, "Runtime container must execute as unprivileged user"

        # Port and Healthcheck
        assert "EXPOSE 8000" in content, "Container must expose port 8000"
        assert "HEALTHCHECK" in content, "Container must define a HEALTHCHECK instruction"
        assert "/api/health" in content, "Healthcheck must verify /api/health endpoint"

        # CMD launching uvicorn
        assert "backend.main:app" in content, "Entrypoint/CMD must launch backend.main:app"

    def test_docker_compose_valid_schema(self, repo_root: Path):
        """Parses docker-compose.yml and validates services, volumes, and healthchecks."""
        compose_path = repo_root / "docker-compose.yml"
        assert compose_path.exists(), "docker-compose.yml must exist at repository root"

        content = compose_path.read_text(encoding="utf-8")
        parsed = yaml.safe_load(content)

        assert "services" in parsed, "docker-compose must define services block"
        assert "sourcemind" in parsed["services"], "Must define 'sourcemind' service"

        svc = parsed["services"]["sourcemind"]
        assert "build" in svc, "Service must specify build configuration"
        assert "ports" in svc, "Service must specify port bindings"
        assert any("8000" in str(p) for p in svc["ports"]), "Port 8000 must be mapped"

        # Persistent storage volumes
        assert "volumes" in parsed, "Top-level volumes block must be defined for data persistence"
        assert "sourcemind_uploads" in parsed["volumes"]
        assert "sourcemind_chromadb" in parsed["volumes"]

        # Healthcheck probe in service
        assert "healthcheck" in svc, "Service must define container healthcheck"

    def test_dockerignore_coverage(self, repo_root: Path):
        """Verifies .dockerignore excludes confidential, large, and volatile directories."""
        dockerignore_path = repo_root / ".dockerignore"
        assert dockerignore_path.exists(), ".dockerignore must exist at repository root"

        content = dockerignore_path.read_text(encoding="utf-8")
        lines = [line.strip() for line in content.splitlines() if line.strip() and not line.startswith("#")]

        critical_exclusions = [
            ".git",
            "__pycache__/",
            ".pytest_cache/",
            ".env",
            "data/",
            "tests/",
            "evaluation/"
        ]

        for exclusion in critical_exclusions:
            assert exclusion in lines, f".dockerignore must exclude '{exclusion}'"

    def test_requirements_files_exist(self, repo_root: Path):
        """Verifies requirements.txt and requirements-dev.txt are present and specify core dependencies."""
        prod_reqs = repo_root / "requirements.txt"
        dev_reqs = repo_root / "requirements-dev.txt"

        assert prod_reqs.exists(), "requirements.txt must exist"
        assert dev_reqs.exists(), "requirements-dev.txt must exist"

        prod_content = prod_reqs.read_text(encoding="utf-8")
        assert "fastapi" in prod_content
        assert "uvicorn" in prod_content
        assert "chromadb" in prod_content
        assert "pydantic" in prod_content
        assert "google-genai" in prod_content

    def test_env_example_completeness(self, repo_root: Path):
        """Verifies .env.example documents all operational parameters required by Settings."""
        env_path = repo_root / ".env.example"
        assert env_path.exists(), ".env.example must exist"

        content = env_path.read_text(encoding="utf-8")

        required_keys = [
            "ENVIRONMENT",
            "GEMINI_API_KEY",
            "RATE_LIMIT_PER_MINUTE",
            "ENABLE_RATE_LIMITER",
            "CANARY_TOKEN",
            "CHROMA_COLLECTION_NAME",
            "SIMILARITY_THRESHOLD"
        ]

        for key in required_keys:
            assert f"{key}=" in content, f".env.example must document '{key}'"

    def test_documentation_suite_integrity(self, repo_root: Path):
        """Verifies all four core release documentation guides exist and have substantive content."""
        docs = {
            "README.md": ["# 🧠 VELTRIX SourceMind", "Table of Contents", "Quickstart Guide"],
            "ARCHITECTURE.md": ["# 🏛️ VELTRIX SourceMind — Architectural Blueprint", "End-to-End System Data Flow", "Subsystem Deep Dives"],
            "API_DOCS.md": ["# 📡 VELTRIX SourceMind — REST & Streaming API Documentation", "Health Check Endpoint", "Grounded RAG Chat Endpoints"],
            "STUDY_GUIDE_FOR_FOUNDER.md": ["# 🎓 VELTRIX SourceMind — Founder's Strategic & Architectural Study Guide", "The NotebookLM Paradigm Shift", "Why Naive RAG Fails in Production"]
        }

        for filename, expected_phrases in docs.items():
            doc_path = repo_root / filename
            assert doc_path.exists(), f"{filename} must exist at repository root"
            text = doc_path.read_text(encoding="utf-8")
            assert len(text) > 500, f"{filename} must have substantive content"
            for phrase in expected_phrases:
                assert phrase in text, f"{filename} must contain '{phrase}'"

