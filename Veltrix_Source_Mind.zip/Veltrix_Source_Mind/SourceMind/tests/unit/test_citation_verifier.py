"""
Unit tests for CitationVerifier and Grounding Verification Engine.
"""

import pytest
from backend.generation.citation_models import CitationStatus
from backend.generation.citation_verifier import CitationVerifier
from backend.vectorstore.base import VectorSearchResult


def make_retrieved_chunk(chunk_id: str, doc_name: str, page: int, content: str) -> VectorSearchResult:
    return VectorSearchResult(
        chunk_id=chunk_id,
        document_id="doc_1",
        document_name=doc_name,
        page_number=page,
        chunk_index=0,
        content=content,
        similarity_score=0.85,
        distance=0.15,
        metadata={}
    )


class TestCitationVerifier:
    def test_extract_raw_citations_multiple(self):
        text = (
            "Mitochondria generate adenosine triphosphate through respiration [[Source: biology.pdf, Page: 12]]. "
            "Ribosomes assemble amino acids into polypeptide chains [[Source: biology.pdf, Page: 14]]."
        )
        citations = CitationVerifier.extract_raw_citations(text)
        assert len(citations) == 2

        assert citations[0].document_name == "biology.pdf"
        assert citations[0].page_number == 12
        assert "Mitochondria generate" in citations[0].claim_text

        assert citations[1].document_name == "biology.pdf"
        assert citations[1].page_number == 14
        assert "Ribosomes assemble" in citations[1].claim_text

    def test_verify_legitimate_citation(self):
        retrieved = [
            make_retrieved_chunk(
                "chk_12", "biology.pdf", 12,
                "Cellular respiration in mitochondria produces cellular ATP energy through oxidative phosphorylation."
            )
        ]
        answer = "Mitochondria generate ATP energy through respiration [[Source: biology.pdf, Page: 12]]."
        report = CitationVerifier.verify_citations(answer, retrieved, sanitize_unverified=True)

        assert report.total_citations == 1
        assert report.verified_citations_count == 1
        assert report.grounding_fidelity_score == 1.0
        assert report.has_hallucinated_citations is False

        cit = report.citations[0]
        assert cit.is_verified is True
        assert cit.status == CitationStatus.VERIFIED
        assert cit.matched_chunk_id == "chk_12"
        assert cit.confidence_score > 0.4
        # Since verified, original tag remains
        assert "[[Source: biology.pdf, Page: 12]]" in report.verified_answer

    def test_catch_fake_page_citation(self):
        """CRITICAL: If the LLM cites a page that was never retrieved, flag as hallucinated."""
        # Only page 1 was retrieved
        retrieved = [
            make_retrieved_chunk("chk_1", "biology.pdf", 1, "Introduction to general biology.")
        ]
        # LLM hallucinated page 77
        answer = "Advanced CRISPR gene editing was discovered later [[Source: biology.pdf, Page: 77]]."
        report = CitationVerifier.verify_citations(answer, retrieved, sanitize_unverified=True)

        assert report.total_citations == 1
        assert report.verified_citations_count == 0
        assert report.grounding_fidelity_score == 0.0
        assert report.has_hallucinated_citations is True

        cit = report.citations[0]
        assert cit.is_verified is False
        assert cit.status == CitationStatus.UNVERIFIED_PAGE_NOT_RETRIEVED
        # Verify tag was sanitized
        assert "[Citation Unverified]" in report.verified_answer
        assert "[[Source: biology.pdf, Page: 77]]" not in report.verified_answer

    def test_catch_content_mismatch_citation(self):
        """If the page was retrieved, but the claim is completely absent from that page."""
        retrieved = [
            make_retrieved_chunk(
                "chk_5", "finance.pdf", 5,
                "Compound interest calculates interest on accumulated principal and interest."
            )
        ]
        # Page 5 exists, but claim is about astrophysics
        answer = "Black holes emit Hawking radiation over cosmological timescales [[Source: finance.pdf, Page: 5]]."
        report = CitationVerifier.verify_citations(answer, retrieved, sanitize_unverified=True)

        assert report.total_citations == 1
        assert report.verified_citations_count == 0
        assert report.has_hallucinated_citations is True

        cit = report.citations[0]
        assert cit.is_verified is False
        assert cit.status == CitationStatus.UNVERIFIED_CONTENT_MISMATCH
        assert "[Citation Unverified]" in report.verified_answer

    def test_zero_citations_returns_clean_report(self):
        answer = "I could not find information regarding this question in the provided source document."
        report = CitationVerifier.verify_citations(answer, [], sanitize_unverified=True)

        assert report.total_citations == 0
        assert report.verified_citations_count == 0
        assert report.grounding_fidelity_score == 1.0
        assert report.has_hallucinated_citations is False
        assert report.verified_answer == answer
