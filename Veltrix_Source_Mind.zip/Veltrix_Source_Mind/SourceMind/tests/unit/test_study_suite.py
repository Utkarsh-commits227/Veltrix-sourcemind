"""
Unit tests for StudySuite (Summaries, Smart Notes, Revision Sheets).
"""

import pytest
from backend.core.exceptions import EmptyDocumentError
from backend.generation.mock_generator import MockLLMGenerator
from backend.ingestion.base import ExtractedDocument, ExtractedPage
from backend.models.study_models import SummaryLevel
from backend.services.study_service import StudyService


def make_sample_doc(text: str = "Quantum computing relies on qubits and superposition.") -> ExtractedDocument:
    return ExtractedDocument(
        document_id="doc_qc_1",
        filename="quantum_notes.pdf",
        file_size_bytes=len(text),
        mime_type="application/pdf",
        sha256_hash="hash_quantum_12345",
        page_count=1,
        total_char_count=len(text),
        pages=[ExtractedPage(page_number=1, text=text, char_count=len(text), has_text=True)],
        full_text=text,
        metadata={"title": "Quantum Physics"},
        is_scanned_pdf=False
    )


class TestStudySuite:
    @pytest.fixture
    def study_service_instance(self):
        generator = MockLLMGenerator()
        return StudyService(generator_instance=generator)

    @pytest.mark.asyncio
    async def test_generate_short_summary(self, study_service_instance):
        doc = make_sample_doc()
        summary = await study_service_instance.generate_summary(doc, level=SummaryLevel.SHORT)

        assert summary.document_id == "doc_qc_1"
        assert summary.document_name == "quantum_notes.pdf"
        assert summary.level == SummaryLevel.SHORT
        assert len(summary.overview) > 0
        assert len(summary.key_takeaways) > 0
        assert "[[Source: quantum_notes.pdf, Page: 1]]" in summary.full_markdown

    @pytest.mark.asyncio
    async def test_generate_medium_summary(self, study_service_instance):
        doc = make_sample_doc()
        summary = await study_service_instance.generate_summary(doc, level=SummaryLevel.MEDIUM)

        assert summary.level == SummaryLevel.MEDIUM
        assert "Analytical Summary" in summary.full_markdown
        assert "Document Overview" in summary.full_markdown
        assert "Major Findings" in summary.full_markdown

    @pytest.mark.asyncio
    async def test_generate_detailed_summary(self, study_service_instance):
        doc = make_sample_doc()
        summary = await study_service_instance.generate_summary(doc, level=SummaryLevel.DETAILED)

        assert summary.level == SummaryLevel.DETAILED
        assert "Comprehensive Detailed Summary" in summary.full_markdown
        assert "Section-by-Section Breakdown" in summary.full_markdown

    @pytest.mark.asyncio
    async def test_generate_smart_notes(self, study_service_instance):
        doc = make_sample_doc()
        notes = await study_service_instance.generate_smart_notes(doc)

        assert notes.document_id == "doc_qc_1"
        assert notes.document_name == "quantum_notes.pdf"
        assert "Smart Study Notes" in notes.full_markdown
        assert "## 1. Overview & Context" in notes.full_markdown
        assert "## 2. Key Concepts & Principles" in notes.full_markdown
        assert "## 4. Key Definitions & Terminology" in notes.full_markdown
        assert len(notes.important_points) > 0
        assert len(notes.definitions) > 0
        assert notes.definitions[0].term == "Protocol"

    @pytest.mark.asyncio
    async def test_generate_revision_sheet(self, study_service_instance):
        doc = make_sample_doc()
        rev = await study_service_instance.generate_revision_sheet(doc)

        assert rev.document_id == "doc_qc_1"
        assert rev.document_name == "quantum_notes.pdf"
        assert "Rapid Revision Sheet" in rev.full_markdown
        assert "Must Remember" in rev.full_markdown
        assert len(rev.must_remember) >= 3
        assert len(rev.common_confusions) > 0
        assert len(rev.quick_questions) > 0

    @pytest.mark.asyncio
    async def test_empty_document_raises_error(self, study_service_instance):
        empty_doc = make_sample_doc(text="")
        with pytest.raises(EmptyDocumentError):
            await study_service_instance.generate_summary(empty_doc)

        with pytest.raises(EmptyDocumentError):
            await study_service_instance.generate_smart_notes(empty_doc)

        with pytest.raises(EmptyDocumentError):
            await study_service_instance.generate_revision_sheet(empty_doc)
