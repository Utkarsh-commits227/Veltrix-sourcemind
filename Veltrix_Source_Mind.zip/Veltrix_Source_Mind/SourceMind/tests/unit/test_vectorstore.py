"""
Unit and integration tests for ChromaVectorStore, metadata filtering,
document isolation, and similarity search.
"""

import pytest
from backend.core.exceptions import VectorStoreError
from backend.embeddings.mock_provider import MockEmbeddingProvider
from backend.ingestion.chunkers import DocumentChunk
from backend.vectorstore.chroma_store import ChromaVectorStore
from backend.vectorstore.service import VectorStoreService


def make_chunk(doc_id: str, doc_name: str, chunk_idx: int, page_num: int, content: str) -> DocumentChunk:
    import hashlib
    content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
    return DocumentChunk(
        chunk_id=f"{doc_id}_chk_{chunk_idx}",
        document_id=doc_id,
        document_name=doc_name,
        page_number=page_num,
        page_start=page_num,
        page_end=page_num,
        chunk_index=chunk_idx,
        char_start=0,
        char_end=len(content),
        content=content,
        token_count=len(content) // 4,
        content_hash=content_hash,
        metadata={"category": "test"}
    )


@pytest.fixture
def temp_chroma_store(tmp_path):
    """Provides an isolated, clean ChromaVectorStore for each test."""
    store = ChromaVectorStore(
        persist_dir=tmp_path / "chromadb_test",
        collection_name="test_collection"
    )
    return store


class TestChromaVectorStore:
    @pytest.mark.asyncio
    async def test_add_and_search_exact_match(self, temp_chroma_store):
        embedder = MockEmbeddingProvider(dimension=768)

        chunk1 = make_chunk("doc_1", "physics.pdf", 0, 1, "The theory of general relativity describes gravitation.")
        chunk2 = make_chunk("doc_1", "physics.pdf", 1, 2, "Quantum mechanics explains the behavior of subatomic particles.")

        chunks = [chunk1, chunk2]
        embeddings = await embedder.embed_texts([c.content for c in chunks])

        # Add chunks to vector store
        await temp_chroma_store.add_chunks(chunks, embeddings)

        # Query using exact text of chunk 1
        query_vector = await embedder.embed_query("The theory of general relativity describes gravitation.")
        results = await temp_chroma_store.search(query_vector, top_k=2, min_similarity=0.0)

        assert len(results) == 2
        # Top match should be chunk 1 with similarity ~ 1.0 (exact match in mock space)
        assert results[0].chunk_id == "doc_1_chk_0"
        assert results[0].page_number == 1
        assert results[0].document_name == "physics.pdf"
        assert results[0].similarity_score > 0.95
        assert "general relativity" in results[0].content

    @pytest.mark.asyncio
    async def test_document_isolation(self, temp_chroma_store):
        """Crucial test: Document A knowledge must NEVER contaminate Document B queries."""
        embedder = MockEmbeddingProvider(dimension=768)

        # Chunks for Document A (Biology)
        chunk_a1 = make_chunk("doc_A", "biology.pdf", 0, 1, "Mitochondria are the powerhouses of the cell.")
        chunk_a2 = make_chunk("doc_A", "biology.pdf", 1, 2, "Ribosomes synthesize cellular proteins.")

        # Chunks for Document B (Finance)
        chunk_b1 = make_chunk("doc_B", "finance.pdf", 0, 1, "Compound interest accelerates capital growth.")
        chunk_b2 = make_chunk("doc_B", "finance.pdf", 1, 2, "Liquidity ratios measure short-term solvency.")

        all_chunks = [chunk_a1, chunk_a2, chunk_b1, chunk_b2]
        all_embeddings = await embedder.embed_texts([c.content for c in all_chunks])

        await temp_chroma_store.add_chunks(all_chunks, all_embeddings)

        # Query scoped to Document A only
        query_vector = await embedder.embed_query("Tell me about cellular biology.")
        results_a = await temp_chroma_store.search(
            query_embedding=query_vector,
            top_k=5,
            document_id="doc_A",
            min_similarity=0.0
        )

        assert len(results_a) == 2
        for r in results_a:
            assert r.document_id == "doc_A"
            assert r.document_name == "biology.pdf"
            assert "finance" not in r.document_name

        # Query scoped to Document B only
        results_b = await temp_chroma_store.search(
            query_embedding=query_vector,
            top_k=5,
            document_id="doc_B",
            min_similarity=0.0
        )

        assert len(results_b) == 2
        for r in results_b:
            assert r.document_id == "doc_B"
            assert r.document_name == "finance.pdf"

    @pytest.mark.asyncio
    async def test_min_similarity_threshold_filtering(self, temp_chroma_store):
        embedder = MockEmbeddingProvider(dimension=768)
        chunk = make_chunk("doc_1", "doc.pdf", 0, 1, "Specific technical content.")
        embeddings = await embedder.embed_texts([chunk.content])
        await temp_chroma_store.add_chunks([chunk], embeddings)

        query_vector = await embedder.embed_query("Completely unrelated query that produces low similarity.")
        # Filter with an impossible threshold (0.9999)
        results = await temp_chroma_store.search(query_vector, top_k=5, min_similarity=0.9999)
        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_delete_document(self, temp_chroma_store):
        embedder = MockEmbeddingProvider(dimension=768)
        chunk1 = make_chunk("doc_del", "paper.pdf", 0, 1, "Section to be deleted.")
        embeddings = await embedder.embed_texts([chunk1.content])
        await temp_chroma_store.add_chunks([chunk1], embeddings)

        stats_before = await temp_chroma_store.get_stats("doc_del")
        assert stats_before["document_chunks"] == 1

        # Delete document
        deleted = await temp_chroma_store.delete_document("doc_del")
        assert deleted == 1

        stats_after = await temp_chroma_store.get_stats("doc_del")
        assert stats_after["document_chunks"] == 0

        # Query should return nothing
        query_vector = await embedder.embed_query("Section to be deleted.")
        results = await temp_chroma_store.search(query_vector, document_id="doc_del", min_similarity=0.0)
        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_mismatch_error(self, temp_chroma_store):
        chunk1 = make_chunk("doc_1", "doc.pdf", 0, 1, "Content 1")
        chunk2 = make_chunk("doc_1", "doc.pdf", 1, 1, "Content 2")
        with pytest.raises(VectorStoreError):
            # 2 chunks with only 1 embedding
            await temp_chroma_store.add_chunks([chunk1, chunk2], [[0.1, 0.2]])
