"""
Unit tests for PDFParser and TextParser.
"""

import io
import pytest
from pypdf import PdfWriter

from backend.core.exceptions import (
    CorruptedFileError,
    EmptyDocumentError,
    ScannedDocumentError
)
from backend.ingestion.parsers.pdf_parser import PDFParser
from backend.ingestion.parsers.text_parser import TextParser


# Standard spec-compliant raw PDF containing extractable text
VALID_PDF_BYTES = (
    b"%PDF-1.4\n"
    b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"
    b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n"
    b"3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> "
    b"/MediaBox [0 0 612 792] /Contents 5 0 R >>\nendobj\n"
    b"4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n"
    b"5 0 obj\n<< /Length 55 >>\nstream\n"
    b"BT\n/F1 12 Tf\n72 712 Td\n(VELTRIX SourceMind is an enterprise AI system) Tj\nET\n"
    b"endstream\nendobj\n"
    b"xref\n0 6\n"
    b"0000000000 65535 f \n"
    b"0000000009 00000 n \n"
    b"0000000058 00000 n \n"
    b"0000000115 00000 n \n"
    b"0000000234 00000 n \n"
    b"0000000307 00000 n \n"
    b"trailer\n<< /Size 6 /Root 1 0 R >>\n"
    b"startxref\n414\n%%EOF\n"
)


def create_blank_pdf_bytes() -> bytes:
    """Generates a valid PDF with blank pages (0 extractable text)."""
    writer = PdfWriter()
    writer.add_blank_page(width=612, height=792)
    buf = io.BytesIO()
    writer.write(buf)
    return buf.getvalue()


class TestTextParser:
    def test_parse_plain_text(self):
        content = b"Introduction to Neural Networks.\n\nDeep learning models rely on gradient descent."
        parser = TextParser()
        doc = parser.parse(None, content, "notes.txt")
        assert doc.filename == "notes.txt"
        assert doc.mime_type == "text/plain"
        assert doc.page_count == 1
        assert "Neural Networks" in doc.full_text
        assert len(doc.sha256_hash) == 64

    def test_parse_markdown_with_title(self):
        content = b"# Advanced RAG Architecture\n\nRetrieval-Augmented Generation bridges retrieval and LLMs."
        parser = TextParser()
        doc = parser.parse(None, content, "rag_guide.md")
        assert doc.filename == "rag_guide.md"
        assert doc.mime_type == "text/markdown"
        assert doc.metadata.get("title") == "Advanced RAG Architecture"
        assert "Retrieval-Augmented Generation" in doc.full_text

    def test_parse_latin1_encoding(self):
        # Text encoded with Latin-1 specific characters
        content = "Caf\xe9 and Resum\xe9 guide for engineers.".encode("latin-1")
        parser = TextParser()
        doc = parser.parse(None, content, "cafe.txt")
        assert "Café" in doc.full_text or "Cafe" in doc.full_text

    def test_empty_text_file(self):
        parser = TextParser()
        with pytest.raises(EmptyDocumentError):
            parser.parse(None, b"   \n\n\t   ", "empty.txt")


class TestPDFParser:
    def test_parse_valid_pdf(self):
        parser = PDFParser()
        doc = parser.parse(None, VALID_PDF_BYTES, "test_doc.pdf")
        assert doc.filename == "test_doc.pdf"
        assert doc.mime_type == "application/pdf"
        assert doc.page_count == 1
        assert "VELTRIX SourceMind" in doc.full_text
        assert doc.pages[0].page_number == 1
        assert doc.pages[0].has_text is True

    def test_scanned_blank_pdf_detection(self):
        blank_pdf = create_blank_pdf_bytes()
        parser = PDFParser()
        # Blank PDF without text should trigger ScannedDocumentError
        with pytest.raises(ScannedDocumentError):
            parser.parse(None, blank_pdf, "scanned_doc.pdf")

    def test_corrupted_pdf(self):
        corrupted = b"%PDF-1.4\nCorrupted binary data that does not conform to PDF specification..."
        parser = PDFParser()
        with pytest.raises(CorruptedFileError):
            parser.parse(None, corrupted, "corrupt.pdf")
