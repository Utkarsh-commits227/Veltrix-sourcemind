"""
VELTRIX SourceMind - API Route Integration & Unit Tests
Tests all REST and SSE streaming endpoints via Starlette / FastAPI TestClient.
"""

import json
import pytest
from starlette.testclient import TestClient

from backend.core.config import settings
from backend.embeddings.mock_provider import MockEmbeddingProvider
from backend.embeddings.service import embedding_service
from backend.generation.mock_generator import MockLLMGenerator
from backend.main import app
from backend.models.study_models import SummaryLevel
from backend.services.chat_service import chat_service
from backend.services.document_registry import document_registry
from backend.services.quiz_service import quiz_service
from backend.services.study_service import study_service

# Test document payload
SAMPLE_MARKDOWN_DOC = b"""# Introduction to Operating Systems
Operating systems manage hardware resources, including the CPU, memory, and I/O devices.
Virtual memory provides an abstraction of main memory, giving each process a uniform address space.
A process is an instance of a computer program that is being executed by one or many threads.
"""


@pytest.fixture(scope="module")
def api_client():
    """Configures deterministic mock providers and returns TestClient."""
    embedding_service.set_provider(MockEmbeddingProvider(dimension=768))

    mock_llm = MockLLMGenerator()
    chat_service.set_generator(mock_llm)
    study_service.set_generator(mock_llm)
    quiz_service.set_generator(mock_llm)

    with TestClient(app) as client:
        yield client


class TestAPIRoutes:

    def test_health_check_endpoint(self, api_client):
        """GET /api/health should report system status and vector store stats."""
        response = api_client.get("/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["app_name"] == settings.APP_NAME
        assert "vector_stats" in data

    def test_serve_root_spa(self, api_client):
        """GET / should serve the Web Studio Single Page Application."""
        response = api_client.get("/")
        assert response.status_code == 200
        assert "VELTRIX" in response.text
        assert "SourceMind" in response.text

    def test_document_lifecycle(self, api_client):
        """Tests POST /upload -> GET /documents -> GET /{id} -> DELETE /{id}."""
        # 1. Upload Markdown file
        files = {
            "file": ("os_intro.md", SAMPLE_MARKDOWN_DOC, "text/markdown")
        }
        upload_res = api_client.post("/api/documents/upload", files=files)
        assert upload_res.status_code == 201
        upload_data = upload_res.json()
        assert "document" in upload_data
        doc_id = upload_data["document"]["document_id"]
        assert upload_data["document"]["filename"] == "os_intro.md"
        assert upload_data["chunks_created"] > 0

        # 2. List documents
        list_res = api_client.get("/api/documents")
        assert list_res.status_code == 200
        list_data = list_res.json()
        assert list_data["total_count"] >= 1
        found = any(d["document_id"] == doc_id for d in list_data["documents"])
        assert found is True

        # 3. Get document details for Source Inspector
        detail_res = api_client.get(f"/api/documents/{doc_id}")
        assert detail_res.status_code == 200
        detail_data = detail_res.json()
        assert detail_data["document"]["document_id"] == doc_id
        assert len(detail_data["pages"]) == 1
        assert "Virtual memory" in detail_data["pages"][0]["text"]

        # 4. Clean up delete
        delete_res = api_client.delete(f"/api/documents/{doc_id}")
        assert delete_res.status_code == 200
        del_data = delete_res.json()
        assert del_data["deleted"] is True

        # 5. Confirm 404 after deletion
        get_deleted = api_client.get(f"/api/documents/{doc_id}")
        assert get_deleted.status_code == 404

    def test_upload_invalid_file_rejected(self, api_client):
        """Uploading unsupported file format should return 422 error."""
        files = {
            "file": ("script.py", b"import os\nprint('hello')", "text/x-python")
        }
        res = api_client.post("/api/documents/upload", files=files)
        assert res.status_code == 422

    def test_upload_empty_file_rejected(self, api_client):
        """Uploading empty file should return 400 error."""
        files = {
            "file": ("empty.txt", b"", "text/plain")
        }
        res = api_client.post("/api/documents/upload", files=files)
        assert res.status_code == 400

    def test_chat_buffered_endpoint(self, api_client):
        """POST /api/chat with valid question should return grounded answer and citations."""
        # First ingest a test doc
        files = {"file": ("os_intro.md", SAMPLE_MARKDOWN_DOC, "text/markdown")}
        upload_res = api_client.post("/api/documents/upload", files=files)
        doc_id = upload_res.json()["document"]["document_id"]

        try:
            # Query the chat endpoint
            payload = {
                "query": "What is virtual memory?",
                "document_id": doc_id,
                "min_similarity": 0.0
            }
            chat_res = api_client.post("/api/chat", json=payload)
            assert chat_res.status_code == 200
            data = chat_res.json()
            assert data["has_matches"] is True
            assert "memory" in data["answer"].lower()
            assert "os_intro.md" in data["answer"]
            assert data["grounding_fidelity_score"] >= 0.0

        finally:
            # Cleanup
            api_client.delete(f"/api/documents/{doc_id}")

    def test_chat_stream_endpoint(self, api_client):
        """POST /api/chat/stream should stream SSE tokens."""
        files = {"file": ("os_intro.md", SAMPLE_MARKDOWN_DOC, "text/markdown")}
        upload_res = api_client.post("/api/documents/upload", files=files)
        doc_id = upload_res.json()["document"]["document_id"]

        try:
            payload = {
                "query": "What does an operating system do?",
                "document_id": doc_id,
                "min_similarity": 0.0
            }
            stream_res = api_client.post("/api/chat/stream", json=payload)
            assert stream_res.status_code == 200
            assert "text/event-stream" in stream_res.headers["content-type"]
            text = stream_res.text
            assert "data: " in text
            assert "[DONE]" in text
        finally:
            api_client.delete(f"/api/documents/{doc_id}")

    def test_study_suite_endpoints(self, api_client):
        """POST /api/study/summary, /notes, and /revision endpoints."""
        files = {"file": ("os_intro.md", SAMPLE_MARKDOWN_DOC, "text/markdown")}
        upload_res = api_client.post("/api/documents/upload", files=files)
        doc_id = upload_res.json()["document"]["document_id"]

        try:
            # 1. Summary
            summary_res = api_client.post("/api/study/summary", json={
                "document_id": doc_id,
                "level": "medium"
            })
            assert summary_res.status_code == 200
            s_data = summary_res.json()
            assert s_data["document_id"] == doc_id
            assert "full_markdown" in s_data

            # 2. Smart Notes
            notes_res = api_client.post("/api/study/notes", json={"document_id": doc_id})
            assert notes_res.status_code == 200
            n_data = notes_res.json()
            assert n_data["document_id"] == doc_id

            # 3. Revision Sheet
            rev_res = api_client.post("/api/study/revision", json={"document_id": doc_id})
            assert rev_res.status_code == 200
            r_data = rev_res.json()
            assert r_data["document_id"] == doc_id

        finally:
            api_client.delete(f"/api/documents/{doc_id}")

    def test_quiz_endpoints(self, api_client):
        """POST /api/quiz/generate and /api/quiz/evaluate."""
        files = {"file": ("os_intro.md", SAMPLE_MARKDOWN_DOC, "text/markdown")}
        upload_res = api_client.post("/api/documents/upload", files=files)
        doc_id = upload_res.json()["document"]["document_id"]

        try:
            # 1. Generate Quiz
            gen_res = api_client.post("/api/quiz/generate", json={
                "document_id": doc_id,
                "num_questions": 3,
                "difficulty": "medium"
            })
            assert gen_res.status_code == 200
            quiz_data = gen_res.json()
            assert "quiz_id" in quiz_data
            assert len(quiz_data["questions"]) > 0

            # 2. Evaluate Quiz
            first_q = quiz_data["questions"][0]
            eval_res = api_client.post("/api/quiz/evaluate", json={
                "quiz": quiz_data,
                "user_answers": {first_q["question_id"]: first_q["correct_answer"]}
            })
            assert eval_res.status_code == 200
            eval_data = eval_res.json()
            assert "score_percentage" in eval_data
            assert eval_data["correct_count"] >= 1

        finally:
            api_client.delete(f"/api/documents/{doc_id}")
