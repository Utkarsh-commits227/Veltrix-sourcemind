"""
Unit tests for QuizService, practice test generation, and automated grading.
"""

import pytest
from backend.core.exceptions import EmptyDocumentError, GenerationError
from backend.generation.base import BaseLLMProvider
from backend.generation.mock_generator import MockLLMGenerator
from backend.ingestion.base import ExtractedDocument, ExtractedPage
from backend.models.quiz_models import DifficultyLevel, QuestionType
from backend.services.quiz_service import QuizService


class BrokenJSONGenerator(BaseLLMProvider):
    async def generate_stream(self, system_prompt: str, user_prompt: str, temperature: float = 0.1):
        yield "Not JSON content at all"

    async def generate(self, system_prompt: str, user_prompt: str, temperature: float = 0.1) -> str:
        return "Not a valid JSON response from LLM"

    def get_model_name(self) -> str:
        return "broken-json-mock"


def make_sample_doc(text: str = "Operating systems manage hardware resources using kernels and drivers.") -> ExtractedDocument:
    return ExtractedDocument(
        document_id="doc_os_1",
        filename="operating_systems.pdf",
        file_size_bytes=len(text),
        mime_type="application/pdf",
        sha256_hash="hash_os_12345",
        page_count=1,
        total_char_count=len(text),
        pages=[ExtractedPage(page_number=1, text=text, char_count=len(text), has_text=True)],
        full_text=text,
        metadata={"title": "Operating Systems"},
        is_scanned_pdf=False
    )


class TestQuizEngine:
    @pytest.fixture
    def quiz_service_instance(self):
        generator = MockLLMGenerator()
        return QuizService(generator_instance=generator)

    @pytest.mark.asyncio
    async def test_generate_quiz_structure(self, quiz_service_instance):
        doc = make_sample_doc()
        quiz = await quiz_service_instance.generate_quiz(
            document=doc,
            num_questions=2,
            difficulty=DifficultyLevel.MEDIUM,
            question_type=QuestionType.MULTIPLE_CHOICE
        )

        assert quiz.quiz_id is not None
        assert quiz.document_id == "doc_os_1"
        assert quiz.document_name == "operating_systems.pdf"
        assert quiz.total_questions == 2
        assert len(quiz.questions) == 2

        q1 = quiz.questions[0]
        assert q1.question_number == 1
        assert len(q1.options) == 4
        assert q1.correct_answer in ["A", "B", "C", "D"]
        assert q1.source_page == 1
        assert len(q1.explanation) > 0
        assert q1.source_quote is not None

    @pytest.mark.asyncio
    async def test_evaluate_quiz_perfect_score(self, quiz_service_instance):
        doc = make_sample_doc()
        quiz = await quiz_service_instance.generate_quiz(doc)

        # Submit perfect answers
        user_answers = {
            quiz.questions[0].question_id: quiz.questions[0].correct_answer,
            quiz.questions[1].question_id: quiz.questions[1].correct_answer
        }

        result = quiz_service_instance.evaluate_quiz(quiz, user_answers)

        assert result.total_questions == 2
        assert result.correct_count == 2
        assert result.incorrect_count == 0
        assert result.score_percentage == 100.0
        assert result.passed is True
        assert len(result.question_results) == 2
        assert result.question_results[0].is_correct is True

    @pytest.mark.asyncio
    async def test_evaluate_quiz_partial_score(self, quiz_service_instance):
        doc = make_sample_doc()
        quiz = await quiz_service_instance.generate_quiz(doc)

        # Submit 1 correct and 1 wrong
        wrong_opt = "D" if quiz.questions[1].correct_answer != "D" else "A"
        user_answers = {
            quiz.questions[0].question_id: quiz.questions[0].correct_answer,
            quiz.questions[1].question_id: wrong_opt
        }

        result = quiz_service_instance.evaluate_quiz(quiz, user_answers)

        assert result.correct_count == 1
        assert result.incorrect_count == 1
        assert result.score_percentage == 50.0
        assert result.passed is False
        assert result.question_results[0].is_correct is True
        assert result.question_results[1].is_correct is False

    @pytest.mark.asyncio
    async def test_empty_document_raises_error(self, quiz_service_instance):
        empty_doc = make_sample_doc(text="")
        with pytest.raises(EmptyDocumentError):
            await quiz_service_instance.generate_quiz(empty_doc)

    @pytest.mark.asyncio
    async def test_corrupted_json_raises_generation_error(self):
        broken_service = QuizService(generator_instance=BrokenJSONGenerator())
        doc = make_sample_doc()
        with pytest.raises(GenerationError):
            await broken_service.generate_quiz(doc)
