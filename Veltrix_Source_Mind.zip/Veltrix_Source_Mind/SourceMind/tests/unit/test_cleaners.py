"""
Unit tests for TextCleaner sanitization rules.
"""

import pytest
from backend.ingestion.cleaners import TextCleaner


class TestTextCleaner:
    def test_normalize_newlines(self):
        text = "Line 1\r\nLine 2\rLine 3\nLine 4"
        normalized = TextCleaner.normalize_newlines(text)
        assert normalized == "Line 1\nLine 2\nLine 3\nLine 4"

    def test_unicode_normalization(self):
        # Ligature 'ﬁ' (U+FB01) should decompose to 'fi'
        ligature_text = "Scientific ﬁndings in ofﬁce"
        normalized = TextCleaner.normalize_unicode(ligature_text)
        assert "findings" in normalized
        assert "office" in normalized

    def test_remove_control_characters(self):
        # Null bytes and escape chars should be removed; tabs and newlines retained
        text = "Hello\x00 World!\x1b[31m Test\tRetain\nLine"
        cleaned = TextCleaner.remove_control_characters(text)
        assert "\x00" not in cleaned
        assert "\t" in cleaned
        assert "\n" in cleaned
        assert "Hello World!" in cleaned

    def test_collapse_whitespace(self):
        text = "Word1     Word2   \t   Word3\n\n\n\n\nParagraph 2"
        collapsed = TextCleaner.collapse_whitespace(text)
        assert "Word1 Word2 Word3" in collapsed
        # Should preserve exactly 2 newlines for paragraph boundary
        assert "\n\n" in collapsed
        assert "\n\n\n" not in collapsed

    def test_sanitize_page_text_empty(self):
        assert TextCleaner.sanitize_page_text("") == ""
        assert TextCleaner.sanitize_page_text("   \n\r\t   ") == ""
