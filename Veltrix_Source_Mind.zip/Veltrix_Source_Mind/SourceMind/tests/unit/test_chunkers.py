"""
Unit and integration tests for RecursiveSemanticChunker and DocumentChunk models.
"""

import pytest
from backend.core.exceptions import ChunkingError
from backend.ingestion.base import ExtractedDocument, ExtractedPage
from backend.ingestion.chunkers import RecursiveSemanticChunker, DocumentChunk
from backend.services.ingestion_service import ingestion_service
from tests.unit.test_parsers import VALID_PDF_BYTES


def create_sample_document(num_pages: int = 1, text_per_page: str = "Short sample text.") -> ExtractedDocument:
    """Helper to generate a mock ExtractedDocument."""
    pages = [
        ExtractedPage(
            page_number=i + 1,
            text=text_per_page,
            char_count=len(text_per_page),
            has_text=True,
            metadata={}
        )
        for i in range(num_pages)
    ]
    return ExtractedDocument(
        document_id="test_doc_uuid_123",
        filename="lecture_notes.pdf",
        file_size_bytes=1024,
        mime_type="application/pdf",
        sha256_hash="fake_hash_1234567890abcdef",
        page_count=num_pages,
        total_char_count=len(text_per_page) * num_pages,
        pages=pages,
        full_text="\n\n".join(p.text for p in pages),
        metadata={"title": "Lecture Notes"},
        is_scanned_pdf=False
    )


class TestRecursiveSemanticChunker:
    def test_invalid_parameters(self):
        # Overlap cannot be >= chunk_size
        with pytest.raises(ValueError):
            RecursiveSemanticChunker(chunk_size_tokens=100, chunk_overlap_tokens=100)

        with pytest.raises(ValueError):
            RecursiveSemanticChunker(chunk_size_tokens=100, chunk_overlap_tokens=120)

    def test_chunk_short_text_single_chunk(self):
        chunker = RecursiveSemanticChunker(chunk_size_tokens=400, chunk_overlap_tokens=50)
        doc = create_sample_document(num_pages=1, text_per_page="A brief statement on machine learning.")
        chunks = chunker.chunk_document(doc)

        assert len(chunks) == 1
        chunk = chunks[0]
        assert chunk.chunk_index == 0
        assert chunk.page_number == 1
        assert chunk.document_id == "test_doc_uuid_123"
        assert chunk.document_name == "lecture_notes.pdf"
        assert chunk.content == "A brief statement on machine learning."
        assert len(chunk.content_hash) == 64
        assert chunk.token_count > 0

    def test_chunk_large_text_respects_paragraph_boundaries(self):
        # Create a document with 5 paragraphs of 300 characters each (~1500 chars)
        paragraphs = [
            f"Paragraph {i}: This is structured paragraph content designed to test semantic chunk splitting. "
            f"It discusses concept {i} in depth and provides relevant context for the vector index."
            for i in range(1, 10)
        ]
        doc_text = "\n\n".join(paragraphs)

        # Use small chunk size (100 tokens ~= 400 chars) with 20 tokens overlap (~80 chars)
        chunker = RecursiveSemanticChunker(chunk_size_tokens=100, chunk_overlap_tokens=20)
        doc = create_sample_document(num_pages=1, text_per_page=doc_text)
        chunks = chunker.chunk_document(doc)

        assert len(chunks) > 1

        # Check sequential indexing and page mapping
        for idx, chk in enumerate(chunks):
            assert chk.chunk_index == idx
            assert chk.page_number == 1
            assert len(chk.content) <= chunker.chunk_size_chars * 1.25  # Within budget

    def test_chunk_overlap_continuity(self):
        """Verify that adjacent chunks share overlapping text."""
        para1 = "Alpha section discusses foundational algorithms in distributed computing."
        para2 = "Beta section analyzes consensus protocols like Paxos and Raft in clustered databases."
        para3 = "Gamma section evaluates Byzantine Fault Tolerance under hostile adversarial conditions."
        combined = f"{para1}\n\n{para2}\n\n{para3}"

        # Set small chunk size to force splitting between paragraphs
        chunker = RecursiveSemanticChunker(chunk_size_tokens=30, chunk_overlap_tokens=10)
        doc = create_sample_document(num_pages=1, text_per_page=combined)
        chunks = chunker.chunk_document(doc)

        assert len(chunks) >= 2
        # Check that there is common text or conceptual bridge between chunk 0 and chunk 1
        chunk0_text = chunks[0].content
        chunk1_text = chunks[1].content
        # Ensure neither chunk is empty
        assert len(chunk0_text) > 0
        assert len(chunk1_text) > 0

    def test_multi_page_chunk_page_tracking(self):
        """Verify that chunks preserve the exact page they originated from."""
        doc = ExtractedDocument(
            document_id="multi_page_doc",
            filename="textbook.pdf",
            file_size_bytes=4096,
            mime_type="application/pdf",
            sha256_hash="hash9876543210",
            page_count=3,
            total_char_count=600,
            pages=[
                ExtractedPage(page_number=1, text="Page 1: Classical Mechanics and Newton's Laws.", char_count=48, has_text=True),
                ExtractedPage(page_number=2, text="Page 2: Thermodynamics and Entropy principles.", char_count=47, has_text=True),
                ExtractedPage(page_number=3, text="Page 3: Quantum Mechanics and Wave-Particle duality.", char_count=52, has_text=True),
            ],
            full_text="Full textbook content",
            metadata={},
            is_scanned_pdf=False
        )

        chunker = RecursiveSemanticChunker()
        chunks = chunker.chunk_document(doc)

        assert len(chunks) == 3
        assert chunks[0].page_number == 1
        assert "Classical Mechanics" in chunks[0].content

        assert chunks[1].page_number == 2
        assert "Thermodynamics" in chunks[1].content

        assert chunks[2].page_number == 3
        assert "Quantum Mechanics" in chunks[2].content

    def test_empty_pages_error(self):
        doc = ExtractedDocument(
            document_id="empty_doc",
            filename="empty.pdf",
            file_size_bytes=100,
            mime_type="application/pdf",
            sha256_hash="empty_hash",
            page_count=0,
            total_char_count=0,
            pages=[],
            full_text="",
            metadata={},
            is_scanned_pdf=False
        )
        chunker = RecursiveSemanticChunker()
        with pytest.raises(ChunkingError):
            chunker.chunk_document(doc)


class TestIngestionServiceChunkingIntegration:
    def test_ingest_and_chunk_full_pipeline(self):
        doc, chunks = ingestion_service.ingest_and_chunk(
            filename="sample_whitepaper.pdf",
            content=VALID_PDF_BYTES,
            save_to_disk=False
        )

        assert doc.filename == "sample_whitepaper.pdf"
        assert len(chunks) >= 1
        first_chunk = chunks[0]
        assert first_chunk.document_name == "sample_whitepaper.pdf"
        assert first_chunk.page_number == 1
        assert "VELTRIX SourceMind" in first_chunk.content
        assert first_chunk.token_count > 0
