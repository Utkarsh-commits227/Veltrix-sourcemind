"""
Unit tests for Embedding Provider abstraction, MockEmbeddingProvider,
EmbeddingCache, and EmbeddingService.
"""

import math
import pytest
from backend.core.exceptions import EmbeddingError
from backend.embeddings.cache import EmbeddingCache
from backend.embeddings.mock_provider import MockEmbeddingProvider
from backend.embeddings.service import EmbeddingService
from backend.ingestion.chunkers import DocumentChunk


def create_test_chunk(chunk_id: str, content: str) -> DocumentChunk:
    """Helper to create a test DocumentChunk."""
    import hashlib
    content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
    return DocumentChunk(
        chunk_id=chunk_id,
        document_id="doc_test_1",
        document_name="sample.pdf",
        page_number=1,
        page_start=1,
        page_end=1,
        chunk_index=0,
        char_start=0,
        char_end=len(content),
        content=content,
        token_count=len(content) // 4,
        content_hash=content_hash,
        metadata={}
    )


class TestMockEmbeddingProvider:
    @pytest.mark.asyncio
    async def test_determinism_and_dimensions(self):
        provider = MockEmbeddingProvider(dimension=768)
        assert provider.get_dimension() == 768
        assert provider.get_model_name() == "mock-embedding-768"

        text_a = "Machine learning models require training data."
        text_b = "Quantum computing relies on superposition."

        vectors = await provider.embed_texts([text_a, text_b, text_a])

        # Dimension checks
        assert len(vectors) == 3
        assert len(vectors[0]) == 768
        assert len(vectors[1]) == 768

        # Determinism check: identical text produces identical vector
        assert vectors[0] == vectors[2]

        # Distinctness check: different texts produce different vectors
        assert vectors[0] != vectors[1]

        # Unit normalization check: L2 norm = sqrt(sum(v_i^2)) ~= 1.0
        norm_a = math.sqrt(sum(x * x for x in vectors[0]))
        norm_b = math.sqrt(sum(x * x for x in vectors[1]))
        assert pytest.approx(norm_a, abs=1e-5) == 1.0
        assert pytest.approx(norm_b, abs=1e-5) == 1.0

    @pytest.mark.asyncio
    async def test_embed_query(self):
        provider = MockEmbeddingProvider(dimension=768)
        query = "What is reinforcement learning?"
        vector = await provider.embed_query(query)
        assert len(vector) == 768
        norm = math.sqrt(sum(x * x for x in vector))
        assert pytest.approx(norm, abs=1e-5) == 1.0


class TestEmbeddingCache:
    def test_cache_lifecycle(self):
        cache = EmbeddingCache()
        stats = cache.get_stats()
        assert stats["cached_vectors_count"] == 0
        assert stats["cache_hits"] == 0
        assert stats["cache_misses"] == 0

        # Cache miss
        assert cache.get("hash_123") is None
        assert cache.get_stats()["cache_misses"] == 1

        # Cache store
        mock_vec = [0.1, 0.2, 0.3]
        cache.set("hash_123", mock_vec)
        assert cache.get_stats()["cached_vectors_count"] == 1

        # Cache hit
        retrieved = cache.get("hash_123")
        assert retrieved == mock_vec
        assert cache.get_stats()["cache_hits"] == 1

        # Clear
        cache.clear()
        assert cache.get_stats()["cached_vectors_count"] == 0


class TestEmbeddingService:
    @pytest.mark.asyncio
    async def test_embed_chunks_with_caching(self):
        cache = EmbeddingCache()
        provider = MockEmbeddingProvider(dimension=768)
        service = EmbeddingService(provider=provider, cache=cache)

        chunk1 = create_test_chunk("chk_1", "Artificial intelligence overview.")
        chunk2 = create_test_chunk("chk_2", "Deep neural networks architecture.")
        chunk3 = create_test_chunk("chk_3", "Artificial intelligence overview.")  # Duplicate of chunk1

        # First run: chunk1 and chunk2 should be computed, chunk3 should hit cache or be cached
        vectors = await service.embed_chunks([chunk1, chunk2, chunk3])
        assert len(vectors) == 3
        assert len(vectors[0]) == 768
        assert vectors[0] == vectors[2]  # Identical content -> identical vectors

        # Second run: All should hit cache
        stats_before = cache.get_stats()
        vectors_rerun = await service.embed_chunks([chunk1, chunk2])
        stats_after = cache.get_stats()

        assert stats_after["cache_hits"] == stats_before["cache_hits"] + 2
        assert vectors_rerun[0] == vectors[0]

    @pytest.mark.asyncio
    async def test_empty_query_validation(self):
        service = EmbeddingService(provider=MockEmbeddingProvider())
        with pytest.raises(EmbeddingError):
            await service.embed_query("")

        with pytest.raises(EmbeddingError):
            await service.embed_query("   ")
