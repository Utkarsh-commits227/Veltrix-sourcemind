"""
VELTRIX SourceMind - End-to-End RAG Benchmark Automated Pytest Suite
Executes the 20-question evaluation benchmark and verifies quantitative quality gates:
1. Context Recall >= 90%
2. Honest Refusal Accuracy = 100% (zero hallucination on unanswerable questions)
3. Citation Validity = 100% (zero fake or hallucinated page numbers)
4. Overall Grounding Fidelity >= 0.95
"""

import pytest
from evaluation.run_rag_eval import RAGEvaluationHarness
from evaluation.eval_models import QuestionCategory


@pytest.mark.asyncio
class TestRAGBenchmarkSuite:

    async def test_full_benchmark_execution(self):
        """Runs the 20-question golden benchmark and validates quality metrics."""
        harness = RAGEvaluationHarness(use_mock_llm=True)
        report = await harness.run()

        # Quality Gate 1: 100% Refusal on Unanswerable questions
        assert report.unanswerable_count == 5
        assert report.refusal_accuracy_rate == 100.0, (
            f"Refusal accuracy must be 100%, but got {report.refusal_accuracy_rate}%."
        )

        # Quality Gate 2: Context Recall on answerable questions >= 90%
        assert report.factual_count == 10
        assert report.synthesis_count == 5
        assert report.context_recall_rate >= 90.0, (
            f"Context recall must be >= 90.0%, but got {report.context_recall_rate}%."
        )

        # Quality Gate 3: Citation Validity = 100% (zero fake citations)
        assert report.citation_validity_rate == 100.0, (
            f"Citation validity must be 100%, but got {report.citation_validity_rate}%."
        )

        # Quality Gate 4: Grounding Fidelity
        assert report.mean_grounding_fidelity >= 0.95, (
            f"Mean grounding fidelity must be >= 0.95, but got {report.mean_grounding_fidelity}."
        )

        # Quality Gate 5: Overall Benchmark passed flag
        assert report.all_tests_passed is True

    async def test_unanswerable_refusal_details(self):
        """Verifies individual unanswerable questions produce 0 citations and standard refusal."""
        harness = RAGEvaluationHarness(use_mock_llm=True)
        report = await harness.run()

        unanswerable_cases = [r for r in report.results if r.category == QuestionCategory.UNANSWERABLE]
        assert len(unanswerable_cases) == 5

        for case in unanswerable_cases:
            assert case.is_refusal is True, f"Question {case.question_id} was not refused."
            assert case.citations_count == 0, f"Question {case.question_id} had fake citations."
            assert case.refusal_passed is True

    async def test_answerable_citations_provenance(self):
        """Verifies that all answerable queries cite genuine pages matching retrieved chunks."""
        harness = RAGEvaluationHarness(use_mock_llm=True)
        report = await harness.run()

        answerable_cases = [r for r in report.results if r.category != QuestionCategory.UNANSWERABLE]
        assert len(answerable_cases) == 15

        for case in answerable_cases:
            assert case.context_recall_passed is True, (
                f"Question {case.question_id} missed expected pages {case.expected_pages}. "
                f"Got retrieved pages: {case.retrieved_pages}"
            )
            assert case.citations_valid is True, f"Question {case.question_id} has invalid citations."
            assert case.grounding_fidelity_score == 1.0
