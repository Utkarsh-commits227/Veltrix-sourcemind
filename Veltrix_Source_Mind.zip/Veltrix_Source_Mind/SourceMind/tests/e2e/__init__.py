"""
VELTRIX SourceMind - End-to-End Evaluation Tests
"""
