"""
Integration tests for the complete IngestionService workflow.
"""

from pathlib import Path
import pytest

from backend.core.config import settings
from backend.core.exceptions import UnsupportedFileError, CorruptedFileError
from backend.services.ingestion_service import ingestion_service
from tests.unit.test_parsers import VALID_PDF_BYTES


class TestIngestionServiceIntegration:
    def test_ingest_pdf_pipeline(self):
        doc = ingestion_service.ingest_file(
            filename="sample_whitepaper.pdf",
            content=VALID_PDF_BYTES,
            save_to_disk=True
        )

        assert doc.document_id is not None
        assert doc.filename == "sample_whitepaper.pdf"
        assert doc.page_count == 1
        assert "VELTRIX SourceMind" in doc.full_text
        assert "storage_path" in doc.metadata

        # Verify physical file was written to uploads directory
        disk_path = Path(doc.metadata["storage_path"])
        assert disk_path.exists()
        assert disk_path.stat().st_size == len(VALID_PDF_BYTES)

        # Cleanup test file
        if disk_path.exists():
            disk_path.unlink()

    def test_ingest_markdown_pipeline(self):
        md_content = b"# Python Systems Design\n\nChapter 1 covers asynchronous pipelines and event loops."
        doc = ingestion_service.ingest_file(
            filename="systems.md",
            content=md_content,
            save_to_disk=True
        )

        assert doc.filename == "systems.md"
        assert doc.mime_type == "text/markdown"
        assert "asynchronous pipelines" in doc.full_text
        assert doc.metadata.get("title") == "Python Systems Design"

        disk_path = Path(doc.metadata["storage_path"])
        if disk_path.exists():
            disk_path.unlink()

    def test_reject_unsupported_file(self):
        with pytest.raises(UnsupportedFileError):
            ingestion_service.ingest_file(
                filename="script.py",
                content=b"print('Hello world')",
                save_to_disk=False
            )

    def test_reject_spoofed_pdf(self):
        with pytest.raises(CorruptedFileError):
            ingestion_service.ingest_file(
                filename="fake.pdf",
                content=b"Plain text content without PDF header magic",
                save_to_disk=False
            )
