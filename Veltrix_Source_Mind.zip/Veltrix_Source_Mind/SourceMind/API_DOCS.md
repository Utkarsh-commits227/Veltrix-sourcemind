# 📡 VELTRIX SourceMind — REST & Streaming API Documentation

> **Complete Reference Guide for VELTRIX SourceMind HTTP APIs**  
> *Includes REST endpoints, Server-Sent Events (SSE) streaming protocols, schemas, and curl examples.*

---

## 📑 Table of Contents
1. [General Overview](#1-general-overview)
2. [Global Headers & Standard Responses](#2-global-headers--standard-responses)
3. [Health Check Endpoint](#3-health-check-endpoint)
4. [Document Management Endpoints](#4-document-management-endpoints)
   - [Upload Document](#41-upload-document)
   - [List Ingested Documents](#42-list-ingested-documents)
   - [Delete Document](#43-delete-document)
5. [Grounded RAG Chat Endpoints](#5-grounded-rag-chat-endpoints)
   - [Standard Grounded Chat](#51-standard-grounded-chat)
   - [Streaming Grounded Chat (SSE)](#52-streaming-grounded-chat-sse)
6. [Study Suite Endpoints](#6-study-suite-endpoints)
   - [Generate Executive Summary](#61-generate-executive-summary)
   - [Generate Smart Notes](#62-generate-smart-notes)
   - [Generate Revision Sheet](#63-generate-revision-sheet)
7. [Practice Quiz & Testing Endpoints](#7-practice-quiz--testing-endpoints)
   - [Generate Practice Quiz](#71-generate-practice-quiz)
   - [Evaluate Quiz Answers](#72-evaluate-quiz-answers)
8. [Error Codes & Troubleshooting](#8-error-codes--troubleshooting)

---

## 1. General Overview

VELTRIX SourceMind exposes high-assurance APIs for document ingestion, semantic retrieval, grounded synthesis, and active practice testing.

- **Base URL**: `http://localhost:8000` (or configured host/port)
- **Content-Type**: `application/json` (except document upload which uses `multipart/form-data`)
- **Interactive OpenAPI Documentation**: Available at `/docs` (Swagger UI) and `/redoc` (ReDoc).

---

## 2. Global Headers & Standard Responses

### Response Headers
Every HTTP transaction automatically carries distributed tracing and rate-limiting telemetry headers:

| Header | Description | Example |
| :--- | :--- | :--- |
| `X-Request-ID` | Unique UUID tracking the request across server logs. | `550e8400-e29b-41d4-a716-446655440000` |
| `X-Process-Time-Ms` | Execution latency inside the ASGI server in milliseconds. | `14.82` |
| `X-RateLimit-Limit` | Maximum allowed requests per 60-second sliding window. | `120` |
| `X-RateLimit-Remaining` | Remaining requests allowed in the current window. | `118` |

### Error Response Schema
All client or server errors return a standard JSON envelope:
```json
{
  "error": {
    "code": "INVALID_FILE_TYPE",
    "message": "Unsupported file extension '.exe'. Allowed extensions: .pdf, .txt, .md",
    "request_id": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

---

## 3. Health Check Endpoint

### `GET /api/health`
Verifies server liveness, operational environment, and version.

#### Request Example
```bash
curl -X GET http://localhost:8000/api/health
```

#### Response (`200 OK`)
```json
{
  "status": "healthy",
  "app_name": "VELTRIX SourceMind",
  "version": "0.1.0",
  "environment": "production"
}
```

---

## 4. Document Management Endpoints

### 4.1 Upload Document
### `POST /api/documents/upload`
Uploads a document (PDF, TXT, or Markdown), validates magic bytes, extracts text with per-page tracking, semantically chunks the content, computes vector embeddings, and indexes them into ChromaDB.

- **Content-Type**: `multipart/form-data`
- **Max File Size**: 25 MB

#### Request Form Data
| Parameter | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `file` | File Binary | Yes | File to ingest (`.pdf`, `.txt`, `.md`). |

#### Request Example
```bash
curl -X POST http://localhost:8000/api/documents/upload \
  -F "file=@/path/to/operating_systems.pdf"
```

#### Response (`200 OK`)
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "filename": "operating_systems.pdf",
  "file_size_bytes": 1048576,
  "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "page_count": 7,
  "chunk_count": 10,
  "status": "indexed",
  "created_at": "2026-10-03T14:30:00Z"
}
```

---

### 4.2 List Ingested Documents
### `GET /api/documents`
Lists all documents currently indexed in the knowledge vault.

#### Request Example
```bash
curl -X GET http://localhost:8000/api/documents
```

#### Response (`200 OK`)
```json
{
  "documents": [
    {
      "document_id": "doc_a1b2c3d4e5f6",
      "filename": "operating_systems.pdf",
      "page_count": 7,
      "chunk_count": 10,
      "file_size_bytes": 1048576,
      "created_at": "2026-10-03T14:30:00Z"
    }
  ],
  "total_count": 1
}
```

---

### 4.3 Delete Document
### `DELETE /api/documents/{document_id}`
Removes a document from disk storage and purges all corresponding vector embeddings from ChromaDB.

#### Request Example
```bash
curl -X DELETE http://localhost:8000/api/documents/doc_a1b2c3d4e5f6
```

#### Response (`200 OK`)
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "status": "deleted",
  "message": "Document and all associated vector chunks removed successfully."
}
```

---

## 5. Grounded RAG Chat Endpoints

### 5.1 Standard Grounded Chat
### `POST /api/chat`
Submits a user prompt, retrieves relevant source chunks using cosine similarity, applies prompt injection sanitization, queries Gemini 2.0 Flash with grounding prompts, audits citations, and returns a verified JSON response.

#### Request Body
```json
{
  "query": "How does virtual memory paging translate addresses?",
  "document_id": "doc_a1b2c3d4e5f6",
  "top_k": 5
}
```
*Note: `document_id` is optional; if omitted, search spans all uploaded documents.*

#### Request Example
```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "query": "How does virtual memory paging translate addresses?",
    "document_id": "doc_a1b2c3d4e5f6"
  }'
```

#### Response (`200 OK`)
```json
{
  "query": "How does virtual memory paging translate addresses?",
  "answer": "Virtual memory paging translates virtual addresses to physical frames through a multi-level page table hierarchy [operating_systems.pdf: page 3]. The CPU uses a Translation Lookaside Buffer (TLB) to cache recent translations [operating_systems.pdf: page 4].",
  "citations": [
    {
      "document_name": "operating_systems.pdf",
      "page_number": 3,
      "status": "VERIFIED"
    },
    {
      "document_name": "operating_systems.pdf",
      "page_number": 4,
      "status": "VERIFIED"
    }
  ],
  "referenced_chunks": [
    {
      "chunk_id": "chk_001",
      "document_name": "operating_systems.pdf",
      "page_number": 3,
      "similarity_score": 0.94
    }
  ]
}
```

---

### 5.2 Streaming Grounded Chat (SSE)
### `POST /api/chat/stream`
Streams generated tokens in real-time using standard Server-Sent Events (`text/event-stream`).

#### Request Body
```json
{
  "query": "Describe pipeline hazards and branch prediction.",
  "document_id": "doc_a1b2c3d4e5f6"
}
```

#### Request Example
```bash
curl -N -X POST http://localhost:8000/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"query": "Describe pipeline hazards and branch prediction."}'
```

#### Event Stream Protocol
```
data: {"token": "Pipeline "}

data: {"token": "hazards "}

data: {"token": "occur "}

data: {"done": true, "citations": [{"document_name": "operating_systems.pdf", "page_number": 2}]}
```

---

## 6. Study Suite Endpoints

### 6.1 Generate Executive Summary
### `POST /api/study/summarize`
Synthesizes a structured summary of an ingested document.

#### Request Body
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "length": "medium"
}
```
*`length` options: `"short"` (~150 words), `"medium"` (~350 words), `"detailed"` (~800 words).*

#### Request Example
```bash
curl -X POST http://localhost:8000/api/study/summarize \
  -H "Content-Type: application/json" \
  -d '{"document_id": "doc_a1b2c3d4e5f6", "length": "medium"}'
```

#### Response (`200 OK`)
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "length": "medium",
  "summary": "### Core Architecture\nThis document outlines modern OS kernel design...",
  "key_findings": [
    "Multi-level paging mitigates physical memory fragmentation.",
    "Hardware atomics guarantee lock-free synchronization."
  ],
  "generated_at": "2026-10-03T14:35:00Z"
}
```

---

### 6.2 Generate Smart Notes
### `POST /api/study/smart-notes`
Extracts structured study notes containing key concepts, architectural diagrams in text, and essential takeaways.

#### Request Body
```json
{
  "document_id": "doc_a1b2c3d4e5f6"
}
```

#### Request Example
```bash
curl -X POST http://localhost:8000/api/study/smart-notes \
  -H "Content-Type: application/json" \
  -d '{"document_id": "doc_a1b2c3d4e5f6"}'
```

#### Response (`200 OK`)
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "title": "Operating Systems & Computer Architecture Notes",
  "sections": [
    {
      "heading": "Virtual Memory & Paging",
      "concepts": [
        {
          "name": "TLB (Translation Lookaside Buffer)",
          "definition": "A high-speed hardware cache for virtual-to-physical address mappings."
        }
      ],
      "takeaways": [
        "A TLB hit avoids memory walk overhead."
      ]
    }
  ]
}
```

---

### 6.3 Generate Revision Sheet
### `POST /api/study/revision-sheet`
Creates high-yield rapid recall bullet points and formulas for fast exam or interview review.

#### Request Example
```bash
curl -X POST http://localhost:8000/api/study/revision-sheet \
  -H "Content-Type: application/json" \
  -d '{"document_id": "doc_a1b2c3d4e5f6"}'
```

---

## 7. Practice Quiz & Testing Endpoints

### 7.1 Generate Practice Quiz
### `POST /api/quiz/generate`
Generates a multiple-choice practice quiz grounded exclusively in the document's content.

#### Request Body
```json
{
  "document_id": "doc_a1b2c3d4e5f6",
  "num_questions": 5
}
```

#### Request Example
```bash
curl -X POST http://localhost:8000/api/quiz/generate \
  -H "Content-Type: application/json" \
  -d '{"document_id": "doc_a1b2c3d4e5f6", "num_questions": 5}'
```

#### Response (`200 OK`)
```json
{
  "quiz_id": "quiz_991827",
  "document_id": "doc_a1b2c3d4e5f6",
  "questions": [
    {
      "question_id": 1,
      "question_text": "What is the primary function of a Translation Lookaside Buffer (TLB)?",
      "options": [
        "A) Direct Memory Access for disk controllers",
        "B) Hardware cache for virtual-to-physical address mappings",
        "C) Instruction pipelining register",
        "D) Process scheduling priority queue"
      ]
    }
  ]
}
```

---

### 7.2 Evaluate Quiz Answers
### `POST /api/quiz/evaluate`
Evaluates submitted answers, calculates score percentage, and provides full explanations and citation links for every question.

#### Request Body
```json
{
  "quiz_id": "quiz_991827",
  "document_id": "doc_a1b2c3d4e5f6",
  "user_answers": {
    "1": "B"
  }
}
```

#### Response (`200 OK`)
```json
{
  "quiz_id": "quiz_991827",
  "score": 1,
  "total_questions": 1,
  "percentage": 100.0,
  "feedback": [
    {
      "question_id": 1,
      "user_answer": "B",
      "correct_answer": "B",
      "is_correct": true,
      "explanation": "According to page 4, the TLB caches recently resolved virtual-to-physical address mappings to avoid page table walks.",
      "citation": "operating_systems.pdf: page 4"
    }
  ]
}
```

---

## 8. Error Codes & Troubleshooting

| HTTP Status | Error Code | Description / Resolution |
| :--- | :--- | :--- |
| `400 Bad Request` | `EMPTY_DOCUMENT` | Uploaded document contains 0 bytes or no extractable text. |
| `400 Bad Request` | `SCANNED_DOCUMENT` | Document consists of blank or image-only scanned pages without OCR text. |
| `413 Payload Too Large` | `FILE_TOO_LARGE` | File exceeds `MAX_FILE_SIZE_BYTES` (25 MB). Compress or split document. |
| `415 Unsupported Media Type` | `INVALID_FILE_TYPE` | Extension or magic bytes mismatch allowed types (`.pdf`, `.txt`, `.md`). |
| `429 Too Many Requests` | `RATE_LIMIT_EXCEEDED` | Exceeded 120 requests/minute. Respect the `Retry-After` header. |
| `500 Internal Server Error` | `INTERNAL_SERVER_ERROR` | Server exception. Check `X-Request-ID` in server logs. |
