/**
 * VELTRIX SourceMind - Web Studio Frontend Application
 * High-Assurance Source-Grounded AI Research & Study Studio
 */

const app = {
  state: {
    documents: [],
    activeDocumentId: null, // null means "All Documents / Global RAG"
    activeDocumentDetail: null,
    currentInspectorPage: 1,
    activeTab: 'chat', // 'chat' | 'study' | 'quiz'
    studySubTab: 'summary', // 'summary' | 'notes' | 'revision'
    chatMessages: [],
    isStreaming: false,
    abortController: null,
    activeQuiz: null,
    quizUserAnswers: {},
    quizResult: null,
    healthInfo: null,
    lastGeneratedSummary: null,
    lastGeneratedNotes: null,
    lastGeneratedRevision: null,
  },

  async init() {
    this.setupEventListeners();
    await this.fetchHealth();
    await this.fetchDocuments();
    if (window.lucide) {
      window.lucide.createIcons();
    }
  },

  setupEventListeners() {
    // Tab Switching
    document.querySelectorAll('[data-tab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetTab = e.currentTarget.getAttribute('data-tab');
        this.switchTab(targetTab);
      });
    });

    // Study Sub-Tab Switching
    document.querySelectorAll('[data-study-subtab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const targetSubTab = e.currentTarget.getAttribute('data-study-subtab');
        this.switchStudySubTab(targetSubTab);
      });
    });

    // Drag and Drop Upload Zone
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-upload-input');

    if (dropZone && fileInput) {
      dropZone.addEventListener('click', () => fileInput.click());

      dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('border-indigo-500', 'bg-indigo-950/20');
      });

      dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-indigo-500', 'bg-indigo-950/20');
      });

      dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('border-indigo-500', 'bg-indigo-950/20');
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          this.uploadFile(e.dataTransfer.files[0]);
        }
      });

      fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
          this.uploadFile(e.target.files[0]);
        }
      });
    }

    // Chat Form Submit
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    if (chatForm && chatInput) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = chatInput.value.trim();
        if (text && !this.state.isStreaming) {
          chatInput.value = '';
          this.sendChatMessage(text);
        }
      });

      // Quick suggestions
      document.querySelectorAll('.prompt-suggestion').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const prompt = e.currentTarget.getAttribute('data-prompt');
          if (prompt && !this.state.isStreaming) {
            this.sendChatMessage(prompt);
          }
        });
      });
    }

    // Source Inspector Page Controls
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    if (prevPageBtn) prevPageBtn.addEventListener('click', () => this.changeInspectorPage(-1));
    if (nextPageBtn) nextPageBtn.addEventListener('click', () => this.changeInspectorPage(1));
  },

  async fetchHealth() {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        this.state.healthInfo = await res.json();
        const statusPill = document.getElementById('health-status-badge');
        const modelPill = document.getElementById('active-model-badge');
        if (statusPill) statusPill.textContent = 'Operational';
        if (modelPill) modelPill.textContent = this.state.healthInfo.generation_model || 'Gemini Flash';
      }
    } catch (e) {
      console.warn('Health check failed:', e);
    }
  },

  async fetchDocuments() {
    try {
      const res = await fetch('/api/documents');
      if (res.ok) {
        const data = await res.json();
        this.state.documents = data.documents || [];
        this.renderDocumentList();

        // If active document is not set and we have documents, select the first one
        if (!this.state.activeDocumentId && this.state.documents.length > 0) {
          await this.selectDocument(this.state.documents[0].document_id);
        } else if (this.state.activeDocumentId) {
          await this.loadDocumentDetail(this.state.activeDocumentId);
        } else {
          this.renderSourceInspector();
        }
      }
    } catch (e) {
      console.error('Failed to fetch documents:', e);
    }
  },

  renderDocumentList() {
    const container = document.getElementById('document-list-container');
    const globalBtn = document.getElementById('global-rag-btn');
    if (!container) return;

    if (globalBtn) {
      if (this.state.activeDocumentId === null) {
        globalBtn.className = 'w-full text-left px-3 py-2 rounded-lg bg-indigo-600/20 border border-indigo-500/40 text-indigo-200 text-xs font-medium flex items-center justify-between transition';
      } else {
        globalBtn.className = 'w-full text-left px-3 py-2 rounded-lg bg-slate-800/40 hover:bg-slate-800 border border-slate-700/40 text-slate-400 text-xs font-medium flex items-center justify-between transition';
      }
    }

    if (this.state.documents.length === 0) {
      container.innerHTML = `
        <div class="p-4 text-center text-slate-500 text-xs">
          No documents uploaded yet.<br>Drag and drop a PDF, Markdown, or text file above.
        </div>
      `;
      return;
    }

    container.innerHTML = this.state.documents.map(doc => {
      const isActive = this.state.activeDocumentId === doc.document_id;
      const isPdf = doc.filename.endsWith('.pdf');
      const icon = isPdf ? 'file-text' : 'file-code';
      const iconColor = isPdf ? 'text-rose-400' : 'text-blue-400';
      const activeClass = isActive
        ? 'bg-indigo-950/40 border-indigo-500/50 text-indigo-100 shadow-sm'
        : 'bg-slate-900/60 hover:bg-slate-800/60 border-slate-800 text-slate-300';

      return `
        <div class="group relative flex items-center justify-between p-2.5 rounded-lg border transition cursor-pointer ${activeClass}"
             onclick="app.selectDocument('${doc.document_id}')">
          <div class="flex items-center space-x-2.5 truncate">
            <i data-lucide="${icon}" class="w-4 h-4 ${iconColor} shrink-0"></i>
            <div class="truncate">
              <div class="text-xs font-medium truncate">${this.escapeHtml(doc.filename)}</div>
              <div class="text-[10px] text-slate-500 flex items-center space-x-2 mt-0.5">
                <span>${doc.page_count} ${doc.page_count === 1 ? 'page' : 'pages'}</span>
                <span>•</span>
                <span>${doc.chunk_count} chunks</span>
              </div>
            </div>
          </div>
          <button onclick="event.stopPropagation(); app.deleteDocument('${doc.document_id}', '${this.escapeHtml(doc.filename)}')"
                  title="Delete document"
                  class="opacity-0 group-hover:opacity-100 p-1 hover:text-rose-400 text-slate-500 rounded transition shrink-0">
            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
          </button>
        </div>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();
  },

  async selectDocument(docId) {
    this.state.activeDocumentId = docId;
    this.renderDocumentList();
    await this.loadDocumentDetail(docId);
    this.updateActiveScopeBadge();
  },

  selectGlobalRAG() {
    this.state.activeDocumentId = null;
    this.renderDocumentList();
    this.updateActiveScopeBadge();
    const inspectorContainer = document.getElementById('inspector-content');
    if (inspectorContainer) {
      inspectorContainer.innerHTML = `
        <div class="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500 text-xs">
          <i data-lucide="layers" class="w-8 h-8 text-indigo-400/50 mb-2"></i>
          <span class="font-medium text-slate-400">Global Knowledge Vault Mode</span>
          <span class="mt-1">Queries are retrieving across all ${this.state.documents.length} indexed documents. Select an individual document to inspect source pages.</span>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }
    const titleEl = document.getElementById('inspector-title');
    if (titleEl) titleEl.textContent = 'All Documents';
  },

  updateActiveScopeBadge() {
    const scopeBadge = document.getElementById('chat-scope-badge');
    if (!scopeBadge) return;
    if (this.state.activeDocumentId === null) {
      scopeBadge.innerHTML = `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-purple-500/10 text-purple-300 border border-purple-500/30"><i data-lucide="globe" class="w-3 h-3 mr-1"></i> Global Vault (${this.state.documents.length} docs)</span>`;
    } else {
      const doc = this.state.documents.find(d => d.document_id === this.state.activeDocumentId);
      const name = doc ? doc.filename : 'Document';
      scopeBadge.innerHTML = `<span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/30"><i data-lucide="file" class="w-3 h-3 mr-1"></i> ${this.escapeHtml(name)}</span>`;
    }
    if (window.lucide) window.lucide.createIcons();
  },

  async loadDocumentDetail(docId) {
    try {
      const res = await fetch(`/api/documents/${docId}`);
      if (res.ok) {
        this.state.activeDocumentDetail = await res.json();
        this.state.currentInspectorPage = 1;
        this.renderSourceInspector();
      }
    } catch (e) {
      console.error('Failed to load document details:', e);
    }
  },

  renderSourceInspector(highlightSnippet = null) {
    const titleEl = document.getElementById('inspector-title');
    const pageIndEl = document.getElementById('page-indicator');
    const contentEl = document.getElementById('inspector-content');

    if (!this.state.activeDocumentDetail) {
      if (titleEl) titleEl.textContent = 'No Document Selected';
      if (pageIndEl) pageIndEl.textContent = 'Page - of -';
      if (contentEl) {
        contentEl.innerHTML = `
          <div class="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500 text-xs">
            <i data-lucide="file-search" class="w-8 h-8 text-slate-600 mb-2"></i>
            <span>Upload or select a document to inspect original source pages.</span>
          </div>
        `;
        if (window.lucide) window.lucide.createIcons();
      }
      return;
    }

    const doc = this.state.activeDocumentDetail.document;
    const pages = this.state.activeDocumentDetail.pages || [];
    const totalPages = pages.length;

    if (titleEl) titleEl.textContent = doc.filename;
    if (pageIndEl) pageIndEl.textContent = `Page ${this.state.currentInspectorPage} of ${totalPages || 1}`;

    const currentPageObj = pages.find(p => p.page_number === this.state.currentInspectorPage);
    let pageText = currentPageObj ? currentPageObj.text : 'Page content not found.';

    // Apply snippet highlighting if requested
    if (highlightSnippet && highlightSnippet.length > 5) {
      const cleanSnippet = highlightSnippet.trim();
      const escapedSnippet = this.escapeHtml(cleanSnippet);
      const escapedPage = this.escapeHtml(pageText);

      // Look for a substring match
      const lowerSnippet = cleanSnippet.toLowerCase();
      const lowerPage = pageText.toLowerCase();
      const idx = lowerPage.indexOf(lowerSnippet);

      if (idx !== -1) {
        const before = this.escapeHtml(pageText.substring(0, idx));
        const matched = this.escapeHtml(pageText.substring(idx, idx + cleanSnippet.length));
        const after = this.escapeHtml(pageText.substring(idx + cleanSnippet.length));
        contentEl.innerHTML = `
          <div class="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap font-sans p-4 select-text">
            ${before}<mark id="active-citation-highlight" class="citation-highlight-pulse text-amber-200">${matched}</mark>${after}
          </div>
        `;
        // Scroll into view
        setTimeout(() => {
          const mark = document.getElementById('active-citation-highlight');
          if (mark) mark.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 100);
        return;
      }
    }

    if (contentEl) {
      contentEl.innerHTML = `
        <div class="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap font-sans p-4 select-text">
          ${this.escapeHtml(pageText)}
        </div>
      `;
    }
  },

  changeInspectorPage(delta) {
    if (!this.state.activeDocumentDetail) return;
    const totalPages = (this.state.activeDocumentDetail.pages || []).length;
    const newPage = this.state.currentInspectorPage + delta;
    if (newPage >= 1 && newPage <= totalPages) {
      this.state.currentInspectorPage = newPage;
      this.renderSourceInspector();
    }
  },

  async jumpToCitation(docName, pageNum, snippet = null) {
    // If not on the target doc, find it and select it
    if (!this.state.activeDocumentDetail || this.state.activeDocumentDetail.document.filename !== docName) {
      const matched = this.state.documents.find(d => d.filename === docName);
      if (matched) {
        await this.selectDocument(matched.document_id);
      }
    }
    this.state.currentInspectorPage = pageNum;
    this.renderSourceInspector(snippet);
  },

  async deleteDocument(docId, filename) {
    if (!confirm(`Are you sure you want to delete '${filename}'? This will permanently remove its embeddings and source files.`)) {
      return;
    }
    try {
      const res = await fetch(`/api/documents/${docId}`, { method: 'DELETE' });
      if (res.ok) {
        if (this.state.activeDocumentId === docId) {
          this.state.activeDocumentId = null;
          this.state.activeDocumentDetail = null;
        }
        await this.fetchDocuments();
      } else {
        alert('Failed to delete document.');
      }
    } catch (e) {
      console.error('Delete document error:', e);
    }
  },

  async uploadFile(file) {
    const uploadStatus = document.getElementById('upload-status');
    const uploadProgress = document.getElementById('upload-progress-bar');
    const uploadContainer = document.getElementById('upload-progress-container');

    if (uploadContainer) uploadContainer.classList.remove('hidden');
    if (uploadStatus) uploadStatus.textContent = `Validating & indexing '${file.name}'...`;
    if (uploadProgress) uploadProgress.style.width = '35%';

    const formData = new FormData();
    formData.append('file', file);

    try {
      if (uploadProgress) uploadProgress.style.width = '65%';
      const res = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData
      });

      if (uploadProgress) uploadProgress.style.width = '100%';

      if (res.ok) {
        const data = await res.json();
        if (uploadStatus) uploadStatus.textContent = `Indexed ${data.chunks_created} chunks!`;
        setTimeout(() => {
          if (uploadContainer) uploadContainer.classList.add('hidden');
          if (uploadProgress) uploadProgress.style.width = '0%';
        }, 1500);

        await this.fetchDocuments();
        if (data.document && data.document.document_id) {
          await this.selectDocument(data.document.document_id);
        }
      } else {
        const err = await res.json();
        const msg = err.detail && err.detail.message ? err.detail.message : 'Upload failed.';
        alert(`Upload Error: ${msg}`);
        if (uploadContainer) uploadContainer.classList.add('hidden');
      }
    } catch (e) {
      console.error('Upload error:', e);
      alert('Upload failed due to network or server error.');
      if (uploadContainer) uploadContainer.classList.add('hidden');
    }
  },

  // ----------------------------------------------------
  // Grounded Chat Execution & Streaming
  // ----------------------------------------------------
  async sendChatMessage(query) {
    this.state.isStreaming = true;
    this.state.abortController = new AbortController();

    // Append user message
    this.state.chatMessages.push({ role: 'user', content: query });
    this.renderChatMessages();

    // Prepare assistant message
    const assistantIndex = this.state.chatMessages.length;
    this.state.chatMessages.push({
      role: 'assistant',
      content: '',
      isStreaming: true,
      citations: [],
      grounding_fidelity_score: 1.0,
      has_matches: true
    });
    this.renderChatMessages();

    const payload = {
      query: query,
      document_id: this.state.activeDocumentId,
      conversation_history: this.state.chatMessages.slice(0, -2).map(m => ({
        role: m.role,
        content: m.content
      }))
    };

    try {
      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: this.state.abortController.signal
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (dataStr === '[DONE]') {
              break;
            }
            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.token) {
                accumulatedText += parsed.token;
                this.state.chatMessages[assistantIndex].content = accumulatedText;
                this.updateStreamingMessageContent(assistantIndex, accumulatedText);
              }
            } catch (e) {
              // Ignore partial JSON
            }
          }
        }
      }

      // Mark streaming done
      this.state.chatMessages[assistantIndex].isStreaming = false;

      // Also fetch verified citation audit report in background
      this.auditLastChatMessage(query, accumulatedText, assistantIndex);

    } catch (e) {
      if (e.name !== 'AbortError') {
        this.state.chatMessages[assistantIndex].content = `⚠️ An error occurred: ${e.message}`;
        this.state.chatMessages[assistantIndex].isStreaming = false;
      }
    } finally {
      this.state.isStreaming = false;
      this.renderChatMessages();
    }
  },

  async auditLastChatMessage(query, answerText, msgIndex) {
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          document_id: this.state.activeDocumentId
        })
      });
      if (res.ok) {
        const audit = await res.json();
        if (this.state.chatMessages[msgIndex]) {
          this.state.chatMessages[msgIndex].citations = audit.citations || [];
          this.state.chatMessages[msgIndex].grounding_fidelity_score = audit.grounding_fidelity_score;
          this.state.chatMessages[msgIndex].has_matches = audit.has_matches;
          this.state.chatMessages[msgIndex].has_hallucinated_citations = audit.has_hallucinated_citations;
          this.renderChatMessages();
        }
      }
    } catch (e) {
      console.warn('Citation audit error:', e);
    }
  },

  updateStreamingMessageContent(index, text) {
    const el = document.getElementById(`chat-msg-${index}`);
    if (el) {
      el.innerHTML = this.formatAnswerWithCitations(text, true);
    }
    const container = document.getElementById('chat-messages-container');
    if (container) container.scrollTop = container.scrollHeight;
  },

  renderChatMessages() {
    const container = document.getElementById('chat-messages-container');
    if (!container) return;

    if (this.state.chatMessages.length === 0) {
      container.innerHTML = `
        <div class="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
          <div class="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 mb-3 border border-indigo-500/20">
            <i data-lucide="sparkles" class="w-6 h-6"></i>
          </div>
          <h3 class="text-sm font-semibold text-slate-300">Grounded Research Assistant</h3>
          <p class="text-xs text-slate-400 max-w-sm mt-1">
            Every answer is verified against your uploaded source chunks. When information is absent, the system refuses rather than guessing.
          </p>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
      return;
    }

    container.innerHTML = this.state.chatMessages.map((msg, idx) => {
      if (msg.role === 'user') {
        return `
          <div class="flex justify-end mb-4">
            <div class="max-w-[80%] rounded-2xl rounded-tr-sm bg-indigo-600 px-4 py-2.5 text-xs text-white shadow">
              ${this.escapeHtml(msg.content)}
            </div>
          </div>
        `;
      } else {
        const isStreaming = msg.isStreaming;
        const fidelity = msg.grounding_fidelity_score || 1.0;
        const hasMatches = msg.has_matches !== false;

        let badgeHtml = '';
        if (!isStreaming) {
          if (!hasMatches) {
            badgeHtml = `
              <span class="inline-flex items-center text-[10px] font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                <i data-lucide="shield-alert" class="w-3 h-3 mr-1 text-slate-400"></i> Information Absent in Sources
              </span>
            `;
          } else if (msg.has_hallucinated_citations) {
            badgeHtml = `
              <span class="inline-flex items-center text-[10px] font-medium px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-600/40">
                <i data-lucide="alert-triangle" class="w-3 h-3 mr-1 text-amber-400"></i> Unverified Citation Flagged (${Math.round(fidelity * 100)}% verified)
              </span>
            `;
          } else {
            badgeHtml = `
              <span class="inline-flex items-center text-[10px] font-medium px-2 py-0.5 rounded bg-emerald-950/50 text-emerald-300 border border-emerald-500/30">
                <i data-lucide="shield-check" class="w-3 h-3 mr-1 text-emerald-400"></i> 100% Grounded in Sources
              </span>
            `;
          }
        }

        return `
          <div class="flex justify-start mb-6">
            <div class="max-w-[90%] rounded-2xl rounded-tl-sm glass-panel p-4 border border-slate-800 text-xs shadow-md">
              <div class="flex items-center justify-between mb-2">
                <div class="flex items-center space-x-2">
                  <div class="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-[10px] font-bold">V</div>
                  <span class="text-[11px] font-semibold text-slate-300">VELTRIX SourceMind</span>
                </div>
                <div>${badgeHtml}</div>
              </div>
              <div id="chat-msg-${idx}" class="markdown-body select-text ${isStreaming ? 'streaming-cursor' : ''}">
                ${this.formatAnswerWithCitations(msg.content, isStreaming)}
              </div>
            </div>
          </div>
        `;
      }
    }).join('');

    if (window.lucide) window.lucide.createIcons();
    container.scrollTop = container.scrollHeight;
  },

  formatAnswerWithCitations(rawText, isStreaming = false) {
    if (!rawText) return '';

    // Convert markdown to HTML first using marked.js
    let html = window.marked ? window.marked.parse(rawText) : this.escapeHtml(rawText);

    // If still streaming, don't replace incomplete tags
    if (isStreaming) {
      return html;
    }

    // Replace [[Source: Document.pdf, Page: 2]] with interactive citation pill
    const citationRegex = /\[\[Source:\s*([^,]+?),\s*Page:\s*(\d+)\]\]/g;
    html = html.replace(citationRegex, (match, docName, pageNum) => {
      const cleanDoc = docName.trim();
      const cleanPage = parseInt(pageNum.trim(), 10);
      return `
        <button onclick="app.jumpToCitation('${cleanDoc}', ${cleanPage})"
                title="Click to jump to ${cleanDoc} (Page ${cleanPage})"
                class="inline-flex items-center px-2 py-0.5 my-0.5 rounded-full text-[10px] font-medium bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-500/40 transition cursor-pointer shadow-sm">
          <i data-lucide="file-check" class="w-3 h-3 mr-1 text-emerald-400"></i>
          Page ${cleanPage}
        </button>
      `;
    });

    // Replace [Citation Unverified] with warning badge
    html = html.replace(/\[Citation Unverified\]/g, `
      <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-rose-950/60 text-rose-300 border border-rose-600/40">
        <i data-lucide="alert-circle" class="w-3 h-3 mr-1 text-rose-400"></i> Unverified
      </span>
    `);

    return html;
  },

  // ----------------------------------------------------
  // Study Studio Synthesis
  // ----------------------------------------------------
  async generateSummary(level = 'medium') {
    if (!this.state.activeDocumentId) {
      alert('Please select a specific document in the library to generate a summary.');
      return;
    }

    const outputEl = document.getElementById('study-summary-output');
    if (outputEl) {
      outputEl.innerHTML = `
        <div class="p-8 text-center text-slate-400 text-xs">
          <i data-lucide="loader-2" class="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2"></i>
          Synthesizing ${level} source-grounded summary...
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    try {
      const res = await fetch('/api/study/summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_id: this.state.activeDocumentId,
          level: level
        })
      });

      if (res.ok) {
        const data = await res.json();
        this.state.lastGeneratedSummary = data;
        this.renderSummaryResult(data);
      } else {
        const err = await res.json();
        outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">${err.detail || 'Summary generation failed.'}</div>`;
      }
    } catch (e) {
      console.error('Summary error:', e);
      outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">Failed to connect to summary engine.</div>`;
    }
  },

  renderSummaryResult(data) {
    const outputEl = document.getElementById('study-summary-output');
    if (!outputEl) return;

    const htmlContent = window.marked ? window.marked.parse(data.full_markdown) : this.escapeHtml(data.full_markdown);

    outputEl.innerHTML = `
      <div class="glass-panel rounded-xl p-5 border border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 class="text-sm font-semibold text-slate-200">${this.escapeHtml(data.title)}</h3>
            <span class="text-[11px] text-slate-500 uppercase tracking-wide font-medium">${data.level} Depth</span>
          </div>
          <button onclick="navigator.clipboard.writeText(app.state.lastGeneratedSummary.full_markdown); alert('Copied markdown to clipboard!');"
                  class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center space-x-1.5 transition">
            <i data-lucide="copy" class="w-3.5 h-3.5"></i>
            <span>Copy Markdown</span>
          </button>
        </div>
        <div class="markdown-body select-text">
          ${htmlContent}
        </div>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
  },

  async generateSmartNotes() {
    if (!this.state.activeDocumentId) {
      alert('Please select a specific document in the library to generate Smart Notes.');
      return;
    }

    const outputEl = document.getElementById('study-notes-output');
    if (outputEl) {
      outputEl.innerHTML = `
        <div class="p-8 text-center text-slate-400 text-xs">
          <i data-lucide="loader-2" class="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2"></i>
          Generating structured Smart Revision Notes...
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    try {
      const res = await fetch('/api/study/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ document_id: this.state.activeDocumentId })
      });

      if (res.ok) {
        const data = await res.json();
        this.state.lastGeneratedNotes = data;
        this.renderSmartNotesResult(data);
      } else {
        const err = await res.json();
        outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">${err.detail || 'Smart Notes generation failed.'}</div>`;
      }
    } catch (e) {
      console.error('Smart notes error:', e);
      outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">Failed to generate Smart Notes.</div>`;
    }
  },

  renderSmartNotesResult(data) {
    const outputEl = document.getElementById('study-notes-output');
    if (!outputEl) return;

    const htmlContent = window.marked ? window.marked.parse(data.full_markdown) : this.escapeHtml(data.full_markdown);

    outputEl.innerHTML = `
      <div class="glass-panel rounded-xl p-5 border border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 class="text-sm font-semibold text-slate-200">${this.escapeHtml(data.title)}</h3>
            <span class="text-[11px] text-slate-500 font-medium">Exam-Focused Revision Framework</span>
          </div>
          <button onclick="navigator.clipboard.writeText(app.state.lastGeneratedNotes.full_markdown); alert('Copied notes to clipboard!');"
                  class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center space-x-1.5 transition">
            <i data-lucide="copy" class="w-3.5 h-3.5"></i>
            <span>Copy Notes</span>
          </button>
        </div>
        <div class="markdown-body select-text">
          ${htmlContent}
        </div>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
  },

  async generateRevisionSheet() {
    if (!this.state.activeDocumentId) {
      alert('Please select a specific document in the library to generate a Revision Sheet.');
      return;
    }

    const outputEl = document.getElementById('study-revision-output');
    if (outputEl) {
      outputEl.innerHTML = `
        <div class="p-8 text-center text-slate-400 text-xs">
          <i data-lucide="loader-2" class="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2"></i>
          Synthesizing 1-minute high-yield cram sheet...
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    try {
      const res = await fetch('/api/study/revision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ document_id: this.state.activeDocumentId })
      });

      if (res.ok) {
        const data = await res.json();
        this.state.lastGeneratedRevision = data;
        this.renderRevisionSheetResult(data);
      } else {
        const err = await res.json();
        outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">${err.detail || 'Revision Sheet generation failed.'}</div>`;
      }
    } catch (e) {
      console.error('Revision sheet error:', e);
      outputEl.innerHTML = `<div class="p-4 text-rose-400 text-xs">Failed to generate Revision Sheet.</div>`;
    }
  },

  renderRevisionSheetResult(data) {
    const outputEl = document.getElementById('study-revision-output');
    if (!outputEl) return;

    const htmlContent = window.marked ? window.marked.parse(data.full_markdown) : this.escapeHtml(data.full_markdown);

    outputEl.innerHTML = `
      <div class="glass-panel rounded-xl p-5 border border-slate-800">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 class="text-sm font-semibold text-slate-200">${this.escapeHtml(data.title)}</h3>
            <span class="text-[11px] text-amber-400 font-medium">60-Second Active Recall Cram Sheet</span>
          </div>
          <button onclick="navigator.clipboard.writeText(app.state.lastGeneratedRevision.full_markdown); alert('Copied revision sheet to clipboard!');"
                  class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center space-x-1.5 transition">
            <i data-lucide="copy" class="w-3.5 h-3.5"></i>
            <span>Copy Cram Sheet</span>
          </button>
        </div>
        <div class="markdown-body select-text">
          ${htmlContent}
        </div>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
  },

  // ----------------------------------------------------
  // Interactive Quiz Runner
  // ----------------------------------------------------
  async generateQuiz() {
    if (!this.state.activeDocumentId) {
      alert('Please select a specific document to generate practice test questions.');
      return;
    }

    const countSelect = document.getElementById('quiz-count-select');
    const diffSelect = document.getElementById('quiz-diff-select');
    const numQuestions = countSelect ? parseInt(countSelect.value, 10) : 5;
    const difficulty = diffSelect ? diffSelect.value : 'medium';

    const container = document.getElementById('quiz-runner-container');
    if (container) {
      container.innerHTML = `
        <div class="p-10 text-center text-slate-400 text-xs">
          <i data-lucide="loader-2" class="w-8 h-8 animate-spin mx-auto text-indigo-400 mb-3"></i>
          <span>Generating ${numQuestions} grounded questions from '${this.escapeHtml(this.state.activeDocumentDetail.document.filename)}'...</span>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    try {
      const res = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          document_id: this.state.activeDocumentId,
          num_questions: numQuestions,
          difficulty: difficulty
        })
      });

      if (res.ok) {
        this.state.activeQuiz = await res.json();
        this.state.quizUserAnswers = {};
        this.state.quizResult = null;
        this.renderQuizQuestions();
      } else {
        const err = await res.json();
        container.innerHTML = `<div class="p-6 text-rose-400 text-xs">${err.detail || 'Failed to generate quiz.'}</div>`;
      }
    } catch (e) {
      console.error('Quiz error:', e);
      container.innerHTML = `<div class="p-6 text-rose-400 text-xs">Error communicating with quiz service.</div>`;
    }
  },

  selectQuizAnswer(questionId, optionLabel) {
    if (this.state.quizResult) return; // Prevent changing after submission
    this.state.quizUserAnswers[questionId] = optionLabel;
    this.renderQuizQuestions();
  },

  renderQuizQuestions() {
    const container = document.getElementById('quiz-runner-container');
    if (!container || !this.state.activeQuiz) return;

    const quiz = this.state.activeQuiz;
    const answers = this.state.quizUserAnswers;
    const result = this.state.quizResult;

    let resultBannerHtml = '';
    if (result) {
      const passColor = result.passed ? 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40' : 'text-rose-400 border-rose-500/40 bg-rose-950/40';
      resultBannerHtml = `
        <div class="mb-6 p-4 rounded-xl border ${passColor} flex items-center justify-between">
          <div>
            <div class="text-sm font-bold">${result.passed ? '🎉 Practice Test Passed!' : 'Needs Review'}</div>
            <div class="text-xs opacity-80 mt-0.5">Score: ${result.correct_count} / ${result.total_questions} (${result.score_percentage}%)</div>
          </div>
          <button onclick="app.state.quizResult = null; app.state.quizUserAnswers = {}; app.renderQuizQuestions();"
                  class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition">
            Retake Quiz
          </button>
        </div>
      `;
    }

    const questionsHtml = quiz.questions.map((q, idx) => {
      const selected = answers[q.question_id];
      const qResult = result ? result.question_results.find(r => r.question_id === q.question_id) : null;

      return `
        <div class="glass-panel rounded-xl p-5 mb-5 border border-slate-800">
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs font-semibold text-indigo-400">Question ${q.question_number} of ${quiz.total_questions}</span>
            <span class="text-[10px] uppercase font-medium tracking-wide px-2 py-0.5 rounded bg-slate-800 text-slate-400">${q.difficulty}</span>
          </div>
          <h4 class="text-xs font-medium text-slate-200 mb-4 leading-relaxed">${this.escapeHtml(q.question)}</h4>
          <div class="space-y-2">
            ${q.options.map(opt => {
              let optClass = 'border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-300';
              let indicator = '';

              if (result) {
                if (opt.label === q.correct_answer) {
                  optClass = 'border-emerald-500/60 bg-emerald-950/40 text-emerald-200 font-medium';
                  indicator = '<i data-lucide="check" class="w-4 h-4 text-emerald-400"></i>';
                } else if (opt.label === selected && !qResult.is_correct) {
                  optClass = 'border-rose-500/60 bg-rose-950/40 text-rose-200 line-through';
                  indicator = '<i data-lucide="x" class="w-4 h-4 text-rose-400"></i>';
                }
              } else if (selected === opt.label) {
                optClass = 'border-indigo-500 bg-indigo-950/40 text-indigo-100 font-medium';
              }

              return `
                <div onclick="app.selectQuizAnswer('${q.question_id}', '${opt.label}')"
                     class="flex items-center justify-between p-3 rounded-lg border text-xs cursor-pointer transition ${optClass}">
                  <div class="flex items-center space-x-3">
                    <span class="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-400">${opt.label}</span>
                    <span>${this.escapeHtml(opt.text)}</span>
                  </div>
                  <div>${indicator}</div>
                </div>
              `;
            }).join('')}
          </div>

          ${result ? `
            <div class="mt-4 pt-3 border-t border-slate-800/80 text-xs">
              <div class="text-slate-300 font-medium mb-1">Explanation:</div>
              <div class="text-slate-400 text-[11px] leading-relaxed">${this.escapeHtml(q.explanation)}</div>
              ${q.source_page ? `
                <div class="mt-2">
                  <button onclick="app.jumpToCitation('${this.escapeHtml(quiz.document_name)}', ${q.source_page})"
                          class="inline-flex items-center text-[11px] font-medium text-indigo-400 hover:text-indigo-300 transition">
                    <i data-lucide="file-search" class="w-3 h-3 mr-1"></i> Verify in Source (Page ${q.source_page})
                  </button>
                </div>
              ` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    const allAnswered = quiz.questions.every(q => answers[q.question_id]);
    const submitBtnHtml = !result ? `
      <div class="flex justify-end pt-2 pb-6">
        <button onclick="app.submitQuiz()"
                ${!allAnswered ? 'disabled' : ''}
                class="px-5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white shadow-md transition">
          Submit Answers & Grade
        </button>
      </div>
    ` : '';

    container.innerHTML = `
      ${resultBannerHtml}
      ${questionsHtml}
      ${submitBtnHtml}
    `;

    if (window.lucide) window.lucide.createIcons();
  },

  async submitQuiz() {
    if (!this.state.activeQuiz) return;
    try {
      const res = await fetch('/api/quiz/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quiz: this.state.activeQuiz,
          user_answers: this.state.quizUserAnswers
        })
      });

      if (res.ok) {
        this.state.quizResult = await res.json();
        this.renderQuizQuestions();
        const container = document.getElementById('quiz-runner-container');
        if (container) container.scrollTop = 0;
      } else {
        alert('Failed to evaluate quiz.');
      }
    } catch (e) {
      console.error('Submit quiz error:', e);
    }
  },

  // ----------------------------------------------------
  // UI Tabs & Utility Helpers
  // ----------------------------------------------------
  switchTab(tabName) {
    this.state.activeTab = tabName;
    document.querySelectorAll('[data-tab]').forEach(el => {
      const t = el.getAttribute('data-tab');
      if (t === tabName) {
        el.className = 'flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 text-white shadow transition';
      } else {
        el.className = 'flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition';
      }
    });

    ['chat', 'study', 'quiz'].forEach(t => {
      const view = document.getElementById(`view-${t}`);
      if (view) {
        if (t === tabName) view.classList.remove('hidden');
        else view.classList.add('hidden');
      }
    });

    if (window.lucide) window.lucide.createIcons();
  },

  switchStudySubTab(subTab) {
    this.state.studySubTab = subTab;
    document.querySelectorAll('[data-study-subtab]').forEach(el => {
      const st = el.getAttribute('data-study-subtab');
      if (st === subTab) {
        el.className = 'px-3 py-1 rounded-md text-xs font-semibold bg-slate-800 text-indigo-300 border border-indigo-500/30 transition';
      } else {
        el.className = 'px-3 py-1 rounded-md text-xs font-medium text-slate-400 hover:text-slate-200 transition';
      }
    });

    ['summary', 'notes', 'revision'].forEach(st => {
      const view = document.getElementById(`study-view-${st}`);
      if (view) {
        if (st === subTab) view.classList.remove('hidden');
        else view.classList.add('hidden');
      }
    });
  },

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
};

window.addEventListener('DOMContentLoaded', () => {
  app.init();
});
