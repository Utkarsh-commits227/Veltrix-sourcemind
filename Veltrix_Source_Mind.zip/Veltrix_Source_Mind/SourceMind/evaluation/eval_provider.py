"""
VELTRIX SourceMind - Deterministic Benchmark Embedding Provider
Provides offline, deterministic 768-dimensional unit embeddings with lexical-semantic
token frequency hashing for RAG benchmark evaluation without external API dependency.
"""

import hashlib
import math
import re
from typing import List

from backend.embeddings.base import BaseEmbeddingProvider

STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
    "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by",
    "can", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from",
    "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself",
    "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", "me", "more", "most",
    "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once", "only", "or", "other", "our",
    "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so", "some", "such", "than",
    "that", "the", "their", "theirs", "them", "themselves", "then", "there", "these", "they", "this",
    "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "were", "what", "when",
    "where", "which", "while", "who", "whom", "why", "with", "would", "you", "your", "yours"
}


class BenchmarkEmbeddingProvider(BaseEmbeddingProvider):
    """
    Deterministic semantic hash embedding provider.
    Maps significant tokens into a 768-dimensional vector space using
    stopword filtering and dual MD5/SHA256 feature hashing.
    Generates reproducible unit vectors where semantic overlap directly yields
    interpretable cosine similarity scores.
    """

    DIMENSION = 768
    MODEL_NAME = "benchmark-semantic-embedder"

    def __init__(self, dimension: int = 768):
        self._dimension = dimension

    def get_dimension(self) -> int:
        return self._dimension

    def get_model_name(self) -> str:
        return self.MODEL_NAME

    def _embed(self, text: str) -> List[float]:
        vec = [0.0] * self._dimension
        tokens = re.findall(r"\b[a-zA-Z0-9_\-]{2,}\b", text.lower())
        sig_tokens = [t for t in tokens if t not in STOPWORDS]

        if not sig_tokens:
            sig_tokens = tokens or ["empty"]

        for t in sig_tokens:
            h1 = int(hashlib.md5(t.encode("utf-8")).hexdigest(), 16) % self._dimension
            h2 = int(hashlib.sha256(t.encode("utf-8")).hexdigest()[:8], 16) % self._dimension
            vec[h1] += 1.0
            vec[h2] += 0.5

        # Normalize to unit length
        norm = math.sqrt(sum(x * x for x in vec))
        if norm == 0.0:
            norm = 1.0
        return [x / norm for x in vec]

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        return [self._embed(t) for t in texts]

    async def embed_query(self, query: str) -> List[float]:
        return self._embed(query)
