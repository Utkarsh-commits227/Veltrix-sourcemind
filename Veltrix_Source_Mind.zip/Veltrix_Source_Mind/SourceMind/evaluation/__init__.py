"""
VELTRIX SourceMind - RAG Evaluation & Benchmarking Package
"""
