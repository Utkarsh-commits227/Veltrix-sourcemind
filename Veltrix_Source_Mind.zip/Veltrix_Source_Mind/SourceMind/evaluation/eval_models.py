"""
VELTRIX SourceMind - RAG Evaluation Data Models
Defines Pydantic schemas for benchmark questions, query execution telemetry, and summary reports.
"""

from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class QuestionCategory(str, Enum):
    FACTUAL = "factual"            # Single-page direct factual recall
    SYNTHESIS = "synthesis"        # Multi-page / cross-section integration
    UNANSWERABLE = "unanswerable"  # Out-of-source question testing honest refusal


class BenchmarkQuestion(BaseModel):
    """Encapsulates a single evaluation test case."""
    id: str = Field(..., description="Unique benchmark query ID (e.g. 'q01')")
    category: QuestionCategory = Field(..., description="Evaluation category")
    question: str = Field(..., description="The query string submitted to the RAG system")
    expected_pages: List[int] = Field(default_factory=list, description="Ground truth page numbers containing answer")
    expected_keywords: List[str] = Field(default_factory=list, description="Key factual terms expected in response")
    reference_answer: Optional[str] = Field(default=None, description="Gold reference answer")
    should_refuse: bool = Field(default=False, description="True if query is out-of-scope and must be refused")


class QuestionEvaluationResult(BaseModel):
    """Detailed evaluation telemetry for a single benchmark question."""
    question_id: str
    category: QuestionCategory
    question: str
    retrieved_pages: List[int]
    expected_pages: List[int]
    context_recall_passed: bool
    refusal_passed: bool
    citations_valid: bool
    grounding_fidelity_score: float
    is_refusal: bool
    citations_count: int
    latency_ms: float
    answer_preview: str


class EvaluationReport(BaseModel):
    """Aggregated quantitative report for a full benchmark run."""
    benchmark_name: str = "VELTRIX SourceMind Golden Benchmark"
    document_name: str
    total_questions: int
    factual_count: int
    synthesis_count: int
    unanswerable_count: int
    context_recall_rate: float = Field(..., description="Percentage of answerable queries where relevant page was retrieved")
    refusal_accuracy_rate: float = Field(..., description="Percentage of unanswerable queries correctly refused with 0 citations")
    citation_validity_rate: float = Field(..., description="Percentage of citations with verified provenance")
    mean_grounding_fidelity: float = Field(..., description="Average grounding fidelity score (0.0 to 1.0)")
    avg_latency_ms: float
    p95_latency_ms: float
    all_tests_passed: bool
    results: List[QuestionEvaluationResult] = Field(default_factory=list)
