"""
VELTRIX SourceMind - Automated RAG Evaluation Benchmark Harness
Executes the golden 20-question benchmark dataset against the reference document,
calculates quantitative retrieval and generation metrics, and generates evaluation telemetry.
"""

import asyncio
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

from backend.core.config import settings
from backend.core.logging import logger
from backend.embeddings.service import embedding_service
from backend.generation.mock_generator import MockLLMGenerator
from backend.generation.prompts import STANDARD_REFUSAL_MESSAGE
from backend.services.chat_service import chat_service
from backend.services.document_registry import document_registry
from backend.services.ingestion_service import ingestion_service
from backend.vectorstore.service import vector_store_service
from evaluation.eval_models import (
    BenchmarkQuestion,
    QuestionCategory,
    QuestionEvaluationResult,
    EvaluationReport
)
from evaluation.eval_provider import BenchmarkEmbeddingProvider


class RAGEvaluationHarness:
    """
    Automated benchmark runner for VELTRIX SourceMind:
    - Measures Context Recall across single-page and cross-page synthesis questions
    - Verifies 100% Honest Refusal Accuracy on out-of-domain unanswerable queries
    - Audits Citation Validity and Grounding Fidelity
    - Tracks latency percentiles (Average and P95)
    """

    BENCHMARK_SIMILARITY_THRESHOLD = 0.18  # Calibrated for BenchmarkEmbeddingProvider

    def __init__(
        self,
        reference_doc_path: Optional[Path] = None,
        dataset_path: Optional[Path] = None,
        use_mock_llm: bool = True
    ):
        base_eval_dir = Path(__file__).resolve().parent
        self.reference_doc_path = reference_doc_path or (base_eval_dir / "reference_os_systems.md")
        self.dataset_path = dataset_path or (base_eval_dir / "benchmark_dataset.json")
        self.use_mock_llm = use_mock_llm
        self.provider = BenchmarkEmbeddingProvider()
        self.document_id: Optional[str] = None

    async def setup(self) -> None:
        """Configures embedding provider and indexes reference document into ChromaDB."""
        logger.info("Setting up RAG Evaluation Harness...")
        embedding_service.set_provider(self.provider)

        if self.use_mock_llm:
            chat_service.set_generator(MockLLMGenerator())

        # Ingest reference document
        content = self.reference_doc_path.read_bytes()
        filename = self.reference_doc_path.name

        extracted_doc, chunks = ingestion_service.ingest_and_chunk(
            filename=filename,
            content=content,
            save_to_disk=False
        )
        self.document_id = extracted_doc.document_id

        # Generate embeddings and index
        embeddings = await self.provider.embed_texts([c.content for c in chunks])
        await vector_store_service.index_chunks(chunks, embeddings)
        document_registry.register_document(extracted_doc, chunk_count=len(chunks))

        logger.info(
            f"Successfully indexed reference document '{filename}' "
            f"({extracted_doc.page_count} pages, {len(chunks)} chunks) [ID: {self.document_id}]."
        )

    def load_dataset(self) -> List[BenchmarkQuestion]:
        """Loads benchmark test cases from JSON dataset."""
        raw_json = json.loads(self.dataset_path.read_text(encoding="utf-8"))
        return [BenchmarkQuestion.model_validate(item) for item in raw_json]

    async def evaluate_question(self, q: BenchmarkQuestion) -> QuestionEvaluationResult:
        """Executes a single benchmark question through ChatService and audits metrics."""
        t0 = time.perf_counter()

        response = await chat_service.ask(
            query=q.question,
            document_id=self.document_id,
            top_k=5,
            min_similarity=self.BENCHMARK_SIMILARITY_THRESHOLD
        )
        latency_ms = round((time.perf_counter() - t0) * 1000.0, 2)

        # Extract retrieved page numbers from citations or retrieved chunks
        retrieved_pages = sorted(list(set(c["page_number"] for c in response.citations)))
        is_refusal = (
            STANDARD_REFUSAL_MESSAGE.lower() in response.answer.lower()
            or not response.has_matches
        )

        # Context Recall Evaluation:
        # For answerable queries, did we retrieve at least one of the expected ground truth pages?
        if q.category == QuestionCategory.UNANSWERABLE:
            context_recall_passed = True
            refusal_passed = is_refusal and len(response.citations) == 0
        else:
            context_recall_passed = any(p in q.expected_pages for p in retrieved_pages)
            refusal_passed = True  # Not applicable to answerable queries

        # Citation Validity: All citations must have verified provenance without hallucination
        citations_valid = not response.has_hallucinated_citations

        return QuestionEvaluationResult(
            question_id=q.id,
            category=q.category,
            question=q.question,
            retrieved_pages=retrieved_pages,
            expected_pages=q.expected_pages,
            context_recall_passed=context_recall_passed,
            refusal_passed=refusal_passed,
            citations_valid=citations_valid,
            grounding_fidelity_score=response.grounding_fidelity_score,
            is_refusal=is_refusal,
            citations_count=len(response.citations),
            latency_ms=latency_ms,
            answer_preview=response.answer[:120].replace("\n", " ") + "..."
        )

    async def run(self) -> EvaluationReport:
        """Runs the complete benchmark suite across all questions."""
        await self.setup()
        questions = self.load_dataset()
        results: List[QuestionEvaluationResult] = []

        logger.info(f"Running evaluation on {len(questions)} benchmark questions...")
        for q in questions:
            res = await self.evaluate_question(q)
            results.append(res)

        # Cleanup reference document from vector store
        if self.document_id:
            await document_registry.delete_document(self.document_id)

        # Calculate Aggregate Metrics
        factual_results = [r for r in results if r.category == QuestionCategory.FACTUAL]
        synthesis_results = [r for r in results if r.category == QuestionCategory.SYNTHESIS]
        unanswerable_results = [r for r in results if r.category == QuestionCategory.UNANSWERABLE]

        answerable_results = factual_results + synthesis_results
        recall_hits = sum(1 for r in answerable_results if r.context_recall_passed)
        context_recall_rate = round((recall_hits / len(answerable_results) * 100.0), 1) if answerable_results else 100.0

        refusal_hits = sum(1 for r in unanswerable_results if r.refusal_passed)
        refusal_accuracy_rate = round((refusal_hits / len(unanswerable_results) * 100.0), 1) if unanswerable_results else 100.0

        total_citations = sum(r.citations_count for r in results)
        valid_citations = sum(r.citations_count for r in results if r.citations_valid)
        citation_validity_rate = round((valid_citations / total_citations * 100.0), 1) if total_citations > 0 else 100.0

        mean_fidelity = round(sum(r.grounding_fidelity_score for r in results) / len(results), 3)

        latencies = [r.latency_ms for r in results]
        avg_latency = round(sum(latencies) / len(latencies), 1)
        sorted_latencies = sorted(latencies)
        p95_idx = int(len(sorted_latencies) * 0.95)
        p95_latency = sorted_latencies[min(p95_idx, len(sorted_latencies) - 1)]

        # Target thresholds: Recall >= 90%, Refusal == 100%, Citations == 100%
        all_passed = (
            context_recall_rate >= 90.0
            and refusal_accuracy_rate == 100.0
            and citation_validity_rate == 100.0
        )

        report = EvaluationReport(
            document_name=self.reference_doc_path.name,
            total_questions=len(questions),
            factual_count=len(factual_results),
            synthesis_count=len(synthesis_results),
            unanswerable_count=len(unanswerable_results),
            context_recall_rate=context_recall_rate,
            refusal_accuracy_rate=refusal_accuracy_rate,
            citation_validity_rate=citation_validity_rate,
            mean_grounding_fidelity=mean_fidelity,
            avg_latency_ms=avg_latency,
            p95_latency_ms=p95_latency,
            all_tests_passed=all_passed,
            results=results
        )

        # Persist report
        report_path = self.dataset_path.parent / "eval_report.json"
        report_path.write_text(json.dumps(report.model_dump(mode="json"), indent=2), encoding="utf-8")
        logger.info(f"Evaluation report saved to: {report_path}")

        return report

    @staticmethod
    def print_summary(report: EvaluationReport) -> None:
        """Formats and displays a clear console summary table."""
        print("\n" + "=" * 80)
        print("  VELTRIX SourceMind — Phase 10 Quantitative RAG Evaluation Benchmark")
        print("=" * 80)
        print(f"  Reference Document : {report.document_name}")
        print(f"  Total Questions    : {report.total_questions} (Factual: {report.factual_count}, Synthesis: {report.synthesis_count}, Unanswerable: {report.unanswerable_count})")
        print("-" * 80)
        print(f"  Context Recall Rate    : {report.context_recall_rate}% (Target: >= 90.0%) -> {'PASS' if report.context_recall_rate >= 90 else 'FAIL'}")
        print(f"  Refusal Accuracy Rate  : {report.refusal_accuracy_rate}% (Target: 100.0%) -> {'PASS' if report.refusal_accuracy_rate == 100 else 'FAIL'}")
        print(f"  Citation Validity Rate : {report.citation_validity_rate}% (Target: 100.0%) -> {'PASS' if report.citation_validity_rate == 100 else 'FAIL'}")
        print(f"  Mean Grounding Fidelity: {report.mean_grounding_fidelity} / 1.000")
        print(f"  Latency                : Avg={report.avg_latency_ms}ms | P95={report.p95_latency_ms}ms")
        print("-" * 80)
        print(f"  BENCHMARK VERDICT      : {'>>> OVERALL BENCHMARK PASSED <<<' if report.all_tests_passed else '>>> BENCHMARK FAILED <<<'}")
        print("=" * 80 + "\n")


async def main():
    harness = RAGEvaluationHarness()
    report = await harness.run()
    harness.print_summary(report)


if __name__ == "__main__":
    asyncio.run(main())
