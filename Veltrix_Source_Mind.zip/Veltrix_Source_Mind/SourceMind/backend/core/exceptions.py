"""
VELTRIX SourceMind - Standardized Exception Hierarchy
Defines clean, domain-specific exceptions for every subsystem in the RAG pipeline.
"""

from typing import Optional, Dict, Any


class SourceMindException(Exception):
    """Base exception for all VELTRIX SourceMind application errors."""
    default_message = "An unexpected error occurred in VELTRIX SourceMind."
    default_code = "INTERNAL_ERROR"

    def __init__(self, message: Optional[str] = None, code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        super().__init__(message or self.default_message)
        self.message = message or self.default_message
        self.code = code or self.default_code
        self.details = details or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "details": self.details
            }
        }


# =====================================================================
# Ingestion & Validation Exceptions
# =====================================================================

class IngestionError(SourceMindException):
    """Base exception for ingestion pipeline failures."""
    default_message = "Failed to process and ingest document."
    default_code = "INGESTION_ERROR"


class ValidationError(IngestionError):
    """Raised when document format, size, or metadata fails validation."""
    default_message = "Document validation failed."
    default_code = "VALIDATION_ERROR"


class FileTooLargeError(ValidationError):
    """Raised when uploaded file exceeds MAX_FILE_SIZE_BYTES."""
    default_message = "Uploaded file exceeds maximum allowed size limit."
    default_code = "FILE_TOO_LARGE"


class UnsupportedFileError(ValidationError):
    """Raised when uploaded file format is not supported."""
    default_message = "File type is not supported. Please upload a PDF, TXT, or Markdown document."
    default_code = "UNSUPPORTED_FILE_TYPE"


class CorruptedFileError(IngestionError):
    """Raised when file structure is malformed, unreadable, or password-protected."""
    default_message = "The file appears to be corrupted or password-protected and cannot be read."
    default_code = "CORRUPTED_FILE"


class EmptyDocumentError(IngestionError):
    """Raised when document contains zero extractable text."""
    default_message = "The document is empty and contains no readable text."
    default_code = "EMPTY_DOCUMENT"


class ScannedDocumentError(IngestionError):
    """Raised when a PDF contains raster images but no digital text layer."""
    default_message = "This PDF appears to be a scanned image without an embedded digital text layer. OCR capability is required."
    default_code = "SCANNED_DOCUMENT"


class ExtractionError(IngestionError):
    """Raised when parsing or text extraction encounters an unexpected error."""
    default_message = "Failed to extract text from document."
    default_code = "EXTRACTION_ERROR"


# =====================================================================
# RAG Pipeline Exceptions (Chunking, Embedding, Vector DB, Generation)
# =====================================================================

class ChunkingError(SourceMindException):
    """Raised when chunking algorithm fails."""
    default_message = "Failed to chunk document into semantic segments."
    default_code = "CHUNKING_ERROR"


class EmbeddingError(SourceMindException):
    """Raised when embedding provider fails, times out, or rate limits."""
    default_message = "Embedding generation failed."
    default_code = "EMBEDDING_ERROR"


class VectorStoreError(SourceMindException):
    """Raised when vector database indexing or search fails."""
    default_message = "Vector database operation failed."
    default_code = "VECTORSTORE_ERROR"


class RetrievalError(SourceMindException):
    """Raised when context retrieval encounters an error."""
    default_message = "Failed to retrieve relevant context chunks."
    default_code = "RETRIEVAL_ERROR"


class GenerationError(SourceMindException):
    """Raised when the generative AI model fails or times out."""
    default_message = "Generative model failed to produce a grounded response."
    default_code = "GENERATION_ERROR"
