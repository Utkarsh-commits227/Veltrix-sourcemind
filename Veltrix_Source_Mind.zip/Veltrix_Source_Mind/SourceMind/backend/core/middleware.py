"""
VELTRIX SourceMind - HTTP Observability & Security Middleware
Implements distributed request tracing (X-Request-ID), latency telemetry (X-Process-Time-Ms),
and IP-based rate limiting.
"""

import time
import uuid
from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse

from backend.core.config import settings
from backend.core.logging import logger
from backend.core.rate_limiter import rate_limiter


class RequestTracingMiddleware(BaseHTTPMiddleware):
    """
    Assigns or reflects an X-Request-ID for every HTTP transaction.
    Measures processing duration and attaches X-Process-Time-Ms to response headers.
    Logs structured telemetry for API observability.
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Step 1: Extract or generate unique Request ID
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request.state.request_id = request_id

        # Step 2: Measure execution duration
        start_time = time.perf_counter()
        
        try:
            response = await call_next(request)
        except Exception as exc:
            duration_ms = round((time.perf_counter() - start_time) * 1000.0, 2)
            logger.error(
                f"[REQ_FAIL] ID={request_id} {request.method} {request.url.path} "
                f"Duration={duration_ms}ms Error={type(exc).__name__}: {str(exc)}"
            )
            raise exc

        duration_ms = round((time.perf_counter() - start_time) * 1000.0, 2)

        # Step 3: Attach telemetry headers
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time-Ms"] = str(duration_ms)

        # Step 4: Structured telemetry log for API requests
        if request.url.path.startswith("/api"):
            logger.info(
                f"[REQ_DONE] ID={request_id} {request.method} {request.url.path} "
                f"Status={response.status_code} Duration={duration_ms}ms"
            )

        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Enforces in-memory sliding window rate limits on client requests.
    Exempts static assets, documentation, and health check probes.
    """

    EXEMPT_PREFIXES = ("/static", "/docs", "/redoc", "/openapi.json", "/api/health")

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if not settings.ENABLE_RATE_LIMITER:
            return await call_next(request)

        # Skip rate limiting for static assets and health probes
        path = request.url.path
        if path == "/" or any(path.startswith(prefix) for prefix in self.EXEMPT_PREFIXES):
            return await call_next(request)

        # Resolve client IP (support reverse proxies via X-Forwarded-For)
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            client_ip = forwarded_for.split(",")[0].strip()
        elif request.client and request.client.host:
            client_ip = request.client.host
        else:
            client_ip = "127.0.0.1"

        allowed, remaining, retry_after = rate_limiter.check_rate_limit(client_ip)

        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "error": {
                        "code": "RATE_LIMIT_EXCEEDED",
                        "message": "Too many requests. Please slow down and try again.",
                        "details": {"retry_after_seconds": retry_after}
                    }
                },
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit": str(rate_limiter.requests_per_minute),
                    "X-RateLimit-Remaining": "0"
                }
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(rate_limiter.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response
