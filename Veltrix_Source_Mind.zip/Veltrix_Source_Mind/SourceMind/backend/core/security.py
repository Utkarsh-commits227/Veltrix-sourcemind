"""
VELTRIX SourceMind - Security & Sanitization Utilities
Handles path traversal prevention, magic byte verification, and content hashing.
"""

import hashlib
import re
from pathlib import Path
from typing import Tuple


def sanitize_filename(filename: str) -> str:
    """
    Sanitizes a user-provided filename to prevent path traversal attacks (e.g., ../../secret.txt).
    Strips directory separators, spaces, and dangerous characters.
    """
    # Extract only the base name
    base_name = Path(filename).name
    # Strip any characters that are not alphanumeric, dash, underscore, or period
    clean_name = re.sub(r'[^a-zA-Z0-9_\-\.]', '_', base_name)
    # Avoid empty names or leading dots
    clean_name = clean_name.lstrip('.')
    if not clean_name:
        clean_name = "unnamed_document"
    return clean_name


def compute_sha256(content: bytes) -> str:
    """Computes SHA-256 fingerprint for data integrity and deduplication."""
    hasher = hashlib.sha256()
    hasher.update(content)
    return hasher.hexdigest()


def detect_file_signature(content: bytes) -> Tuple[str, str]:
    """
    Inspects magic bytes at the beginning of the file to determine true MIME type.
    Protects against disguised extensions (e.g., malware.exe renamed to paper.pdf).
    
    Returns: (detected_extension, detected_mime_type)
    """
    if len(content) == 0:
        return ("", "application/x-empty")

    # PDF Magic Bytes: %PDF- (0x25 0x50 0x44 0x46 0x2D)
    if content.startswith(b'%PDF-'):
        return (".pdf", "application/pdf")

    # Check for text/plain or markdown (attempt UTF-8 / ASCII decode)
    try:
        sample = content[:4096].decode('utf-8')
        # Check if text contains null bytes (binary file check)
        if '\x00' in sample:
            return ("", "application/octet-stream")
        return (".txt", "text/plain")
    except UnicodeDecodeError:
        # Check for Latin-1 or other common text encodings
        try:
            sample = content[:4096].decode('latin-1')
            if '\x00' in sample:
                return ("", "application/octet-stream")
            return (".txt", "text/plain")
        except Exception:
            return ("", "application/octet-stream")


# Patterns that attempt to escape prompt packaging or hijack LLM execution
ADVERSARIAL_PATTERNS = [
    r"(?i)\bSYSTEM\s+OVERRIDE\s*:",
    r"(?i)\bIGNORE\s+ALL\s+(?:PREVIOUS\s+|PRIOR\s+)?INSTRUCTIONS\b",
    r"(?i)\bDISREGARD\s+(?:ALL\s+)?(?:PRIOR\s+|PREVIOUS\s+)?(?:SYSTEM\s+)?RULES\b",
    r"(?i)\bREVEAL\s+(?:YOUR\s+)?(?:SYSTEM\s+)?PROMPT\b",
    r"(?i)\bYOU\s+ARE\s+NOW\s+(?:AN?\s+)?(?:UNRESTRICTED|DAN|JAILBROKEN)\b",
    r"(?i)\bADMINISTRATIVE\s+(?:OVERRIDE|COMMAND)\s*:",
]

DELIMITER_TAGS = [
    (r"</source_context>", "&lt;/source_context&gt;"),
    (r"<source_context>", "&lt;source_context&gt;"),
    (r"</chunk>", "&lt;/chunk&gt;"),
    (r"<chunk\b", "&lt;chunk"),
    (r"</untrusted_source_content>", "&lt;/untrusted_source_content&gt;"),
    (r"<untrusted_source_content>", "&lt;untrusted_source_content&gt;"),
]


def sanitize_prompt_injection(text: str) -> str:
    """
    Sanitizes untrusted text extracted from user documents before XML context assembly.
    1. Escapes delimiter tags that could break out of the <source_context> envelope.
    2. Neutralizes active prompt injection commands into inert labels.
    """
    if not text:
        return ""

    sanitized = text

    # Step 1: Escape XML envelope tags
    for tag_pattern, replacement in DELIMITER_TAGS:
        sanitized = re.sub(tag_pattern, replacement, sanitized, flags=re.IGNORECASE)

    # Step 2: Neutralize adversarial injection strings
    for pattern in ADVERSARIAL_PATTERNS:
        sanitized = re.sub(pattern, "[ADVERSARIAL_INSTRUCTION_NEUTRALIZED]", sanitized)

    return sanitized


def check_prompt_leak(response: str, canary_token: str = "CANARY_SECURE_VELTRIX_9918") -> bool:
    """
    Audits generated model output for canary token leaks or system prompt reflection.
    Returns True if an adversarial information leak is detected.
    """
    if not response:
        return False
    if canary_token and canary_token in response:
        return True
    return False
