"""
VELTRIX SourceMind - Observability & Logging
Configures standardized, structured logging across backend services.
"""

import sys
import logging
from typing import Optional


def setup_logger(name: str = "sourcemind", level: Optional[int] = None) -> logging.Logger:
    """
    Creates and configures a standard logger with a clean, readable format.
    Avoids duplicate handlers across re-imports.
    """
    logger = logging.getLogger(name)
    if level is None:
        level = logging.DEBUG
    logger.setLevel(level)

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        formatter = logging.Formatter(
            fmt="[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


logger = setup_logger("sourcemind")
