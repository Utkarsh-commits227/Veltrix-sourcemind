"""
VELTRIX SourceMind - In-Memory Sliding Window Rate Limiter
Prevents API abuse and denial-of-service through thread-safe IP-based throttling.
"""

import math
import threading
import time
from collections import defaultdict
from typing import Dict, List, Tuple

from backend.core.config import settings
from backend.core.logging import logger


class SlidingWindowRateLimiter:
    """
    Thread-safe in-memory sliding window rate limiter.
    Tracks timestamps of requests per client IP across a 60-second window.
    """

    def __init__(self, requests_per_minute: int = 120):
        self.requests_per_minute = requests_per_minute
        self._requests: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def set_rate_limit(self, requests_per_minute: int) -> None:
        """Dynamically adjusts the allowed request quota."""
        with self._lock:
            self.requests_per_minute = requests_per_minute

    def check_rate_limit(self, client_ip: str) -> Tuple[bool, int, int]:
        """
        Audits request rate for a given client IP.
        Returns:
            (allowed: bool, remaining_quota: int, retry_after_seconds: int)
        """
        now = time.time()
        window = 60.0  # 60 seconds rolling window

        with self._lock:
            timestamps = self._requests[client_ip]
            # Prune timestamps outside current 60s sliding window
            cutoff = now - window
            valid_timestamps = [t for t in timestamps if t > cutoff]
            self._requests[client_ip] = valid_timestamps

            if len(valid_timestamps) >= self.requests_per_minute:
                # Quota exhausted: oldest timestamp defines when next slot opens
                oldest = valid_timestamps[0]
                retry_after = max(1, int(math.ceil(oldest + window - now)))
                logger.warning(
                    f"Rate limit exceeded for IP '{client_ip}'. "
                    f"Limit: {self.requests_per_minute}/min. Retry-After: {retry_after}s."
                )
                return False, 0, retry_after

            # Allow request and log timestamp
            valid_timestamps.append(now)
            remaining = self.requests_per_minute - len(valid_timestamps)
            return True, remaining, 0

    def reset(self) -> None:
        """Clears all stored rate limit records (useful for testing)."""
        with self._lock:
            self._requests.clear()


# Global singleton instance of rate limiter
rate_limiter = SlidingWindowRateLimiter(requests_per_minute=settings.RATE_LIMIT_PER_MINUTE)
