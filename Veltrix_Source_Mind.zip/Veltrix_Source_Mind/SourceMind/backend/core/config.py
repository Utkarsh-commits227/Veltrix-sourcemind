"""
VELTRIX SourceMind - Core Configuration Module
Defines application-wide settings, environment variables, and operational thresholds.
"""

from pathlib import Path
from typing import List, Set
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Central application configuration loaded from environment variables and .env file.
    Follows 12-factor application methodology.
    """
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    # Application Identity
    APP_NAME: str = "VELTRIX SourceMind"
    APP_VERSION: str = "0.1.0"
    ENVIRONMENT: str = Field(default="development", description="development | staging | production")
    DEBUG: bool = True

    # Storage Paths
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent
    DATA_DIR: Path = BASE_DIR / "data"
    UPLOAD_DIR: Path = DATA_DIR / "uploads"
    CHROMA_PERSIST_DIR: Path = DATA_DIR / "chromadb"
    SQLITE_DB_PATH: Path = DATA_DIR / "sourcemind.db"

    # Ingestion Constraints & Security
    MAX_FILE_SIZE_BYTES: int = 25 * 1024 * 1024  # 25 Megabytes
    ALLOWED_EXTENSIONS: Set[str] = {".pdf", ".txt", ".md"}
    ALLOWED_MIME_TYPES: Set[str] = {
        "application/pdf",
        "text/plain",
        "text/markdown",
        "application/octet-stream"  # For raw text streams when mime sniffing is ambiguous
    }

    # Minimum character count to classify a page as having text (vs scanned image)
    MIN_PAGE_CHAR_COUNT: int = 20

    # API Keys (Loaded from environment)
    GEMINI_API_KEY: str = Field(default="", description="Google Gemini API Key")
    OPENAI_API_KEY: str = Field(default="", description="Optional OpenAI Fallback API Key")

    # Embedding Settings
    EMBEDDING_PROVIDER: str = Field(default="gemini", description="gemini | openai | local")
    EMBEDDING_MODEL: str = "text-embedding-004"
    EMBEDDING_BATCH_SIZE: int = 32

    # Vector Store
    CHROMA_COLLECTION_NAME: str = "sourcemind_knowledge_vault"
    DEFAULT_TOP_K: int = 5
    SIMILARITY_THRESHOLD: float = 0.65  # Filter out noise chunks below 65% cosine similarity

    # LLM Generation
    GENERATION_MODEL: str = "gemini-2.0-flash"
    GENERATION_TEMPERATURE: float = 0.1  # Strict grounding, minimal creative hallucination

    # Security & Rate Limiting Guardrails
    RATE_LIMIT_PER_MINUTE: int = Field(default=120, description="Max allowed requests per minute per IP")
    ENABLE_RATE_LIMITER: bool = Field(default=True, description="Enforce IP-based rate limiting")
    CANARY_TOKEN: str = "CANARY_SECURE_VELTRIX_9918"

    def ensure_directories(self) -> None:
        """Ensures all necessary local storage directories exist."""
        self.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        self.CHROMA_PERSIST_DIR.mkdir(parents=True, exist_ok=True)


# Global singleton instance of configuration
settings = Settings()
settings.ensure_directories()
