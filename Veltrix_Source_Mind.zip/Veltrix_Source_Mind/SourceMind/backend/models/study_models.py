"""
VELTRIX SourceMind - Study Suite Data Models
Defines Pydantic schemas for Summaries, Smart Notes, and Revision Sheets.
"""

from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class SummaryLevel(str, Enum):
    SHORT = "short"        # Executive 1-2 paragraph overview
    MEDIUM = "medium"      # Analytical 3-5 paragraph breakdown with bullet takeaways
    DETAILED = "detailed"  # Comprehensive section-by-section analytical summary


class DocumentSummary(BaseModel):
    """Encapsulates a source-grounded summary output."""
    document_id: str
    document_name: str
    level: SummaryLevel
    title: str
    overview: str
    key_takeaways: List[str] = Field(default_factory=list)
    full_markdown: str


class ConceptDefinition(BaseModel):
    term: str
    definition: str
    page_number: Optional[int] = None


class SmartNotes(BaseModel):
    """Encapsulates dedicated, structured Smart Notes generated from a source document."""
    document_id: str
    document_name: str
    title: str
    overview: str
    key_concepts: List[Dict[str, str]] = Field(default_factory=list)
    important_points: List[str] = Field(default_factory=list)
    definitions: List[ConceptDefinition] = Field(default_factory=list)
    processes_and_mechanisms: List[Dict[str, str]] = Field(default_factory=list)
    exam_oriented_points: List[str] = Field(default_factory=list)
    quick_revision: str
    full_markdown: str


class ConfusionClarification(BaseModel):
    confusion: str
    clarification: str


class QuickReviewQA(BaseModel):
    question: str
    answer: str


class RevisionSheet(BaseModel):
    """Encapsulates a high-yield, 1-minute cram sheet for rapid review."""
    document_id: str
    document_name: str
    title: str
    must_remember: List[str] = Field(default_factory=list)
    key_definitions: List[ConceptDefinition] = Field(default_factory=list)
    common_confusions: List[ConfusionClarification] = Field(default_factory=list)
    quick_questions: List[QuickReviewQA] = Field(default_factory=list)
    one_minute_summary: str
    full_markdown: str
