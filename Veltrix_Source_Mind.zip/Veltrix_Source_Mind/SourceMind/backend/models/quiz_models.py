"""
VELTRIX SourceMind - Quiz & Practice Test Data Models
Defines Pydantic models for interactive quiz generation, distractor options, and automated grading.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class DifficultyLevel(str, Enum):
    EASY = "easy"        # Direct factual recall & explicit definitions
    MEDIUM = "medium"    # Conceptual comprehension & cause-effect relationships
    HARD = "hard"        # Multi-factor analysis & application scenarios


class QuestionType(str, Enum):
    MULTIPLE_CHOICE = "multiple_choice"
    TRUE_FALSE = "true_false"
    CONCEPTUAL = "conceptual"
    SHORT_ANSWER = "short_answer"


class QuizOption(BaseModel):
    """An option choice in a multiple choice or true/false question."""
    label: str = Field(..., description="Option letter: 'A', 'B', 'C', or 'D'")
    text: str = Field(..., description="The option text statement")


class QuizQuestion(BaseModel):
    """A single source-grounded quiz question with options, verified answer, and explanation."""
    question_id: str = Field(..., description="Unique question UUID")
    question_number: int = Field(..., description="1-indexed sequence number")
    question_type: QuestionType = Field(default=QuestionType.MULTIPLE_CHOICE)
    difficulty: DifficultyLevel = Field(default=DifficultyLevel.MEDIUM)
    question: str = Field(..., description="The question text")
    options: List[QuizOption] = Field(default_factory=list, description="4 options (A, B, C, D) for MCQs")
    correct_answer: str = Field(..., description="The label of the correct option (e.g. 'A') or True/False answer")
    explanation: str = Field(..., description="Source-grounded explanation why this answer is correct")
    source_page: Optional[int] = Field(default=None, description="Page number where the answer is verified")
    source_quote: Optional[str] = Field(default=None, description="Exact passage quote supporting the answer")


class Quiz(BaseModel):
    """A complete practice test generated from a source document."""
    quiz_id: str = Field(..., description="Unique practice quiz UUID")
    document_id: str = Field(..., description="Parent document UUID")
    document_name: str = Field(..., description="Source document filename")
    title: str = Field(..., description="Title of the practice test")
    total_questions: int = Field(..., description="Count of questions in quiz")
    difficulty: DifficultyLevel = Field(default=DifficultyLevel.MEDIUM)
    questions: List[QuizQuestion] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class QuestionResult(BaseModel):
    """Grading result for a single quiz question."""
    question_id: str
    question_number: int
    question: str
    user_answer: str
    correct_answer: str
    is_correct: bool
    explanation: str
    source_page: Optional[int] = None


class QuizEvaluationResult(BaseModel):
    """Comprehensive evaluation and grading report for a submitted quiz."""
    quiz_id: str
    total_questions: int
    correct_count: int
    incorrect_count: int
    score_percentage: float
    passed: bool
    question_results: List[QuestionResult]
    completed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
