"""
VELTRIX SourceMind - Central Retriever Engine
Coordinates query vectorization, similarity search, threshold gating, and context assembly.
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

from backend.core.config import settings
from backend.core.exceptions import RetrievalError
from backend.core.logging import logger
from backend.embeddings.service import EmbeddingService, embedding_service
from backend.retrieval.context_assembler import ContextAssembler, AssembledContext
from backend.vectorstore.base import VectorSearchResult
from backend.vectorstore.service import VectorStoreService, vector_store_service


class RetrievalPackage(BaseModel):
    """Encapsulates the complete result of a retrieval operation."""
    query: str = Field(..., description="Original user query")
    has_matches: bool = Field(..., description="True if at least one chunk exceeded similarity threshold")
    assembled_context: AssembledContext = Field(..., description="Packaged XML context for LLM prompt")
    top_chunks: List[VectorSearchResult] = Field(default_factory=list, description="Ordered matching chunks")
    top_similarity: float = Field(default=0.0, description="Highest similarity score among retrieved chunks")


class Retriever:
    """
    Executes semantic search across the vector store.
    Enforces document isolation and similarity threshold filtering.
    """

    def __init__(
        self,
        embedder: Optional[EmbeddingService] = None,
        store_service: Optional[VectorStoreService] = None
    ):
        self.embedder = embedder or embedding_service
        self.store_service = store_service or vector_store_service

    async def retrieve(
        self,
        query: str,
        document_id: Optional[str] = None,
        top_k: Optional[int] = None,
        min_similarity: Optional[float] = None
    ) -> RetrievalPackage:
        """
        Executes end-to-end retrieval:
        1. Validates query
        2. Embeds query into vector space
        3. Queries vector database (with document isolation and threshold filtering)
        4. Detects empty/insufficient matches
        5. Packages context for LLM generation
        """
        clean_query = query.strip()
        if not clean_query:
            raise RetrievalError("Search query cannot be empty.")

        k = top_k or settings.DEFAULT_TOP_K
        threshold = min_similarity if min_similarity is not None else settings.SIMILARITY_THRESHOLD

        logger.info(
            f"Executing retrieval for query='{clean_query[:60]}...' "
            f"[doc_id={document_id}, top_k={k}, min_similarity={threshold}]"
        )

        # Step 1: Embed query vector
        query_vector = await self.embedder.embed_query(clean_query)

        # Step 2: Vector similarity search
        search_results = await self.store_service.search(
            query_embedding=query_vector,
            top_k=k,
            document_id=document_id,
            min_similarity=threshold
        )

        # Step 3: Check match quality
        has_matches = len(search_results) > 0
        top_similarity = search_results[0].similarity_score if has_matches else 0.0

        if not has_matches:
            logger.warning(
                f"No chunks exceeded similarity threshold {threshold} for query='{clean_query[:50]}'. "
                f"Flagging EMPTY_RETRIEVAL state."
            )

        # Step 4: Assemble structured context
        assembled = ContextAssembler.assemble(search_results)

        return RetrievalPackage(
            query=clean_query,
            has_matches=has_matches,
            assembled_context=assembled,
            top_chunks=search_results,
            top_similarity=top_similarity
        )


# Global singleton instance of Retriever
retriever = Retriever()
