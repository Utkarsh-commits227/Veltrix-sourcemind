"""
VELTRIX SourceMind - Context Assembly Engine
Formats retrieved vector search results into structured, prompt-ready XML envelopes
with metadata, token budgeting, and boundary sanitization.
"""

from typing import List, Dict, Any, Tuple
from pydantic import BaseModel, Field

from backend.core.security import sanitize_prompt_injection
from backend.vectorstore.base import VectorSearchResult


class AssembledContext(BaseModel):
    """Encapsulates packaged context, token metrics, and chunk references."""
    formatted_context: str = Field(..., description="XML-delimited prompt string containing source chunks")
    chunk_count: int = Field(..., description="Number of chunks included in context")
    total_characters: int = Field(..., description="Total character count of assembled context")
    estimated_tokens: int = Field(..., description="Estimated token count")
    referenced_chunks: List[VectorSearchResult] = Field(default_factory=list, description="Raw chunk objects")


class ContextAssembler:
    """
    Constructs an untrusted data envelope containing retrieved chunks.
    Ensures clear chunk boundaries, page number attribution, and token budget compliance.
    """

    # Maximum characters allowed for context injection to protect LLM context limits (~16,000 chars ~= 4,000 tokens)
    DEFAULT_MAX_CONTEXT_CHARS = 16000

    @staticmethod
    def _sanitize_chunk_content(text: str) -> str:
        """
        Prevents prompt injection breakouts by escaping XML-like closing tags
        and neutralizing active injection commands in untrusted document text.
        """
        if not text:
            return ""
        return sanitize_prompt_injection(text).strip()

    @classmethod
    def assemble(
        cls,
        chunks: List[VectorSearchResult],
        max_chars: int = DEFAULT_MAX_CONTEXT_CHARS
    ) -> AssembledContext:
        """
        Packages a list of VectorSearchResult objects into an XML envelope:
        <source_context>
          <chunk id="..." page="..." document="...">
            ... text ...
          </chunk>
        </source_context>
        """
        if not chunks:
            return AssembledContext(
                formatted_context="<source_context>\n  <!-- No relevant chunks found in source documents -->\n</source_context>",
                chunk_count=0,
                total_characters=0,
                estimated_tokens=0,
                referenced_chunks=[]
            )

        context_lines: List[str] = ["<source_context>"]
        current_chars = len(context_lines[0])
        accepted_chunks: List[VectorSearchResult] = []

        for idx, chunk in enumerate(chunks):
            clean_content = cls._sanitize_chunk_content(chunk.content)
            chunk_xml = (
                f'  <chunk id="{chunk.chunk_id}" page="{chunk.page_number}" '
                f'document="{chunk.document_name}" similarity="{chunk.similarity_score}">\n'
                f"    {clean_content}\n"
                f"  </chunk>"
            )
            xml_len = len(chunk_xml)

            # Check character budget
            if current_chars + xml_len > max_chars and accepted_chunks:
                # Budget reached; truncate further chunks
                break

            context_lines.append(chunk_xml)
            current_chars += xml_len + 1
            accepted_chunks.append(chunk)

        context_lines.append("</source_context>")
        final_context_str = "\n".join(context_lines)

        estimated_tokens = max(1, len(final_context_str) // 4)

        return AssembledContext(
            formatted_context=final_context_str,
            chunk_count=len(accepted_chunks),
            total_characters=len(final_context_str),
            estimated_tokens=estimated_tokens,
            referenced_chunks=accepted_chunks
        )
