"""
VELTRIX SourceMind - Generative AI Provider Abstraction
Defines the abstract interface for all foundation LLM providers with streaming support.
"""

from abc import ABC, abstractmethod
from typing import AsyncGenerator


class BaseLLMProvider(ABC):
    """
    Abstract interface for Large Language Model generation.
    Decouples SourceMind from specific model vendors (Google Gemini, OpenAI, Claude, Local models).
    """

    @abstractmethod
    async def generate_stream(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> AsyncGenerator[str, None]:
        """Streams response tokens asynchronously one by one."""
        pass

    @abstractmethod
    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> str:
        """Generates a complete response synchronously/buffered."""
        pass

    @abstractmethod
    def get_model_name(self) -> str:
        """Returns model identifier."""
        pass
