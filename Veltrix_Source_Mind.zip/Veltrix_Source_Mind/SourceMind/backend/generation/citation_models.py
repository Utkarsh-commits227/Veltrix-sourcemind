"""
VELTRIX SourceMind - Citation & Grounding Data Models
Defines Pydantic schemas for citation extraction, chunk verification, and grounding fidelity.
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class CitationStatus(str, Enum):
    VERIFIED = "verified"                                     # Page and claim verified against retrieved chunk
    UNVERIFIED_PAGE_NOT_RETRIEVED = "unverified_page_absent"  # LLM cited a page not present in retrieved context
    UNVERIFIED_CONTENT_MISMATCH = "unverified_claim_mismatch" # Page was retrieved, but claim text is absent from chunk
    SANITIZED = "sanitized"                                   # Unverified citation stripped from user-facing text


class ExtractedCitation(BaseModel):
    """Represents an individual source citation extracted from generated text."""
    raw_tag: str = Field(..., description="Raw citation tag, e.g. [[Source: doc.pdf, Page: 12]]")
    document_name: str = Field(..., description="Cited document filename")
    page_number: int = Field(..., description="Cited 1-indexed page number")
    claim_text: str = Field(..., description="Preceding sentence/statement supported by this citation")
    is_verified: bool = Field(default=False, description="True if proven by retrieved chunks")
    status: CitationStatus = Field(default=CitationStatus.UNVERIFIED_PAGE_NOT_RETRIEVED)
    matched_chunk_id: Optional[str] = Field(default=None, description="UUID of chunk that proves the claim")
    confidence_score: float = Field(default=0.0, description="Lexical overlap confidence (0.0 to 1.0)")


class GroundedAnswer(BaseModel):
    """Complete verified answer package containing cleaned text and audited citations."""
    raw_answer: str = Field(..., description="Original output produced by the LLM")
    verified_answer: str = Field(..., description="Answer text with unverified citations sanitized/flagged")
    citations: List[ExtractedCitation] = Field(default_factory=list, description="All extracted citations with audit status")
    total_citations: int = Field(default=0)
    verified_citations_count: int = Field(default=0)
    grounding_fidelity_score: float = Field(default=1.0, description="Ratio of verified citations (0.0 to 1.0)")
    has_hallucinated_citations: bool = Field(default=False)
