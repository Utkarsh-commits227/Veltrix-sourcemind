"""
VELTRIX SourceMind - Deterministic Mock LLM Generator
Simulates streaming grounded responses, honest refusals, and structured study outputs
(Summaries, Smart Notes, Revision Sheets) for automated testing and offline development.
"""

import asyncio
import re
from typing import AsyncGenerator

from backend.generation.base import BaseLLMProvider
from backend.generation.prompts import STANDARD_REFUSAL_MESSAGE


class MockLLMGenerator(BaseLLMProvider):
    """
    Deterministic LLM mock that evaluates groundedness:
    - If query keywords appear in <source_context>, generates a grounded answer with verified citations.
    - If query keywords are absent from <source_context>, returns the standard refusal message.
    - If a study task is detected, produces structured markdown for summaries, notes, and revision sheets.
    """

    MODEL_NAME = "mock-llm-generator"

    def get_model_name(self) -> str:
        return self.MODEL_NAME

    def _generate_study_response(self, user_prompt: str) -> str:
        """Generates structured study outputs grounded in <source_document> text."""
        # Extract document name and content
        doc_match = re.search(r'<source_document name="([^"]+)">\s*(.*?)\s*</source_document>', user_prompt, re.DOTALL)
        doc_name = doc_match.group(1) if doc_match else "document.pdf"
        doc_text = doc_match.group(2) if doc_match else ""

        # Check for Summary requests
        if "SHORT SUMMARY" in user_prompt:
            return (
                f"# Executive Summary: {doc_name}\n\n"
                f"This document provides core findings regarding documented concepts [[Source: {doc_name}, Page: 1]]. "
                f"The analysis presents conclusive results derived from empirical methods [[Source: {doc_name}, Page: 1]].\n\n"
                f"### Key Takeaways:\n"
                f"- Primary mechanism established [[Source: {doc_name}, Page: 1]].\n"
                f"- Quantitative benchmarks verified [[Source: {doc_name}, Page: 1]].\n"
                f"- Final recommendations outlined [[Source: {doc_name}, Page: 1]]."
            )

        if "BALANCED ANALYTICAL SUMMARY" in user_prompt:
            return (
                f"# Analytical Summary: {doc_name}\n\n"
                f"## 1. Document Overview\n"
                f"The source document explores foundational principles and practical applications [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 2. Core Methodology & Principles\n"
                f"The framework utilizes systematic analysis to evaluate operational parameters [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 3. Major Findings\n"
                f"- Verified efficiency gains across tested benchmarks [[Source: {doc_name}, Page: 1]].\n"
                f"- Structural integrity confirmed under operational load [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 4. Critical Conclusions\n"
                f"The document concludes that the proposed architecture provides significant improvements [[Source: {doc_name}, Page: 1]]."
            )

        if "COMPREHENSIVE DETAILED SUMMARY" in user_prompt:
            return (
                f"# Comprehensive Detailed Summary: {doc_name}\n\n"
                f"## 1. Executive Abstract\n"
                f"A rigorous examination of core domain concepts and operational dynamics [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 2. Section-by-Section Breakdown\n"
                f"Section 1 outlines theoretical foundations [[Source: {doc_name}, Page: 1]].\n"
                f"Section 2 provides empirical validation and data collection [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 3. Essential Definitions\n"
                f"- **Core Architecture**: The structural foundation described in the source [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 4. Key Takeaways & Significance\n"
                f"Detailed takeaways confirm stability and long-term efficacy [[Source: {doc_name}, Page: 1]]."
            )

        # Check for Smart Study Notes request
        if "Smart Study Notes" in user_prompt or "SMART_NOTES" in user_prompt:
            return (
                f"# {doc_name}: Smart Study Notes\n\n"
                f"## 1. Overview & Context\n"
                f"This document presents essential knowledge and principles for study [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 2. Key Concepts & Principles\n"
                f"- **Primary Architecture**: Fundamental systems dynamics [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 3. Important Points to Remember\n"
                f"- Key observation verified under testing [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 4. Key Definitions & Terminology\n"
                f"- **Protocol**: Standard operational procedure (Page 1)\n\n"
                f"## 5. Processes, Mechanisms & Cause-Effect\n"
                f"- Step 1 leads to activation, resulting in measured output [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 6. Exam-Oriented Focus Points\n"
                f"- Crucial distinction between input and output states [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 7. Quick 30-Second Synthesis\n"
                f"Core summary synthesis for rapid retention."
            )

        # Check for Revision Sheet request
        if "Rapid Revision Sheet" in user_prompt or "REVISION" in user_prompt:
            return (
                f"# {doc_name}: Rapid Revision Sheet\n\n"
                f"## 1. Must Remember (Top 5 Non-Negotiable Facts)\n"
                f"1. Core principle 1 [[Source: {doc_name}, Page: 1]].\n"
                f"2. Core principle 2 [[Source: {doc_name}, Page: 1]].\n"
                f"3. Core principle 3 [[Source: {doc_name}, Page: 1]].\n"
                f"4. Core principle 4 [[Source: {doc_name}, Page: 1]].\n"
                f"5. Core principle 5 [[Source: {doc_name}, Page: 1]].\n\n"
                f"## 2. Essential Definitions\n"
                f"- **Core Term**: Fundamental concept definition (Page 1)\n\n"
                f"## 3. Common Confusions & Pitfalls\n"
                f"- **Confusion**: Conflating state A with state B.\n"
                f"  **Clarification**: The source clarifies that state A precedes state B.\n\n"
                f"## 4. Rapid-Fire Self-Test Questions\n"
                f"- **Q**: What is the primary function?\n"
                f"  **A**: The primary function is systematic execution.\n\n"
                f"## 5. The 60-Second Final Wrap-Up\n"
                f"In conclusion, the document establishes clear operational parameters [[Source: {doc_name}, Page: 1]]."
            )

        # Check for Quiz generation request
        if "practice test" in user_prompt.lower() or "practice quiz" in user_prompt.lower() or "schema requirement" in user_prompt.lower():
            return f'''{{
  "title": "Practice Quiz: {doc_name}",
  "questions": [
    {{
      "question_number": 1,
      "question_type": "multiple_choice",
      "difficulty": "medium",
      "question": "What primary mechanism is established in the source document?",
      "options": [
        {{"label": "A", "text": "Unverified external assertion"}},
        {{"label": "B", "text": "The verified operational principle"}},
        {{"label": "C", "text": "Alternative ungrounded concept"}},
        {{"label": "D", "text": "Theoretical outlier hypothesis"}}
      ],
      "correct_answer": "B",
      "explanation": "The source document explicitly confirms option B as the verified operational principle.",
      "source_page": 1,
      "source_quote": "Core principle verified under empirical benchmarking."
    }},
    {{
      "question_number": 2,
      "question_type": "multiple_choice",
      "difficulty": "easy",
      "question": "According to the document, which statement is factually accurate?",
      "options": [
        {{"label": "A", "text": "Documented foundational standard"}},
        {{"label": "B", "text": "Contradictory premise"}},
        {{"label": "C", "text": "Unrelated distractor statement"}},
        {{"label": "D", "text": "Outdated speculation"}}
      ],
      "correct_answer": "A",
      "explanation": "Section 1 establishes that option A represents the foundational standard.",
      "source_page": 1,
      "source_quote": "Foundational standard established in source."
    }}
  ]
}}'''

        return f"Study output generated for {doc_name}."

    def _generate_deterministic_response(self, user_prompt: str) -> str:
        """Determines if prompt is a study synthesis or chat query."""
        if "<source_document" in user_prompt:
            return self._generate_study_response(user_prompt)

        # Otherwise handle standard chat query with <source_context>
        context_match = re.search(r"<source_context>(.*?)</source_context>", user_prompt, re.DOTALL)
        context_text = context_match.group(1).strip() if context_match else ""

        question_match = re.search(r"USER QUESTION:\s*(.*?)(?:\nANSWER|\Z)", user_prompt, re.DOTALL)
        question_text = question_match.group(1).strip() if question_match else ""

        if not context_text or "<!-- No relevant chunks" in context_text:
            return STANDARD_REFUSAL_MESSAGE

        chunk_match = re.search(r'<chunk[^>]*page="(\d+)"[^>]*document="([^"]+)"', context_text)
        page_num = chunk_match.group(1) if chunk_match else "1"
        doc_name = chunk_match.group(2) if chunk_match else "document.pdf"

        stopwords = {"what", "is", "the", "in", "of", "and", "a", "an", "to", "for", "tell", "me", "about", "how", "why"}
        question_words = {w.lower().strip("?,.!") for w in question_text.split() if w.lower() not in stopwords}

        found_words = [w for w in question_words if w in context_text.lower()]

        if not found_words:
            return STANDARD_REFUSAL_MESSAGE

        return (
            f"Based on the provided source, {', '.join(found_words)} relates directly to the documented concepts "
            f"[[Source: {doc_name}, Page: {page_num}]]."
        )

    async def generate_stream(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> AsyncGenerator[str, None]:
        """Streams response tokens word-by-word asynchronously."""
        full_text = self._generate_deterministic_response(user_prompt)
        words = full_text.split(" ")
        for idx, word in enumerate(words):
            token = word + (" " if idx < len(words) - 1 else "")
            await asyncio.sleep(0.002)
            yield token

    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> str:
        """Returns the complete response string."""
        return self._generate_deterministic_response(user_prompt)
