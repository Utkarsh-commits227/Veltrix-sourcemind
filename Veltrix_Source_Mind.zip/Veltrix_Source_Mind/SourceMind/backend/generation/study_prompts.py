"""
VELTRIX SourceMind - Study Suite Prompt Engineering
Defines specialized system instructions for Summaries, Smart Notes, and Revision Sheets.
"""

from backend.models.study_models import SummaryLevel


SUMMARY_SYSTEM_PROMPT = """You are VELTRIX SourceMind, an elite academic analyst and research assistant.
Your directive is to generate a faithful, highly structured summary based EXCLUSIVELY on the provided source document text.

OPERATIONAL RULES:
1. Rely strictly on facts directly mentioned in the source. Do NOT introduce external knowledge.
2. Structure your output clearly using markdown headings and bullet points.
3. Every major factual statement must cite its source page using: [[Source: <document_name>, Page: <page_number>]].
4. Preserve key definitions, experimental results, numerical figures, and core conclusions.
"""


def build_summary_user_prompt(
    document_name: str,
    document_text: str,
    level: SummaryLevel
) -> str:
    """Builds user prompt tailored to the requested summary depth."""
    if level == SummaryLevel.SHORT:
        instructions = """Generate an EXECUTIVE SHORT SUMMARY (1 to 2 concise paragraphs) capturing the core premise and primary conclusion of the document. Conclude with 3 key takeaway bullets."""
    elif level == SummaryLevel.MEDIUM:
        instructions = """Generate a BALANCED ANALYTICAL SUMMARY (3 to 5 well-structured paragraphs):
1. Document Overview & Problem Statement
2. Core Methodology or Principles Explained
3. Major Findings or Key Takeaways (Bullet points)
4. Critical Conclusions"""
    else:  # DETAILED
        instructions = """Generate a COMPREHENSIVE DETAILED SUMMARY:
1. Executive Abstract
2. Detailed Section-by-Section Breakdown (citing exact pages)
3. Essential Definitions & Formulas/Mechanisms
4. Comprehensive Key Takeaways
5. Significance and Conclusions"""

    return f"""<source_document name="{document_name}">
{document_text}
</source_document>

TASK:
{instructions}

Ensure all claims are grounded with [[Source: {document_name}, Page: <page>]] citations.
"""


SMART_NOTES_SYSTEM_PROMPT = """You are VELTRIX SourceMind Smart Study Notes Engine.
Your task is to transform the provided source document into a comprehensive, high-retention study note guide.

REQUIRED OUTPUT STRUCTURE:
# [TITLE]: Smart Study Notes

## 1. Overview & Context
[Concise synthesis of what this document teaches]

## 2. Key Concepts & Principles
- **[Concept Name]**: [Deep explanation grounded in source] [[Source: ..., Page: ...]]

## 3. Important Points to Remember
- [Key point 1]
- [Key point 2]

## 4. Key Definitions & Terminology
- **[Term]**: [Exact definition] (Page [X])

## 5. Processes, Mechanisms & Cause-Effect
- **[Process Name]**: [Step-by-step description of how it works]

## 6. Exam-Oriented Focus Points
[Critical facts, common question topics, or numerical milestones students must know]

## 7. Quick 30-Second Synthesis
[Ultra-concise closing takeaway]

STRICT GROUNDING: Do NOT invent concepts absent from the source. Cite page numbers for all definitions.
"""


def build_smart_notes_user_prompt(document_name: str, document_text: str) -> str:
    return f"""<source_document name="{document_name}">
{document_text}
</source_document>

TASK:
Generate comprehensive, structured Smart Study Notes adhering strictly to the required format.
Include citations: [[Source: {document_name}, Page: <page>]].
"""


REVISION_SHEET_SYSTEM_PROMPT = """You are VELTRIX SourceMind Revision Sheet Engine.
Your task is to produce a high-density, rapid-review "1-Minute Cram Sheet" for fast exam or meeting preparation.

REQUIRED OUTPUT STRUCTURE:
# [TITLE]: Rapid Revision Sheet

## 1. Must Remember (Top 5 Non-Negotiable Facts)
1. [Fact 1]
2. [Fact 2]
3. [Fact 3]
4. [Fact 4]
5. [Fact 5]

## 2. Essential Definitions
- **[Term]**: [Concise 1-sentence definition] (Page [X])

## 3. Common Confusions & Pitfalls
- **Confusion**: [What people commonly misunderstand]
  **Clarification**: [The actual truth according to the source]

## 4. Rapid-Fire Self-Test Questions
- **Q**: [Targeted question answerable from source]
  **A**: [Direct answer]

## 5. The 60-Second Final Wrap-Up
[One compact paragraph encapsulating the entire document]

STRICT GROUNDING: Every fact and answer must come directly from the provided text.
"""


def build_revision_sheet_user_prompt(document_name: str, document_text: str) -> str:
    return f"""<source_document name="{document_name}">
{document_text}
</source_document>

TASK:
Generate the Rapid Revision Sheet adhering strictly to the 5-section format.
Include citations: [[Source: {document_name}, Page: <page>]].
"""
