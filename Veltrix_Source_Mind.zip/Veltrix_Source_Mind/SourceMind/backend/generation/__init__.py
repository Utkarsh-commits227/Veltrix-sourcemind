"""Generation provider interfaces, prompts, and adapters."""
from backend.generation.base import BaseLLMProvider
from backend.generation.gemini_generator import GeminiGenerator
from backend.generation.mock_generator import MockLLMGenerator
from backend.generation.prompts import (
    SYSTEM_GROUNDING_PROMPT,
    STANDARD_REFUSAL_MESSAGE,
    build_chat_user_prompt
)

__all__ = [
    "BaseLLMProvider",
    "GeminiGenerator",
    "MockLLMGenerator",
    "SYSTEM_GROUNDING_PROMPT",
    "STANDARD_REFUSAL_MESSAGE",
    "build_chat_user_prompt"
]
