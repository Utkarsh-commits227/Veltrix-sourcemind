"""
VELTRIX SourceMind - Verifiable Citation Engine
Audits LLM-generated citation tags against retrieved chunks, checks claim text overlap,
and prevents hallucinated citations.
"""

import re
from typing import List, Optional, Set, Tuple

from backend.core.logging import logger
from backend.generation.citation_models import (
    CitationStatus,
    ExtractedCitation,
    GroundedAnswer
)
from backend.vectorstore.base import VectorSearchResult


class CitationVerifier:
    """
    Automated grounding auditor.
    Guarantees that every [[Source: doc, Page: X]] tag matches a real retrieved chunk,
    and verifies that the claim preceding the citation is actually substantiated by that chunk.
    """

    CITATION_REGEX = re.compile(r"\[\[Source:\s*([^,]+),\s*Page:\s*(\d+)\]\]", re.IGNORECASE)

    # Standard English stopwords to filter out before computing lexical overlap
    STOPWORDS: Set[str] = {
        "a", "an", "the", "in", "on", "at", "of", "and", "or", "is", "are", "was", "were",
        "to", "for", "with", "by", "that", "this", "it", "from", "as", "be", "which", "an",
        "based", "according", "provided", "source", "document"
    }

    @classmethod
    def _extract_preceding_claim(cls, full_text: str, tag_start_idx: int) -> str:
        """Extracts the sentence or clause immediately preceding the citation tag."""
        preceding = full_text[:tag_start_idx].strip()
        if not preceding:
            return ""
        # Find sentence terminators (. ! ?)
        sentences = re.split(r"(?<=[.!?])\s+", preceding)
        return sentences[-1].strip() if sentences else preceding

    @classmethod
    def extract_raw_citations(cls, text: str) -> List[ExtractedCitation]:
        """Scans generated text and extracts all citation tags with preceding claims."""
        citations: List[ExtractedCitation] = []
        if not text:
            return citations

        for match in cls.CITATION_REGEX.finditer(text):
            raw_tag = match.group(0)
            doc_name = match.group(1).strip()
            page_num = int(match.group(2).strip())
            claim = cls._extract_preceding_claim(text, match.start())

            citations.append(
                ExtractedCitation(
                    raw_tag=raw_tag,
                    document_name=doc_name,
                    page_number=page_num,
                    claim_text=claim,
                    is_verified=False,
                    status=CitationStatus.UNVERIFIED_PAGE_NOT_RETRIEVED
                )
            )

        return citations

    @classmethod
    def _compute_claim_overlap(cls, claim_text: str, chunk_content: str) -> float:
        """
        Computes lexical keyword overlap ratio between the claim and the source chunk.
        Returns float between 0.0 and 1.0.
        """
        if not claim_text or not chunk_content:
            return 0.0

        claim_words = {
            w.lower().strip(".,!?;:\"'()[]{}")
            for w in claim_text.split()
            if w.lower() not in cls.STOPWORDS and len(w) > 2
        }

        if not claim_words:
            return 0.5  # If claim consists only of stopwords, neutral confidence

        chunk_words = {
            w.lower().strip(".,!?;:\"'()[]{}")
            for w in chunk_content.split()
            if len(w) > 2
        }

        matching_words = claim_words.intersection(chunk_words)
        return len(matching_words) / len(claim_words)

    @classmethod
    def verify_citations(
        cls,
        raw_answer: str,
        retrieved_chunks: List[VectorSearchResult],
        sanitize_unverified: bool = True
    ) -> GroundedAnswer:
        """
        Complete verification pipeline:
        1. Extracts citation tags and claims.
        2. Cross-references against retrieved chunks.
        3. Audits claim text overlap.
        4. Calculates grounding fidelity score.
        5. Optionally sanitizes unverified citations from user-facing text.
        """
        citations = cls.extract_raw_citations(raw_answer)

        if not citations:
            return GroundedAnswer(
                raw_answer=raw_answer,
                verified_answer=raw_answer,
                citations=[],
                total_citations=0,
                verified_citations_count=0,
                grounding_fidelity_score=1.0,
                has_hallucinated_citations=False
            )

        verified_count = 0
        has_hallucinations = False
        verified_answer_text = raw_answer

        for cit in citations:
            # Check if this document and page were actually present in retrieved context
            matching_chunks = [
                chk for chk in retrieved_chunks
                if chk.page_number == cit.page_number
                and (chk.document_name.lower() in cit.document_name.lower() or cit.document_name.lower() in chk.document_name.lower())
            ]

            if not matching_chunks:
                # FAKE CITATION DETECTED: Page was never provided in context
                cit.status = CitationStatus.UNVERIFIED_PAGE_NOT_RETRIEVED
                cit.is_verified = False
                cit.confidence_score = 0.0
                has_hallucinations = True
                logger.warning(
                    f"Hallucinated citation detected: Cited page {cit.page_number} "
                    f"in '{cit.document_name}', but page was never retrieved."
                )
                if sanitize_unverified:
                    verified_answer_text = verified_answer_text.replace(cit.raw_tag, "[Citation Unverified]")
                continue

            # Page was retrieved; now verify claim content overlap
            best_chunk = None
            best_overlap = 0.0

            for chk in matching_chunks:
                overlap = cls._compute_claim_overlap(cit.claim_text, chk.content)
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_chunk = chk

            # Require at least 25% significant word overlap to substantiate the claim
            if best_overlap >= 0.25 and best_chunk:
                cit.is_verified = True
                cit.status = CitationStatus.VERIFIED
                cit.matched_chunk_id = best_chunk.chunk_id
                cit.confidence_score = round(best_overlap, 3)
                verified_count += 1
            else:
                cit.status = CitationStatus.UNVERIFIED_CONTENT_MISMATCH
                cit.is_verified = False
                cit.confidence_score = round(best_overlap, 3)
                has_hallucinations = True
                logger.warning(
                    f"Content mismatch citation: Page {cit.page_number} was retrieved, "
                    f"but claim '{cit.claim_text[:40]}...' has insufficient overlap ({best_overlap:.2f})."
                )
                if sanitize_unverified:
                    verified_answer_text = verified_answer_text.replace(cit.raw_tag, "[Citation Unverified]")

        fidelity_score = round(verified_count / len(citations), 3)

        return GroundedAnswer(
            raw_answer=raw_answer,
            verified_answer=verified_answer_text,
            citations=citations,
            total_citations=len(citations),
            verified_citations_count=verified_count,
            grounding_fidelity_score=fidelity_score,
            has_hallucinated_citations=has_hallucinations
        )
