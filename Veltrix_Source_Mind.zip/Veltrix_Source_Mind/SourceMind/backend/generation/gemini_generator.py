"""
VELTRIX SourceMind - Google Gemini Foundation Model Adapter
Streams grounded responses from Gemini 2.0 Flash / 1.5 Flash using official google-genai SDK.
"""

import asyncio
from typing import AsyncGenerator, Optional
from backend.core.config import settings
from backend.core.exceptions import GenerationError
from backend.core.logging import logger
from backend.generation.base import BaseLLMProvider


class GeminiGenerator(BaseLLMProvider):
    """
    Google GenAI streaming generation adapter.
    Utilizes Gemini 2.0 Flash for sub-second Time-To-First-Token (TTFT) and strict grounding adherence.
    """

    DEFAULT_MODEL = "gemini-2.0-flash"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or settings.GEMINI_API_KEY
        self.model_name = model or settings.GENERATION_MODEL or self.DEFAULT_MODEL
        self._client = None

    def _get_client(self):
        """Lazy client initialization."""
        if self._client is None:
            if not self.api_key:
                raise GenerationError(
                    "GEMINI_API_KEY is not configured. Please supply an API key in your .env file."
                )
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as e:
                raise GenerationError(f"Failed to initialize Google GenAI client: {str(e)}")
        return self._client

    def get_model_name(self) -> str:
        return self.model_name

    async def generate_stream(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> AsyncGenerator[str, None]:
        """Streams text chunks from Gemini API asynchronously."""
        client = self._get_client()

        try:
            from google.genai import types

            # Run streaming call in async context
            # In google-genai, client.aio provides native async client
            response_stream = await client.aio.models.generate_content_stream(
                model=self.model_name,
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    temperature=temperature
                )
            )

            async for chunk in response_stream:
                if chunk.text:
                    yield chunk.text

        except Exception as exc:
            logger.error(f"Gemini streaming generation failed: {str(exc)}")
            raise GenerationError(f"Gemini generation error: {str(exc)}")

    async def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1
    ) -> str:
        """Buffered generation yielding the full response string."""
        collected: list[str] = []
        async for token in self.generate_stream(system_prompt, user_prompt, temperature):
            collected.append(token)
        return "".join(collected)
