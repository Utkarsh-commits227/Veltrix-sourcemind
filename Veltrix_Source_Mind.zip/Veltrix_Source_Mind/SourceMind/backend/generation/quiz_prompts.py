"""
VELTRIX SourceMind - Quiz Generation Prompt Engineering
Generates strictly grounded multiple-choice and conceptual practice questions in JSON format.
"""

from backend.models.quiz_models import DifficultyLevel, QuestionType


QUIZ_SYSTEM_PROMPT = """You are VELTRIX SourceMind Quiz & Practice Test Engine.
Your task is to generate high-quality, active-recall study questions based EXCLUSIVELY on the provided source document.

CRITICAL RULES:
1. STRICT GROUNDING: Every question, correct answer, and explanation MUST be directly verifiable from the provided document text. Do NOT test unstated trivia or general internet knowledge.
2. DISTRACTOR INTEGRITY: For multiple-choice questions, provide 4 options (A, B, C, D). Distractors (wrong options) must be realistic and relevant to the topic, but definitively incorrect based on the text.
3. CITATIONS & QUOTES: You MUST cite the source page number and quote the exact sentence from the source that proves the correct answer.
4. JSON FORMAT ONLY: Output MUST be a valid, parseable JSON object matching the exact schema specified below. Do NOT output markdown code blocks (```json), commentary, or apologies.
"""

JSON_SCHEMA_EXAMPLE = """{
  "title": "Practice Quiz: Document Title",
  "questions": [
    {
      "question_number": 1,
      "question_type": "multiple_choice",
      "difficulty": "medium",
      "question": "What is the primary function of the component discussed in Chapter 2?",
      "options": [
        {"label": "A", "text": "Incorrect plausible distractor 1"},
        {"label": "B", "text": "The correct answer supported by text"},
        {"label": "C", "text": "Incorrect plausible distractor 2"},
        {"label": "D", "text": "Incorrect plausible distractor 3"}
      ],
      "correct_answer": "B",
      "explanation": "The source explicitly states that component B performs the primary function.",
      "source_page": 2,
      "source_quote": "Component B executes the primary scheduling loop."
    }
  ]
}"""


def build_quiz_user_prompt(
    document_name: str,
    document_text: str,
    num_questions: int = 5,
    difficulty: DifficultyLevel = DifficultyLevel.MEDIUM,
    question_type: QuestionType = QuestionType.MULTIPLE_CHOICE
) -> str:
    """Builds user prompt requesting a structured JSON quiz."""
    return f"""<source_document name="{document_name}">
{document_text}
</source_document>

TASK:
Generate a {difficulty.value}-difficulty practice test containing exactly {num_questions} {question_type.value} questions based SOLELY on the source document above.

SCHEMA REQUIREMENT:
Your response must strictly adhere to this JSON format:
{JSON_SCHEMA_EXAMPLE}

OUTPUT RAW JSON ONLY.
"""
