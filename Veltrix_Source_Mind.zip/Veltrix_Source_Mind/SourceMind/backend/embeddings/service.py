"""
VELTRIX SourceMind - Central Embedding Service
Coordinates embedding provider selection, caching, batch vector generation, and telemetry.
"""

from typing import List, Optional, Dict, Tuple
from backend.core.config import settings
from backend.core.exceptions import EmbeddingError
from backend.core.logging import logger
from backend.embeddings.base import BaseEmbeddingProvider
from backend.embeddings.cache import EmbeddingCache, embedding_cache
from backend.embeddings.gemini_provider import GeminiEmbeddingProvider
from backend.embeddings.mock_provider import MockEmbeddingProvider
from backend.ingestion.chunkers import DocumentChunk


class EmbeddingService:
    """
    High-level service managing vector embedding creation and caching.
    Ensures zero redundant API calls for duplicate or re-indexed chunks.
    """

    def __init__(
        self,
        provider: Optional[BaseEmbeddingProvider] = None,
        cache: Optional[EmbeddingCache] = None
    ):
        self.cache = cache or embedding_cache
        self._provider = provider

    @property
    def provider(self) -> BaseEmbeddingProvider:
        """Lazy-instantiates the configured embedding provider."""
        if self._provider is None:
            provider_type = settings.EMBEDDING_PROVIDER.lower()
            if provider_type == "gemini":
                # If no Gemini API key is configured in dev mode, fallback gracefully to Mock
                if not settings.GEMINI_API_KEY and settings.ENVIRONMENT == "development":
                    logger.warning("No GEMINI_API_KEY detected in development mode. Using MockEmbeddingProvider.")
                    self._provider = MockEmbeddingProvider()
                else:
                    self._provider = GeminiEmbeddingProvider()
            elif provider_type == "mock":
                self._provider = MockEmbeddingProvider()
            else:
                raise EmbeddingError(f"Unsupported EMBEDDING_PROVIDER '{provider_type}'.")
        return self._provider

    def set_provider(self, provider: BaseEmbeddingProvider) -> None:
        """Allows injecting a custom or mock provider (useful for testing)."""
        self._provider = provider

    async def embed_chunks(self, chunks: List[DocumentChunk]) -> List[List[float]]:
        """
        Embeds a list of DocumentChunks into vectors.
        Utilizes SHA-256 content hash cache to skip already-embedded chunks.
        Returns vectors in identical order to input chunks.
        """
        if not chunks:
            return []

        results: List[Optional[List[float]]] = [None] * len(chunks)
        uncached_indices: List[int] = []
        uncached_texts: List[str] = []

        # Step 1: Check cache for each chunk's content hash
        for idx, chunk in enumerate(chunks):
            cached_vector = self.cache.get(chunk.content_hash)
            if cached_vector is not None:
                results[idx] = cached_vector
            else:
                uncached_indices.append(idx)
                uncached_texts.append(chunk.content)

        # Step 2: Embed uncached chunks in batch
        if uncached_texts:
            logger.info(
                f"Embedding {len(uncached_texts)} uncached chunks "
                f"({len(chunks) - len(uncached_texts)} served from cache) "
                f"using {self.provider.get_model_name()}..."
            )
            generated_vectors = await self.provider.embed_texts(uncached_texts)

            if len(generated_vectors) != len(uncached_texts):
                raise EmbeddingError(
                    f"Provider returned {len(generated_vectors)} vectors for {len(uncached_texts)} input texts."
                )

            # Store in cache and place in result slots
            for pos, vector in enumerate(generated_vectors):
                orig_idx = uncached_indices[pos]
                results[orig_idx] = vector
                self.cache.set(chunks[orig_idx].content_hash, vector)

        return results  # type: ignore

    async def embed_query(self, query: str) -> List[float]:
        """Embeds a single search query into the active vector space."""
        if not query or not query.strip():
            raise EmbeddingError("Search query cannot be empty.")
        return await self.provider.embed_query(query)


# Global singleton instance of EmbeddingService
embedding_service = EmbeddingService()
