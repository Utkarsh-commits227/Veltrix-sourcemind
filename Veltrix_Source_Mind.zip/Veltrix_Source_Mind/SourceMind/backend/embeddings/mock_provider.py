"""
VELTRIX SourceMind - Deterministic Mock Embedding Provider
Provides normalized, reproducible 768-dimensional float vectors for local testing and offline execution.
"""

import hashlib
import math
import random
from typing import List

from backend.embeddings.base import BaseEmbeddingProvider


class MockEmbeddingProvider(BaseEmbeddingProvider):
    """
    Deterministic embedding provider that maps text to a 768-dimensional unit vector
    using a pseudo-random seed based on the text's SHA-256 hash.
    Generates reproducible unit vectors (L2 norm = 1.0) suitable for testing cosine similarity.
    """

    DIMENSION = 768
    MODEL_NAME = "mock-embedding-768"

    def __init__(self, dimension: int = 768):
        self._dimension = dimension

    def get_dimension(self) -> int:
        return self._dimension

    def get_model_name(self) -> str:
        return self.MODEL_NAME

    def _generate_vector(self, text: str) -> List[float]:
        """Generates a normalized 768-dim float vector deterministically from text."""
        # Seed RNG with text hash so identical text produces identical vector
        seed = int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:16], 16)
        rng = random.Random(seed)

        # Generate Gaussian distributed floats
        raw_vector = [rng.gauss(0, 1) for _ in range(self._dimension)]

        # Normalize to unit length (L2 norm = 1.0)
        norm = math.sqrt(sum(x * x for x in raw_vector))
        if norm == 0:
            norm = 1.0
        return [x / norm for x in raw_vector]

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Embeds a list of texts into deterministic unit vectors."""
        return [self._generate_vector(t) for t in texts]

    async def embed_query(self, query: str) -> List[float]:
        """Embeds a search query into the same vector space."""
        return self._generate_vector(query)
