"""
VELTRIX SourceMind - Embedding Provider Abstraction
Defines the abstract base contract for all vector embedding providers.
"""

from abc import ABC, abstractmethod
from typing import List


class BaseEmbeddingProvider(ABC):
    """
    Abstract interface for text embedding generation.
    Decouples the core RAG engine from vendor-specific embedding models
    (Google Gemini, OpenAI, Cohere, Local models).
    """

    @abstractmethod
    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """
        Embeds a list of document chunk texts into high-dimensional float vectors.
        Must handle internal batching if the list exceeds provider limits.
        """
        pass

    @abstractmethod
    async def embed_query(self, query: str) -> List[float]:
        """
        Embeds a single search query into the same vector space.
        Some providers (like Google text-embedding-004) use specialized task_types for queries.
        """
        pass

    @abstractmethod
    def get_dimension(self) -> int:
        """Returns the fixed dimensionality of the embedding vector (e.g. 768, 1536)."""
        pass

    @abstractmethod
    def get_model_name(self) -> str:
        """Returns the provider model identifier."""
        pass
