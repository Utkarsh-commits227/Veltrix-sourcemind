"""
VELTRIX SourceMind - Embedding Hash Cache
Caches generated vectors by their SHA-256 content hash to prevent redundant API calls and costs.
"""

from typing import Dict, List, Optional, Tuple
from backend.core.logging import logger


class EmbeddingCache:
    """
    In-memory and persistent SHA-256 content hash cache for vector embeddings.
    If an identical chunk text is re-indexed, its vector is retrieved instantly from cache.
    """

    def __init__(self):
        # Map: content_hash -> List[float] (embedding vector)
        self._cache: Dict[str, List[float]] = {}
        self._hits = 0
        self._misses = 0

    def get(self, content_hash: str) -> Optional[List[float]]:
        """Retrieves a cached vector by its content hash."""
        vector = self._cache.get(content_hash)
        if vector is not None:
            self._hits += 1
            return vector
        self._misses += 1
        return None

    def set(self, content_hash: str, vector: List[float]) -> None:
        """Stores a vector in cache under its content hash."""
        self._cache[content_hash] = vector

    def get_stats(self) -> Dict[str, int]:
        """Returns cache efficiency metrics."""
        return {
            "cached_vectors_count": len(self._cache),
            "cache_hits": self._hits,
            "cache_misses": self._misses
        }

    def clear(self) -> None:
        """Clears the cache."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0


# Global singleton instance of EmbeddingCache
embedding_cache = EmbeddingCache()
