"""
VELTRIX SourceMind - Google Gemini Embedding Provider
Integrates Google's text-embedding-004 model via official google-genai SDK.
"""

import asyncio
from typing import List, Optional
from backend.core.config import settings
from backend.core.exceptions import EmbeddingError
from backend.core.logging import logger
from backend.embeddings.base import BaseEmbeddingProvider


class GeminiEmbeddingProvider(BaseEmbeddingProvider):
    """
    Google GenAI text-embedding-004 embedding adapter.
    Produces 768-dimensional semantic vectors.
    """

    DEFAULT_MODEL = "text-embedding-004"
    DIMENSION = 768
    MAX_BATCH_SIZE = 64

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or settings.GEMINI_API_KEY
        self.model_name = model or settings.EMBEDDING_MODEL or self.DEFAULT_MODEL
        self._client = None

    def _get_client(self):
        """Lazy client initialization."""
        if self._client is None:
            if not self.api_key:
                raise EmbeddingError(
                    "GEMINI_API_KEY is not configured. Please provide an API key in your .env file."
                )
            try:
                from google import genai
                self._client = genai.Client(api_key=self.api_key)
            except Exception as e:
                raise EmbeddingError(f"Failed to initialize Google GenAI client: {str(e)}")
        return self._client

    def get_dimension(self) -> int:
        return self.DIMENSION

    def get_model_name(self) -> str:
        return self.model_name

    async def _embed_batch_with_retry(self, batch: List[str], max_retries: int = 3) -> List[List[float]]:
        """Executes a single batch embedding call with exponential backoff for rate limits."""
        client = self._get_client()

        for attempt in range(max_retries):
            try:
                # Run synchronous client call in thread pool to avoid blocking async event loop
                loop = asyncio.get_running_loop()
                response = await loop.run_in_executor(
                    None,
                    lambda: client.models.embed_content(
                        model=self.model_name,
                        contents=batch
                    )
                )

                if hasattr(response, "embeddings") and response.embeddings:
                    return [emb.values for emb in response.embeddings]
                elif hasattr(response, "embedding") and response.embedding:
                    return [response.embedding.values]
                else:
                    raise EmbeddingError("Google GenAI returned an empty embedding response.")

            except Exception as exc:
                is_rate_limit = "429" in str(exc) or "quota" in str(exc).lower()
                if is_rate_limit and attempt < max_retries - 1:
                    delay = 2 ** attempt + 0.5
                    logger.warning(f"Rate limit hit in Gemini embedding API. Retrying in {delay:.1f}s... (Attempt {attempt + 1}/{max_retries})")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Gemini embedding API call failed: {str(exc)}")
                    raise EmbeddingError(f"Gemini embedding generation failed: {str(exc)}")

        raise EmbeddingError("Gemini embedding failed after maximum retries.")

    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Embeds a list of texts in batches to comply with API limits."""
        if not texts:
            return []

        all_embeddings: List[List[float]] = []
        for i in range(0, len(texts), self.MAX_BATCH_SIZE):
            batch = texts[i:i + self.MAX_BATCH_SIZE]
            batch_embeddings = await self._embed_batch_with_retry(batch)
            all_embeddings.extend(batch_embeddings)

        return all_embeddings

    async def embed_query(self, query: str) -> List[float]:
        """Embeds a single search query."""
        if not query or not query.strip():
            raise EmbeddingError("Search query cannot be empty for embedding generation.")

        embeddings = await self._embed_batch_with_retry([query])
        return embeddings[0]
