"""
VELTRIX SourceMind - Ingested Document Registry & State Management
Maintains in-memory document state, metadata persistence, and vector store coordination.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from backend.core.config import settings
from backend.core.logging import logger
from backend.ingestion.base import ExtractedDocument
from backend.vectorstore.service import vector_store_service


class DocumentRegistry:
    """
    Central repository for ingested documents in VELTRIX SourceMind.
    Provides fast lookup of ExtractedDocument records for Study synthesis,
    Quiz generation, Source Inspector page reading, and deletion.
    """

    def __init__(self, registry_file: Optional[Path] = None):
        self.registry_file = registry_file or (settings.DATA_DIR / "documents_registry.json")
        self._documents: Dict[str, ExtractedDocument] = {}
        self._chunk_counts: Dict[str, int] = {}
        self._load_from_disk()

    def _load_from_disk(self) -> None:
        """Loads registered documents from disk if available."""
        if not self.registry_file.exists():
            return
        try:
            raw_data = json.loads(self.registry_file.read_text(encoding="utf-8"))
            for item in raw_data:
                doc = ExtractedDocument.model_validate(item["document"])
                self._documents[doc.document_id] = doc
                self._chunk_counts[doc.document_id] = item.get("chunk_count", 0)
            logger.info(f"Loaded {len(self._documents)} documents from registry: {self.registry_file}")
        except Exception as e:
            logger.warning(f"Failed to load document registry from disk: {e}")

    def _save_to_disk(self) -> None:
        """Persists current registry state to disk."""
        try:
            self.registry_file.parent.mkdir(parents=True, exist_ok=True)
            payload = [
                {
                    "document": doc.model_dump(mode="json"),
                    "chunk_count": self._chunk_counts.get(doc.document_id, 0)
                }
                for doc in self._documents.values()
            ]
            self.registry_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as e:
            logger.error(f"Failed to persist document registry to disk: {e}")

    def register_document(self, doc: ExtractedDocument, chunk_count: int = 0) -> None:
        """Adds or updates an ExtractedDocument in the registry."""
        self._documents[doc.document_id] = doc
        self._chunk_counts[doc.document_id] = chunk_count
        self._save_to_disk()
        logger.info(f"Registered document '{doc.filename}' (ID: {doc.document_id}, Chunks: {chunk_count})")

    def get_document(self, document_id: str) -> Optional[ExtractedDocument]:
        """Retrieves an ExtractedDocument by its document_id."""
        return self._documents.get(document_id)

    def list_documents(self) -> List[Dict[str, Any]]:
        """Returns metadata summaries for all registered documents."""
        results = []
        for doc_id, doc in self._documents.items():
            results.append({
                "document_id": doc.document_id,
                "filename": doc.filename,
                "mime_type": doc.mime_type,
                "file_size_bytes": doc.file_size_bytes,
                "page_count": doc.page_count,
                "total_char_count": doc.total_char_count,
                "chunk_count": self._chunk_counts.get(doc_id, 0),
                "ingested_at": doc.ingested_at.isoformat() if hasattr(doc, "ingested_at") else "",
                "status": "INDEXED"
            })
        return results

    async def delete_document(self, document_id: str) -> bool:
        """
        Cascades deletion across:
        1. VectorStoreService (deletes ChromaDB chunk embeddings)
        2. Uploaded physical file from disk (if exists)
        3. Document registry memory and persistence
        """
        doc = self._documents.pop(document_id, None)
        self._chunk_counts.pop(document_id, None)
        if not doc:
            return False

        # 1. Delete vectors
        try:
            await vector_store_service.delete_document(document_id)
        except Exception as e:
            logger.warning(f"Vector store deletion warning for {document_id}: {e}")

        # 2. Delete physical storage if present
        storage_path = doc.metadata.get("storage_path")
        if storage_path:
            p = Path(storage_path)
            if p.exists():
                try:
                    p.unlink()
                    logger.info(f"Deleted physical file: {p}")
                except Exception as e:
                    logger.warning(f"Could not delete physical file {p}: {e}")

        # 3. Update disk registry
        self._save_to_disk()
        logger.info(f"Document {document_id} ('{doc.filename}') fully removed.")
        return True


# Global singleton instance of DocumentRegistry
document_registry = DocumentRegistry()
