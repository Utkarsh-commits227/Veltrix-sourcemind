"""
VELTRIX SourceMind - Document Ingestion Service
Orchestrates file validation, parser selection, extraction, chunking, and persistence.
"""

from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

from backend.core.config import settings
from backend.core.exceptions import UnsupportedFileError, IngestionError
from backend.core.logging import logger
from backend.ingestion.base import BaseParser, ExtractedDocument
from backend.ingestion.chunkers import BaseChunker, DocumentChunk, RecursiveSemanticChunker
from backend.ingestion.parsers.pdf_parser import PDFParser
from backend.ingestion.parsers.text_parser import TextParser
from backend.ingestion.validators import FileValidator


class IngestionService:
    """
    Central orchestration service for document ingestion and chunking.
    Dispatches file uploads to appropriate parsers after thorough validation,
    and converts extracted documents into semantic chunks.
    """

    def __init__(
        self,
        parsers: Optional[List[BaseParser]] = None,
        chunker: Optional[BaseChunker] = None
    ):
        # Register default supported parsers
        self.parsers = parsers or [
            PDFParser(),
            TextParser()
        ]
        self.chunker = chunker or RecursiveSemanticChunker()

    def select_parser(self, extension: str, mime_type: str) -> BaseParser:
        """Finds the appropriate parser registered for the given extension and MIME type."""
        for parser in self.parsers:
            if parser.can_parse(extension, mime_type):
                return parser
        raise UnsupportedFileError(
            f"No parser available for file type '{extension}' ({mime_type})."
        )

    def ingest_file(self, filename: str, content: bytes, save_to_disk: bool = True) -> ExtractedDocument:
        """
        Executes the document ingestion lifecycle:
        1. File validation (size, magic byte signature, extension)
        2. Parser selection
        3. Document parsing & text cleaning
        4. Optional secure local file disk storage
        """
        logger.info(f"Starting ingestion for file: '{filename}' ({len(content)} bytes)")

        # Step 1: Validate file upload
        clean_filename, extension, mime_type = FileValidator.validate_upload(filename, content)

        # Step 2: Select appropriate parser
        parser = self.select_parser(extension, mime_type)
        logger.debug(f"Selected parser '{parser.__class__.__name__}' for '{clean_filename}'")

        # Step 3: Parse document
        extracted_doc = parser.parse(
            file_path=Path(clean_filename),
            content=content,
            filename=clean_filename
        )

        # Step 4: Persist file to uploads directory if requested
        if save_to_disk:
            storage_path = settings.UPLOAD_DIR / f"{extracted_doc.document_id}{extension}"
            storage_path.write_bytes(content)
            extracted_doc.metadata["storage_path"] = str(storage_path)
            logger.info(f"Saved document '{clean_filename}' to storage: {storage_path}")

        logger.info(
            f"Successfully ingested '{clean_filename}': "
            f"{extracted_doc.page_count} pages, {extracted_doc.total_char_count} chars, "
            f"doc_id={extracted_doc.document_id}"
        )

        return extracted_doc

    def ingest_and_chunk(
        self,
        filename: str,
        content: bytes,
        save_to_disk: bool = True
    ) -> Tuple[ExtractedDocument, List[DocumentChunk]]:
        """
        Ingests the document and executes semantic chunking.
        Returns both the ExtractedDocument and the ordered List[DocumentChunk].
        """
        extracted_doc = self.ingest_file(filename, content, save_to_disk=save_to_disk)
        chunks = self.chunker.chunk_document(extracted_doc)
        return extracted_doc, chunks


# Global singleton instance of IngestionService
ingestion_service = IngestionService()
