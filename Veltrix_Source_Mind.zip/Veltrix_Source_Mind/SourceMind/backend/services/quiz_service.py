"""
VELTRIX SourceMind - Quiz & Practice Test Service
Orchestrates grounded question generation, distractor validation, and automated grading.
"""

import json
import re
import uuid
from typing import Dict, List, Optional, Any

from backend.core.config import settings
from backend.core.exceptions import EmptyDocumentError, GenerationError
from backend.core.logging import logger
from backend.generation.base import BaseLLMProvider
from backend.generation.gemini_generator import GeminiGenerator
from backend.generation.mock_generator import MockLLMGenerator
from backend.generation.quiz_prompts import QUIZ_SYSTEM_PROMPT, build_quiz_user_prompt
from backend.ingestion.base import ExtractedDocument
from backend.models.quiz_models import (
    DifficultyLevel,
    QuestionType,
    Quiz,
    QuizQuestion,
    QuizOption,
    QuizEvaluationResult,
    QuestionResult
)


class QuizService:
    """
    Coordinates active-recall study questions and practice tests:
    - Generates grounded multiple-choice and conceptual quizzes
    - Enforces JSON validation and distractor plausibility
    - Automated grading engine with per-question explanations
    """

    def __init__(self, generator_instance: Optional[BaseLLMProvider] = None):
        self._generator = generator_instance

    @property
    def generator(self) -> BaseLLMProvider:
        """Lazy-instantiates configured LLM provider."""
        if self._generator is None:
            if not settings.GEMINI_API_KEY and settings.ENVIRONMENT == "development":
                logger.warning("No GEMINI_API_KEY detected in development mode. Using MockLLMGenerator.")
                self._generator = MockLLMGenerator()
            else:
                self._generator = GeminiGenerator()
        return self._generator

    def set_generator(self, generator: BaseLLMProvider) -> None:
        """Injects a custom or mock LLM provider (ideal for testing)."""
        self._generator = generator

    @staticmethod
    def _clean_json_output(raw_text: str) -> str:
        """Strips markdown code block wrappers (```json ... ```) if present."""
        cleaned = raw_text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        elif cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        return cleaned.strip()

    async def generate_quiz(
        self,
        document: ExtractedDocument,
        num_questions: int = 5,
        difficulty: DifficultyLevel = DifficultyLevel.MEDIUM,
        question_type: QuestionType = QuestionType.MULTIPLE_CHOICE
    ) -> Quiz:
        """
        Generates a verified, source-grounded practice test in structured JSON format.
        """
        if not document.full_text or not document.full_text.strip():
            raise EmptyDocumentError(
                f"Document '{document.filename}' contains no readable text to generate questions."
            )

        logger.info(
            f"Generating {num_questions} {difficulty.value} {question_type.value} questions "
            f"for document '{document.filename}'..."
        )

        user_prompt = build_quiz_user_prompt(
            document_name=document.filename,
            document_text=document.full_text.strip(),
            num_questions=num_questions,
            difficulty=difficulty,
            question_type=question_type
        )

        raw_response = await self.generator.generate(
            system_prompt=QUIZ_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        )

        cleaned_json = self._clean_json_output(raw_response)

        try:
            quiz_data = json.loads(cleaned_json)
        except json.JSONDecodeError as exc:
            logger.error(f"Failed to parse LLM JSON quiz output: {str(exc)}\nRaw: {raw_response[:200]}")
            raise GenerationError(f"Model failed to return valid JSON for quiz: {str(exc)}")

        quiz_title = quiz_data.get("title", f"Practice Quiz: {document.filename}")
        raw_questions = quiz_data.get("questions", [])

        quiz_id = str(uuid.uuid4())
        parsed_questions: List[QuizQuestion] = []

        for idx, q_dict in enumerate(raw_questions):
            q_num = idx + 1
            q_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{quiz_id}_q_{q_num}"))

            # Parse options
            options: List[QuizOption] = []
            for opt in q_dict.get("options", []):
                options.append(QuizOption(label=opt.get("label", "").upper(), text=opt.get("text", "")))

            correct_ans = q_dict.get("correct_answer", "").strip().upper()

            parsed_questions.append(
                QuizQuestion(
                    question_id=q_id,
                    question_number=q_num,
                    question_type=question_type,
                    difficulty=difficulty,
                    question=q_dict.get("question", f"Question {q_num}"),
                    options=options,
                    correct_answer=correct_ans,
                    explanation=q_dict.get("explanation", "Verified from source."),
                    source_page=q_dict.get("source_page"),
                    source_quote=q_dict.get("source_quote")
                )
            )

        return Quiz(
            quiz_id=quiz_id,
            document_id=document.document_id,
            document_name=document.filename,
            title=quiz_title,
            total_questions=len(parsed_questions),
            difficulty=difficulty,
            questions=parsed_questions
        )

    def evaluate_quiz(
        self,
        quiz: Quiz,
        user_answers: Dict[str, str]
    ) -> QuizEvaluationResult:
        """
        Instant grading engine evaluating submitted answers against verified keys.
        Returns score percentage, pass/fail status (pass threshold >= 70%), and detailed question results.
        """
        correct_count = 0
        question_results: List[QuestionResult] = []

        for q in quiz.questions:
            # User answer lookup by question_id or question_number string
            user_ans = user_answers.get(q.question_id) or user_answers.get(str(q.question_number), "")
            clean_user_ans = user_ans.strip().upper()
            is_correct = clean_user_ans == q.correct_answer.upper()

            if is_correct:
                correct_count += 1

            question_results.append(
                QuestionResult(
                    question_id=q.question_id,
                    question_number=q.question_number,
                    question=q.question,
                    user_answer=clean_user_ans,
                    correct_answer=q.correct_answer,
                    is_correct=is_correct,
                    explanation=q.explanation,
                    source_page=q.source_page
                )
            )

        total = len(quiz.questions)
        percentage = round((correct_count / total * 100.0), 1) if total > 0 else 0.0
        passed = percentage >= 70.0

        return QuizEvaluationResult(
            quiz_id=quiz.quiz_id,
            total_questions=total,
            correct_count=correct_count,
            incorrect_count=total - correct_count,
            score_percentage=percentage,
            passed=passed,
            question_results=question_results
        )


# Global singleton instance of QuizService
quiz_service = QuizService()
