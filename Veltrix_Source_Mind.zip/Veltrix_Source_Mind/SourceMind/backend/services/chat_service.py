"""
VELTRIX SourceMind - Central Chat & RAG Service
Orchestrates query retrieval, honest refusal gating, prompt construction,
and streaming grounded responses.
"""

from typing import AsyncGenerator, Dict, Any, List, Optional
from pydantic import BaseModel, Field

from backend.core.config import settings
from backend.core.exceptions import GenerationError, RetrievalError
from backend.core.logging import logger
from backend.generation.base import BaseLLMProvider
from backend.generation.gemini_generator import GeminiGenerator
from backend.generation.mock_generator import MockLLMGenerator
from backend.generation.prompts import (
    SYSTEM_GROUNDING_PROMPT,
    STANDARD_REFUSAL_MESSAGE,
    build_chat_user_prompt
)
from backend.retrieval.retriever import Retriever, RetrievalPackage, retriever
from backend.vectorstore.base import VectorSearchResult


from backend.generation.citation_verifier import CitationVerifier


class ChatResponse(BaseModel):
    """Encapsulates a non-streaming chat answer with associated citations and metadata."""
    query: str
    answer: str
    has_matches: bool
    top_similarity: float
    citations: List[Dict[str, Any]]
    chunks_used: int
    verified_answer: Optional[str] = None
    grounding_fidelity_score: float = 1.0
    has_hallucinated_citations: bool = False


class ChatService:
    """
    Coordinates conversational QA grounded in retrieved document context.
    Enforces honest refusal when source context is insufficient.
    """

    def __init__(
        self,
        retriever_instance: Optional[Retriever] = None,
        generator_instance: Optional[BaseLLMProvider] = None
    ):
        self.retriever = retriever_instance or retriever
        self._generator = generator_instance

    @property
    def generator(self) -> BaseLLMProvider:
        """Lazy-instantiates configured LLM provider."""
        if self._generator is None:
            if not settings.GEMINI_API_KEY and settings.ENVIRONMENT == "development":
                logger.warning("No GEMINI_API_KEY detected in development. Using MockLLMGenerator.")
                self._generator = MockLLMGenerator()
            else:
                self._generator = GeminiGenerator()
        return self._generator

    def set_generator(self, generator: BaseLLMProvider) -> None:
        """Injects a custom or mock LLM provider (ideal for testing)."""
        self._generator = generator

    @staticmethod
    def _extract_citations(chunks: List[VectorSearchResult]) -> List[Dict[str, Any]]:
        """Extracts unique citation references from retrieved chunks."""
        seen = set()
        citations = []
        for chk in chunks:
            key = (chk.document_name, chk.page_number)
            if key not in seen:
                seen.add(key)
                citations.append({
                    "document_name": chk.document_name,
                    "page_number": chk.page_number,
                    "chunk_id": chk.chunk_id,
                    "similarity_score": chk.similarity_score
                })
        return citations

    async def stream_chat(
        self,
        query: str,
        document_id: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        top_k: Optional[int] = None,
        min_similarity: Optional[float] = None
    ) -> AsyncGenerator[str, None]:
        """
        Executes end-to-end streaming RAG:
        1. Retrieves relevant source chunks
        2. If no chunks pass similarity threshold: fast-path refuses immediately
        3. If chunks found: packages prompt and streams tokens from LLM
        """
        # Step 1: Execute retrieval
        pkg: RetrievalPackage = await self.retriever.retrieve(
            query=query,
            document_id=document_id,
            top_k=top_k,
            min_similarity=min_similarity
        )

        # Step 2: Honest Refusal Fast-Path
        # If zero chunks exceeded similarity threshold, refuse immediately without calling LLM
        if not pkg.has_matches or pkg.assembled_context.chunk_count == 0:
            logger.info(f"Query '{query[:50]}' yielded no relevant chunks. Yielding standard refusal.")
            yield STANDARD_REFUSAL_MESSAGE
            return

        # Step 3: Construct prompt with strict context envelope
        user_prompt = build_chat_user_prompt(
            query=query,
            assembled_context=pkg.assembled_context,
            conversation_history=conversation_history
        )

        # Step 4: Stream tokens from LLM
        logger.info(f"Streaming grounded answer for query='{query[:50]}' using {self.generator.get_model_name()}...")
        async for token in self.generator.generate_stream(
            system_prompt=SYSTEM_GROUNDING_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        ):
            yield token

    async def ask(
        self,
        query: str,
        document_id: Optional[str] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        top_k: Optional[int] = None,
        min_similarity: Optional[float] = None
    ) -> ChatResponse:
        """Non-streaming buffered QA returning answer and citation metadata."""
        pkg: RetrievalPackage = await self.retriever.retrieve(
            query=query,
            document_id=document_id,
            top_k=top_k,
            min_similarity=min_similarity
        )

        if not pkg.has_matches or pkg.assembled_context.chunk_count == 0:
            return ChatResponse(
                query=query,
                answer=STANDARD_REFUSAL_MESSAGE,
                has_matches=False,
                top_similarity=0.0,
                citations=[],
                chunks_used=0
            )

        user_prompt = build_chat_user_prompt(
            query=query,
            assembled_context=pkg.assembled_context,
            conversation_history=conversation_history
        )

        raw_answer = await self.generator.generate(
            system_prompt=SYSTEM_GROUNDING_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        )

        # If the generated response is a refusal, do not attach source citations
        is_refusal = STANDARD_REFUSAL_MESSAGE.lower() in raw_answer.lower()
        if is_refusal:
            citations = []
            verified_answer = raw_answer
            fidelity = 1.0
            has_hallucinated = False
        else:
            # Audit generated citations against actual retrieved chunks
            grounded_report = CitationVerifier.verify_citations(raw_answer, pkg.top_chunks)
            citations = [
                {
                    "document_name": c.document_name,
                    "page_number": c.page_number,
                    "chunk_id": c.matched_chunk_id or "",
                    "similarity_score": c.confidence_score,
                    "is_verified": c.is_verified,
                    "status": c.status.value
                }
                for c in grounded_report.citations
            ]
            verified_answer = grounded_report.verified_answer
            fidelity = grounded_report.grounding_fidelity_score
            has_hallucinated = grounded_report.has_hallucinated_citations

        return ChatResponse(
            query=query,
            answer=raw_answer,
            verified_answer=verified_answer,
            has_matches=not is_refusal,
            top_similarity=pkg.top_similarity,
            citations=citations,
            chunks_used=0 if is_refusal else pkg.assembled_context.chunk_count,
            grounding_fidelity_score=fidelity,
            has_hallucinated_citations=has_hallucinated
        )


# Global singleton instance of ChatService
chat_service = ChatService()
