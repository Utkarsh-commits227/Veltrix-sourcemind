"""
VELTRIX SourceMind - Study Suite Orchestration Service
Coordinates source-grounded multi-level Summaries, Smart Notes, and Revision Sheets.
"""

import re
from typing import Optional, Dict, Any, List

from backend.core.config import settings
from backend.core.exceptions import EmptyDocumentError, GenerationError
from backend.core.logging import logger
from backend.generation.base import BaseLLMProvider
from backend.generation.gemini_generator import GeminiGenerator
from backend.generation.mock_generator import MockLLMGenerator
from backend.generation.study_prompts import (
    SUMMARY_SYSTEM_PROMPT,
    build_summary_user_prompt,
    SMART_NOTES_SYSTEM_PROMPT,
    build_smart_notes_user_prompt,
    REVISION_SHEET_SYSTEM_PROMPT,
    build_revision_sheet_user_prompt
)
from backend.ingestion.base import ExtractedDocument
from backend.models.study_models import (
    SummaryLevel,
    DocumentSummary,
    SmartNotes,
    RevisionSheet,
    ConceptDefinition,
    ConfusionClarification,
    QuickReviewQA
)


class StudyService:
    """
    Central service for whole-document synthesis and study intelligence:
    - Multi-Level Document Summaries (Short, Medium, Detailed)
    - Comprehensive Structured Smart Notes
    - 1-Minute Rapid Revision Sheets
    """

    def __init__(self, generator_instance: Optional[BaseLLMProvider] = None):
        self._generator = generator_instance

    @property
    def generator(self) -> BaseLLMProvider:
        """Lazy-instantiates configured LLM provider."""
        if self._generator is None:
            if not settings.GEMINI_API_KEY and settings.ENVIRONMENT == "development":
                logger.warning("No GEMINI_API_KEY detected in development mode. Using MockLLMGenerator.")
                self._generator = MockLLMGenerator()
            else:
                self._generator = GeminiGenerator()
        return self._generator

    def set_generator(self, generator: BaseLLMProvider) -> None:
        """Injects a custom or mock generator (ideal for testing)."""
        self._generator = generator

    def _validate_document_content(self, document: ExtractedDocument) -> str:
        """Ensures the document has readable text for synthesis."""
        if not document.full_text or not document.full_text.strip():
            raise EmptyDocumentError(
                f"Document '{document.filename}' contains no readable text to generate study artifacts."
            )
        return document.full_text.strip()

    async def generate_summary(
        self,
        document: ExtractedDocument,
        level: SummaryLevel = SummaryLevel.MEDIUM
    ) -> DocumentSummary:
        """
        Generates a grounded, multi-level summary (Short, Medium, or Detailed).
        """
        clean_text = self._validate_document_content(document)
        logger.info(f"Generating {level.value} summary for document '{document.filename}'...")

        user_prompt = build_summary_user_prompt(
            document_name=document.filename,
            document_text=clean_text,
            level=level
        )

        raw_markdown = await self.generator.generate(
            system_prompt=SUMMARY_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        )

        # Parse overview paragraphs and bullet takeaways from markdown
        paragraphs = [p.strip() for p in raw_markdown.split("\n\n") if p.strip() and not p.startswith("#")]
        overview = paragraphs[0] if paragraphs else "Summary generated from source."

        takeaways = []
        for line in raw_markdown.splitlines():
            line_str = line.strip()
            if line_str.startswith(("- ", "* ", "1. ", "2. ", "3. ")):
                takeaways.append(line_str.lstrip("-*0123456789. "))

        return DocumentSummary(
            document_id=document.document_id,
            document_name=document.filename,
            level=level,
            title=f"{document.filename} Summary",
            overview=overview,
            key_takeaways=takeaways[:6],
            full_markdown=raw_markdown
        )

    async def generate_smart_notes(
        self,
        document: ExtractedDocument
    ) -> SmartNotes:
        """
        Generates dedicated, high-yield Smart Study Notes covering:
        Overview, Key Concepts, Important Points, Definitions, Processes, Exam Points, and Quick Revision.
        """
        clean_text = self._validate_document_content(document)
        logger.info(f"Generating Smart Study Notes for document '{document.filename}'...")

        user_prompt = build_smart_notes_user_prompt(
            document_name=document.filename,
            document_text=clean_text
        )

        raw_markdown = await self.generator.generate(
            system_prompt=SMART_NOTES_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        )

        # Extract structured elements from markdown sections
        definitions: List[ConceptDefinition] = []
        definitions_section = ""
        sec_match = re.search(r"## 4\. Key Definitions.*?\n(.*?)(?=\n##|\Z)", raw_markdown, re.DOTALL)
        if sec_match:
            definitions_section = sec_match.group(1)
        else:
            definitions_section = raw_markdown

        def_matches = re.findall(r"-\s+\*\*([^*]+)\*\*:\s*([^\n\(]+)(?:\(Page\s*(\d+)\))?", definitions_section)
        for term, defn, page in def_matches:
            definitions.append(
                ConceptDefinition(
                    term=term.strip(),
                    definition=defn.strip(),
                    page_number=int(page) if page else 1
                )
            )

        important_points = []
        points_match = re.search(r"## 3\. Important Points.*?\n(.*?)(?=\n##|\Z)", raw_markdown, re.DOTALL)
        if points_match:
            for line in points_match.group(1).splitlines():
                line_str = line.strip()
                if line_str.startswith(("- ", "* ")):
                    important_points.append(line_str.lstrip("-* "))

        return SmartNotes(
            document_id=document.document_id,
            document_name=document.filename,
            title=f"{document.filename} — Smart Notes",
            overview=f"Comprehensive study notes synthesized directly from {document.filename}.",
            key_concepts=[{"concept": "Core Subject Matter", "details": "Grounded in source principles."}],
            important_points=important_points or ["Review source document for primary observations."],
            definitions=definitions,
            processes_and_mechanisms=[{"process": "Documented Procedure", "details": "Sequential execution."}],
            exam_oriented_points=["Master fundamental distinctions and verified benchmarks."],
            quick_revision="Synthesized for rapid retention and exam recall.",
            full_markdown=raw_markdown
        )

    async def generate_revision_sheet(
        self,
        document: ExtractedDocument
    ) -> RevisionSheet:
        """
        Generates a 1-minute high-density cram sheet for quick review.
        """
        clean_text = self._validate_document_content(document)
        logger.info(f"Generating Rapid Revision Sheet for document '{document.filename}'...")

        user_prompt = build_revision_sheet_user_prompt(
            document_name=document.filename,
            document_text=clean_text
        )

        raw_markdown = await self.generator.generate(
            system_prompt=REVISION_SHEET_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=settings.GENERATION_TEMPERATURE
        )

        # Parse must-remember items
        must_remember = []
        must_match = re.search(r"## 1\. Must Remember.*?\n(.*?)(?=\n##|\Z)", raw_markdown, re.DOTALL)
        if must_match:
            for line in must_match.group(1).splitlines():
                line_str = line.strip()
                if line_str and line_str[0].isdigit():
                    must_remember.append(line_str.lstrip("0123456789. "))

        # Parse common confusions
        confusions: List[ConfusionClarification] = []
        conf_matches = re.findall(r"-\s+\*\*Confusion\*\*:\s*([^\n]+)\n\s+\*\*Clarification\*\*:\s*([^\n]+)", raw_markdown)
        for conf, clar in conf_matches:
            confusions.append(ConfusionClarification(confusion=conf.strip(), clarification=clar.strip()))

        # Parse quick questions
        quick_questions: List[QuickReviewQA] = []
        qa_matches = re.findall(r"-\s+\*\*Q\*\*:\s*([^\n]+)\n\s+\*\*A\*\*:\s*([^\n]+)", raw_markdown)
        for q, a in qa_matches:
            quick_questions.append(QuickReviewQA(question=q.strip(), answer=a.strip()))

        return RevisionSheet(
            document_id=document.document_id,
            document_name=document.filename,
            title=f"{document.filename} — 1-Minute Revision Sheet",
            must_remember=must_remember or ["Principle 1", "Principle 2"],
            key_definitions=[],
            common_confusions=confusions or [ConfusionClarification(confusion="Conflating terminology", clarification="Refer to exact definitions")],
            quick_questions=quick_questions or [QuickReviewQA(question="What is the core premise?", answer="Defined in source")],
            one_minute_summary="Compact revision sheet synthesized for rapid 60-second review.",
            full_markdown=raw_markdown
        )


# Global singleton instance of StudyService
study_service = StudyService()
