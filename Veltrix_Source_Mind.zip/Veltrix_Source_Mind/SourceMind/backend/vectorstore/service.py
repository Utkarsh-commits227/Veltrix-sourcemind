"""
VELTRIX SourceMind - Central Vector Store Service
Coordinates vector persistence, multi-document indexing, and similarity search.
"""

from typing import List, Optional, Dict, Any
from backend.core.logging import logger
from backend.ingestion.chunkers import DocumentChunk
from backend.vectorstore.base import BaseVectorStore, VectorSearchResult
from backend.vectorstore.chroma_store import ChromaVectorStore


class VectorStoreService:
    """
    High-level service managing vector indexing and retrieval.
    Decoupled from specific vector database engines.
    """

    def __init__(self, store: Optional[BaseVectorStore] = None):
        self._store = store

    @property
    def store(self) -> BaseVectorStore:
        """Lazy-instantiates the default ChromaVectorStore."""
        if self._store is None:
            self._store = ChromaVectorStore()
        return self._store

    def set_store(self, store: BaseVectorStore) -> None:
        """Allows injecting an alternative vector store implementation."""
        self._store = store

    async def index_chunks(
        self,
        chunks: List[DocumentChunk],
        embeddings: List[List[float]]
    ) -> None:
        """Indexes document chunks along with their vector embeddings."""
        await self.store.add_chunks(chunks, embeddings)

    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        document_id: Optional[str] = None,
        min_similarity: Optional[float] = None
    ) -> List[VectorSearchResult]:
        """
        Retrieves top-K most similar chunks to the query vector.
        Supports filtering by document_id (document isolation).
        """
        return await self.store.search(
            query_embedding=query_embedding,
            top_k=top_k,
            document_id=document_id,
            min_similarity=min_similarity
        )

    async def delete_document(self, document_id: str) -> int:
        """Removes all vectors and chunks for a specific document."""
        return await self.store.delete_document(document_id)

    async def get_stats(self, document_id: Optional[str] = None) -> Dict[str, Any]:
        """Returns collection metrics."""
        return await self.store.get_stats(document_id)


# Global singleton instance of VectorStoreService
vector_store_service = VectorStoreService()
