"""
VELTRIX SourceMind - Vector Store Abstraction
Defines abstract contracts for vector storage, approximate nearest neighbor (ANN) search,
and metadata filtering.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

from backend.ingestion.chunkers import DocumentChunk


class VectorSearchResult(BaseModel):
    """Represents a single retrieved chunk matched via vector similarity search."""
    chunk_id: str = Field(..., description="Unique chunk UUID")
    document_id: str = Field(..., description="Parent document UUID")
    document_name: str = Field(..., description="Source document filename")
    page_number: int = Field(..., description="1-indexed source page")
    chunk_index: int = Field(..., description="Sequential position in document")
    content: str = Field(..., description="Text content of the retrieved chunk")
    similarity_score: float = Field(..., description="Normalized cosine similarity score between 0.0 and 1.0")
    distance: float = Field(..., description="Raw vector distance metric")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Associated chunk metadata")


class BaseVectorStore(ABC):
    """
    Abstract Vector Store interface.
    Enables swapping underlying vector databases (ChromaDB, Qdrant, Pinecone, pgvector)
    without altering business logic or RAG retrieval code.
    """

    @abstractmethod
    async def add_chunks(
        self,
        chunks: List[DocumentChunk],
        embeddings: List[List[float]]
    ) -> None:
        """Stores chunks alongside their embedding vectors and metadata in the vector index."""
        pass

    @abstractmethod
    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        document_id: Optional[str] = None,
        min_similarity: Optional[float] = None
    ) -> List[VectorSearchResult]:
        """
        Executes approximate nearest neighbor (ANN) search for the query embedding.
        Supports document scoping (isolation) and minimum similarity thresholding.
        """
        pass

    @abstractmethod
    async def delete_document(self, document_id: str) -> int:
        """Purges all chunks and vectors associated with the given document ID."""
        pass

    @abstractmethod
    async def get_stats(self, document_id: Optional[str] = None) -> Dict[str, Any]:
        """Returns collection size, indexed chunk count, and storage metrics."""
        pass
