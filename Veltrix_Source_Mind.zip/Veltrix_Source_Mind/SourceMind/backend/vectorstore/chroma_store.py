"""
VELTRIX SourceMind - ChromaDB Vector Store Adapter
Implements persistent, local vector indexing, metadata filtering, and cosine similarity search.
"""

import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from backend.core.config import settings
from backend.core.exceptions import VectorStoreError
from backend.core.logging import logger
from backend.ingestion.chunkers import DocumentChunk
from backend.vectorstore.base import BaseVectorStore, VectorSearchResult


class ChromaVectorStore(BaseVectorStore):
    """
    ChromaDB persistent vector store implementation.
    Operates in-process, saves to local disk, and utilizes HNSW indexing with Cosine space.
    """

    def __init__(
        self,
        persist_dir: Optional[Path] = None,
        collection_name: Optional[str] = None
    ):
        self.persist_dir = persist_dir or settings.CHROMA_PERSIST_DIR
        self.collection_name = collection_name or settings.CHROMA_COLLECTION_NAME
        self.persist_dir.mkdir(parents=True, exist_ok=True)

        try:
            self._client = chromadb.PersistentClient(
                path=str(self.persist_dir),
                settings=ChromaSettings(anonymized_telemetry=False)
            )
            # Create or load collection with cosine distance metric
            self._collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            logger.info(
                f"Initialized ChromaVectorStore: path='{self.persist_dir}', "
                f"collection='{self.collection_name}', items={self._collection.count()}"
            )
        except Exception as exc:
            logger.error(f"Failed to initialize ChromaDB client: {str(exc)}")
            raise VectorStoreError(f"ChromaDB initialization failed: {str(exc)}")

    @staticmethod
    def _sanitize_metadata(metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        ChromaDB requires metadata values to be primitives (str, int, float, bool).
        Converts non-primitive values to strings.
        """
        sanitized = {}
        for k, v in metadata.items():
            if isinstance(v, (str, int, float, bool)):
                sanitized[k] = v
            elif v is None:
                sanitized[k] = ""
            else:
                sanitized[k] = str(v)
        return sanitized

    async def add_chunks(
        self,
        chunks: List[DocumentChunk],
        embeddings: List[List[float]]
    ) -> None:
        """Stores chunks, embeddings, and metadata into ChromaDB using upsert."""
        if not chunks:
            return

        if len(chunks) != len(embeddings):
            raise VectorStoreError(
                f"Mismatch: received {len(chunks)} chunks but {len(embeddings)} embeddings."
            )

        ids: List[str] = []
        documents: List[str] = []
        metadatas: List[Dict[str, Any]] = []

        for chunk in chunks:
            ids.append(chunk.chunk_id)
            documents.append(chunk.content)

            chunk_meta = {
                "document_id": chunk.document_id,
                "document_name": chunk.document_name,
                "page_number": chunk.page_number,
                "page_start": chunk.page_start,
                "page_end": chunk.page_end,
                "chunk_index": chunk.chunk_index,
                "token_count": chunk.token_count,
                "content_hash": chunk.content_hash,
                **chunk.metadata
            }
            metadatas.append(self._sanitize_metadata(chunk_meta))

        try:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                lambda: self._collection.upsert(
                    ids=ids,
                    embeddings=embeddings,
                    documents=documents,
                    metadatas=metadatas
                )
            )
            logger.info(f"Upserted {len(chunks)} chunks into ChromaDB collection '{self.collection_name}'.")
        except Exception as exc:
            logger.error(f"ChromaDB upsert failed: {str(exc)}")
            raise VectorStoreError(f"Failed to upsert chunks into ChromaDB: {str(exc)}")

    async def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        document_id: Optional[str] = None,
        min_similarity: Optional[float] = None
    ) -> List[VectorSearchResult]:
        """
        Performs approximate nearest neighbor search with optional document scoping
        and similarity threshold filtering.
        """
        if not query_embedding:
            raise VectorStoreError("Query embedding vector cannot be empty.")

        # Ensure top_k does not exceed total items in collection
        total_items = self._collection.count()
        if total_items == 0:
            return []

        adjusted_top_k = min(top_k, total_items)
        where_filter = {"document_id": document_id} if document_id else None

        try:
            loop = asyncio.get_running_loop()
            results = await loop.run_in_executor(
                None,
                lambda: self._collection.query(
                    query_embeddings=[query_embedding],
                    n_results=adjusted_top_k,
                    where=where_filter,
                    include=["documents", "metadatas", "distances"]
                )
            )
        except Exception as exc:
            logger.error(f"ChromaDB search query failed: {str(exc)}")
            raise VectorStoreError(f"Vector search failed: {str(exc)}")

        search_results: List[VectorSearchResult] = []

        if not results or not results.get("ids") or not results["ids"][0]:
            return search_results

        ids = results["ids"][0]
        docs = results["documents"][0] if results.get("documents") else [""] * len(ids)
        metas = results["metadatas"][0] if results.get("metadatas") else [{}] * len(ids)
        distances = results["distances"][0] if results.get("distances") else [0.0] * len(ids)

        threshold = min_similarity if min_similarity is not None else settings.SIMILARITY_THRESHOLD

        for chunk_id, content, meta, dist in zip(ids, docs, metas, distances):
            # Chroma with cosine metric returns cosine distance (0.0 = identical, 2.0 = opposite)
            # Convert distance to similarity score: similarity = 1.0 - distance
            similarity = max(0.0, min(1.0, 1.0 - dist))

            # Apply similarity threshold cutoff to eliminate irrelevant noise
            if similarity < threshold:
                continue

            search_results.append(
                VectorSearchResult(
                    chunk_id=chunk_id,
                    document_id=meta.get("document_id", ""),
                    document_name=meta.get("document_name", ""),
                    page_number=int(meta.get("page_number", 1)),
                    chunk_index=int(meta.get("chunk_index", 0)),
                    content=content,
                    similarity_score=round(similarity, 4),
                    distance=round(dist, 4),
                    metadata=meta
                )
            )

        # Sort descending by similarity score
        search_results.sort(key=lambda r: r.similarity_score, reverse=True)
        return search_results

    async def delete_document(self, document_id: str) -> int:
        """Purges all chunks associated with a specific document ID."""
        if not document_id:
            return 0

        try:
            loop = asyncio.get_running_loop()
            # Count items before deletion
            stats_before = self._collection.get(where={"document_id": document_id})
            deleted_count = len(stats_before["ids"]) if stats_before and stats_before.get("ids") else 0

            if deleted_count > 0:
                await loop.run_in_executor(
                    None,
                    lambda: self._collection.delete(where={"document_id": document_id})
                )
                logger.info(f"Deleted {deleted_count} chunks for document_id='{document_id}' from ChromaDB.")

            return deleted_count
        except Exception as exc:
            logger.error(f"Failed to delete document '{document_id}' from ChromaDB: {str(exc)}")
            raise VectorStoreError(f"Failed to delete document from vector index: {str(exc)}")

    async def get_stats(self, document_id: Optional[str] = None) -> Dict[str, Any]:
        """Returns storage statistics and item counts."""
        try:
            total_items = self._collection.count()
            doc_items = 0
            if document_id:
                doc_records = self._collection.get(where={"document_id": document_id})
                doc_items = len(doc_records["ids"]) if doc_records and doc_records.get("ids") else 0

            return {
                "collection_name": self.collection_name,
                "total_chunks": total_items,
                "document_chunks": doc_items if document_id else total_items,
                "persist_directory": str(self.persist_dir)
            }
        except Exception as exc:
            raise VectorStoreError(f"Failed to retrieve vector store stats: {str(exc)}")
