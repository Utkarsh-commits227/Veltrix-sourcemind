"""
VELTRIX SourceMind - Ingestion Base Abstractions & Models
Defines the core data contracts and abstract parser interfaces.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class ExtractedPage(BaseModel):
    """Represents a single page or discrete section extracted from a document."""
    page_number: int = Field(..., description="1-indexed page number or section sequence")
    text: str = Field(..., description="Cleaned, extracted text content of this page")
    char_count: int = Field(default=0, description="Number of characters on this page")
    has_text: bool = Field(default=True, description="False if page is blank or scanned image")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Page-specific metadata")


class ExtractedDocument(BaseModel):
    """
    Standardized, high-level representation of an ingested document.
    Produced by Parsers and consumed by Chunkers.
    """
    document_id: str = Field(..., description="Deterministic UUID identifying this document")
    filename: str = Field(..., description="Sanitized original filename")
    file_size_bytes: int = Field(..., description="Size of file in bytes")
    mime_type: str = Field(..., description="Detected MIME type")
    sha256_hash: str = Field(..., description="SHA-256 fingerprint for deduplication")
    page_count: int = Field(..., description="Total number of pages processed")
    total_char_count: int = Field(..., description="Total character count across all pages")
    pages: List[ExtractedPage] = Field(default_factory=list, description="Ordered extracted pages")
    full_text: str = Field(..., description="Concatenated clean text of the entire document")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Document metadata (title, author, etc.)")
    is_scanned_pdf: bool = Field(default=False, description="Flagged if document has pages but zero text")
    ingested_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class BaseParser(ABC):
    """Abstract Base Class for all document parsers (PDF, TXT, Markdown, etc.)."""

    @abstractmethod
    def can_parse(self, extension: str, mime_type: str) -> bool:
        """Determines if this parser can handle the given file type."""
        pass

    @abstractmethod
    def parse(self, file_path: Path, content: bytes, filename: str) -> ExtractedDocument:
        """Parses file bytes into an ExtractedDocument object."""
        pass
