"""
VELTRIX SourceMind - Semantic Chunking Engine
Splits extracted document text into semantically coherent segments with sliding window overlap,
strict token budgeting, and rich metadata preservation.
"""

import hashlib
import re
import uuid
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

from backend.core.config import settings
from backend.core.exceptions import ChunkingError
from backend.core.logging import logger
from backend.ingestion.base import ExtractedDocument, ExtractedPage


class DocumentChunk(BaseModel):
    """
    Core data structure representing a retrievable chunk of knowledge.
    Stored in Vector DB and retrieved during RAG queries.
    """
    chunk_id: str = Field(..., description="Unique deterministic UUID identifying this chunk")
    document_id: str = Field(..., description="UUID of the parent document")
    document_name: str = Field(..., description="Original filename of the source document")
    page_number: int = Field(..., description="Primary page number where this chunk appears")
    page_start: int = Field(..., description="First page number covered by this chunk")
    page_end: int = Field(..., description="Last page number covered by this chunk")
    chunk_index: int = Field(..., description="0-indexed sequential order within the document")
    char_start: int = Field(default=0, description="Starting character offset in full document text")
    char_end: int = Field(default=0, description="Ending character offset in full document text")
    content: str = Field(..., description="Clean text content of this chunk")
    token_count: int = Field(..., description="Estimated token count of chunk content")
    content_hash: str = Field(..., description="SHA-256 hash of content for deduplication")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Custom metadata (section titles, tags)")


class BaseChunker(ABC):
    """Abstract Base Class for document chunking algorithms."""

    @abstractmethod
    def chunk_document(self, document: ExtractedDocument) -> List[DocumentChunk]:
        """Divides an ExtractedDocument into a list of DocumentChunks."""
        pass


class RecursiveSemanticChunker(BaseChunker):
    """
    Production-grade recursive chunker that prioritizes semantic text boundaries
    (Paragraphs -> Newlines -> Sentences -> Words) before falling back to character cuts.
    Preserves page numbers, sliding overlap, and metadata.
    """

    # Typical estimation: 1 token ~= 4 characters in English text
    CHARS_PER_TOKEN = 4

    def __init__(
        self,
        chunk_size_tokens: int = 450,
        chunk_overlap_tokens: int = 90,
        separators: Optional[List[str]] = None
    ):
        if chunk_overlap_tokens >= chunk_size_tokens:
            raise ValueError("chunk_overlap_tokens must be strictly less than chunk_size_tokens")

        self.chunk_size_chars = chunk_size_tokens * self.CHARS_PER_TOKEN
        self.chunk_overlap_chars = chunk_overlap_tokens * self.CHARS_PER_TOKEN
        self.chunk_size_tokens = chunk_size_tokens
        self.chunk_overlap_tokens = chunk_overlap_tokens

        # Hierarchical separators ordered by semantic integrity
        self.separators = separators or [
            "\n\n",   # Paragraph breaks
            "\n",     # Line breaks / list items
            ". ",     # Sentence terminators
            "? ",     # Question marks
            "! ",     # Exclamation marks
            "; ",     # Semicolons
            " ",      # Word spaces
            ""        # Fallback character split
        ]

    def estimate_tokens(self, text: str) -> int:
        """Estimates token count based on standard 4-char heuristic with word boundary adjustments."""
        if not text:
            return 0
        # Combine character length and whitespace word count for balanced approximation
        char_tokens = len(text) / self.CHARS_PER_TOKEN
        word_tokens = len(text.split()) * 1.3
        return max(1, int((char_tokens + word_tokens) / 2))

    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """Recursively splits text using the highest-priority separator that fits the budget."""
        final_chunks: List[str] = []
        separator = separators[-1]
        new_separators = []

        for i, sep in enumerate(separators):
            if sep == "":
                separator = ""
                break
            if sep in text:
                separator = sep
                new_separators = separators[i + 1:]
                break

        splits = text.split(separator) if separator else list(text)

        good_splits: List[str] = []
        for s in splits:
            if separator and good_splits:
                piece = separator + s
            else:
                piece = s

            if len(piece) <= self.chunk_size_chars:
                good_splits.append(piece)
            else:
                if new_separators:
                    sub_splits = self._split_text(piece, new_separators)
                    good_splits.extend(sub_splits)
                else:
                    # Hard slice if no more separators exist
                    for j in range(0, len(piece), self.chunk_size_chars - self.chunk_overlap_chars):
                        good_splits.append(piece[j:j + self.chunk_size_chars])

        return good_splits

    def _merge_splits_with_overlap(self, splits: List[str]) -> List[str]:
        """
        Combines small splits into full chunks up to chunk_size_chars,
        ensuring adjacent chunks share chunk_overlap_chars.
        """
        chunks: List[str] = []
        current_chunk: List[str] = []
        current_length = 0

        for piece in splits:
            piece_len = len(piece)
            if current_length + piece_len > self.chunk_size_chars and current_chunk:
                merged = "".join(current_chunk).strip()
                if merged:
                    chunks.append(merged)

                # Create overlap window for the next chunk
                overlap_splits: List[str] = []
                overlap_len = 0
                for prev_piece in reversed(current_chunk):
                    if overlap_len + len(prev_piece) <= self.chunk_overlap_chars:
                        overlap_splits.insert(0, prev_piece)
                        overlap_len += len(prev_piece)
                    else:
                        break

                current_chunk = overlap_splits + [piece]
                current_length = sum(len(p) for p in current_chunk)
            else:
                current_chunk.append(piece)
                current_length += piece_len

        if current_chunk:
            merged = "".join(current_chunk).strip()
            if merged:
                chunks.append(merged)

        return chunks

    def chunk_page(self, page_text: str) -> List[str]:
        """Chunks a single page's text respecting the configured size and overlap."""
        if not page_text or not page_text.strip():
            return []

        if len(page_text.strip()) <= self.chunk_size_chars:
            return [page_text.strip()]

        raw_splits = self._split_text(page_text, self.separators)
        return self._merge_splits_with_overlap(raw_splits)

    def chunk_document(self, document: ExtractedDocument) -> List[DocumentChunk]:
        """
        Splits an ExtractedDocument page by page to ensure tight page-to-chunk citation mapping.
        Assigns sequential chunk indices, character offsets, and SHA-256 content hashes.
        """
        if not document.pages:
            raise ChunkingError(f"Document '{document.filename}' contains no extracted pages to chunk.")

        document_chunks: List[DocumentChunk] = []
        global_chunk_index = 0
        running_char_offset = 0

        for page in document.pages:
            if not page.has_text or not page.text.strip():
                continue

            page_text_chunks = self.chunk_page(page.text)

            for text_chunk in page_text_chunks:
                # Content hash for deduplication
                content_hash = hashlib.sha256(text_chunk.encode("utf-8")).hexdigest()
                
                # Deterministic chunk UUID derived from doc_id and sequential index
                chunk_uuid = str(uuid.uuid5(
                    uuid.NAMESPACE_DNS,
                    f"{document.document_id}_chk_{global_chunk_index}_{content_hash[:8]}"
                ))

                token_count = self.estimate_tokens(text_chunk)
                char_len = len(text_chunk)

                chunk = DocumentChunk(
                    chunk_id=chunk_uuid,
                    document_id=document.document_id,
                    document_name=document.filename,
                    page_number=page.page_number,
                    page_start=page.page_number,
                    page_end=page.page_number,
                    chunk_index=global_chunk_index,
                    char_start=running_char_offset,
                    char_end=running_char_offset + char_len,
                    content=text_chunk,
                    token_count=token_count,
                    content_hash=content_hash,
                    metadata={
                        **document.metadata,
                        "page_number": page.page_number,
                        "char_count": char_len
                    }
                )

                document_chunks.append(chunk)
                global_chunk_index += 1
                running_char_offset += char_len + 1

        logger.info(
            f"Chunked document '{document.filename}' into {len(document_chunks)} chunks "
            f"(target={self.chunk_size_tokens} tokens, overlap={self.chunk_overlap_tokens} tokens)."
        )

        return document_chunks
