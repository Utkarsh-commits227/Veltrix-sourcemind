"""
VELTRIX SourceMind - Text Cleaning & Normalization Engine
Sanitizes raw extracted text, normalizes Unicode, strips control characters,
and unifies whitespace while preserving paragraph and sentence boundaries.
"""

import re
import unicodedata


class TextCleaner:
    """Provides modular, pure-Python text sanitization rules for extracted document text."""

    @staticmethod
    def normalize_unicode(text: str) -> str:
        """
        Normalizes Unicode characters to NFKC (Normalization Form Compatibility Composition).
        Converts full-width characters, ligatures (e.g. 'fi' -> 'f' + 'i'), and non-standard symbols.
        """
        if not text:
            return ""
        return unicodedata.normalize("NFKC", text)

    @staticmethod
    def normalize_newlines(text: str) -> str:
        """Normalizes Windows (CRLF) and Mac (CR) newlines to standard Unix (LF)."""
        if not text:
            return ""
        return text.replace("\r\n", "\n").replace("\r", "\n")

    @staticmethod
    def remove_control_characters(text: str) -> str:
        """
        Strips non-printable ASCII/Unicode control characters while preserving
        newlines, carriage returns, and tabs.
        """
        if not text:
            return ""
        # Keep \n (0x0A), \t (0x09)
        return "".join(ch for ch in text if ch in ("\n", "\t") or unicodedata.category(ch)[0] != "C")

    @staticmethod
    def collapse_whitespace(text: str) -> str:
        """
        Collapses repetitive horizontal whitespace (spaces, tabs) into a single space,
        while preserving intentional double newlines (\n\n) that demarcate paragraphs.
        """
        if not text:
            return ""
        lines = text.split("\n")
        cleaned_lines = []
        for line in lines:
            # Replace consecutive spaces and tabs with a single space
            cleaned_line = re.sub(r"[ \t]+", " ", line).strip()
            cleaned_lines.append(cleaned_line)

        # Collapse more than 2 consecutive newlines into exactly 2
        joined = "\n".join(cleaned_lines)
        return re.sub(r"\n{3,}", "\n\n", joined).strip()

    @staticmethod
    def sanitize_page_text(text: str) -> str:
        """
        Applies full normalization pipeline to a single page's extracted text.
        """
        if not text:
            return ""
        text = TextCleaner.normalize_unicode(text)
        text = TextCleaner.normalize_newlines(text)
        text = TextCleaner.remove_control_characters(text)
        text = TextCleaner.collapse_whitespace(text)
        return text
