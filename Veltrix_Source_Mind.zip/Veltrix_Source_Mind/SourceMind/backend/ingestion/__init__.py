"""Document ingestion, parsing, cleaning, and validation."""
