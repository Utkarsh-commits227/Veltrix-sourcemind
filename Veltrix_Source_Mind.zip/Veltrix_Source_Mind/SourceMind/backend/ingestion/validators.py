"""
VELTRIX SourceMind - Document Ingestion Validators
Enforces strict file type, size, signature, and integrity checks before parsing.
"""

from pathlib import Path
from typing import Tuple

from backend.core.config import settings
from backend.core.exceptions import (
    FileTooLargeError,
    UnsupportedFileError,
    EmptyDocumentError,
    CorruptedFileError,
    ValidationError
)
from backend.core.security import detect_file_signature, sanitize_filename


class FileValidator:
    """Validates raw file uploads for security, integrity, and compatibility."""

    @staticmethod
    def validate_file_size(content: bytes) -> None:
        """Ensures file size does not exceed configured limits."""
        size = len(content)
        if size == 0:
            raise EmptyDocumentError("The uploaded file is empty (0 bytes).")
        if size > settings.MAX_FILE_SIZE_BYTES:
            max_mb = settings.MAX_FILE_SIZE_BYTES / (1024 * 1024)
            curr_mb = size / (1024 * 1024)
            raise FileTooLargeError(
                f"File size ({curr_mb:.2f} MB) exceeds maximum allowed limit of {max_mb:.1f} MB."
            )

    @staticmethod
    def validate_filename_and_extension(filename: str) -> Tuple[str, str]:
        """
        Validates and sanitizes filename.
        Returns: (sanitized_filename, lowercase_extension)
        """
        if not filename or not filename.strip():
            raise ValidationError("Filename cannot be empty.")

        clean_name = sanitize_filename(filename)
        suffix = Path(clean_name).suffix.lower()

        if suffix not in settings.ALLOWED_EXTENSIONS:
            allowed = ", ".join(sorted(settings.ALLOWED_EXTENSIONS))
            raise UnsupportedFileError(
                f"Extension '{suffix}' is not supported. Supported extensions: {allowed}."
            )

        return clean_name, suffix

    @staticmethod
    def validate_signature(content: bytes, claimed_extension: str) -> str:
        """
        Verifies magic bytes against claimed extension to prevent spoofed uploads.
        Returns detected MIME type.
        """
        detected_ext, detected_mime = detect_file_signature(content)

        # For PDFs, enforce strict magic byte check (%PDF-)
        if claimed_extension == ".pdf":
            if not content.startswith(b"%PDF-"):
                raise CorruptedFileError(
                    "File has a .pdf extension but does not contain valid PDF header magic bytes."
                )
            return "application/pdf"

        # For text documents (.txt, .md), verify it is valid readable text
        if claimed_extension in {".txt", ".md"}:
            if detected_mime not in settings.ALLOWED_MIME_TYPES and detected_mime != "application/octet-stream":
                raise UnsupportedFileError(
                    f"File appears to be a binary format ({detected_mime}), not a valid text document."
                )
            return "text/plain" if claimed_extension == ".txt" else "text/markdown"

        return detected_mime

    @classmethod
    def validate_upload(cls, filename: str, content: bytes) -> Tuple[str, str, str]:
        """
        Complete validation gate for an incoming file upload.
        Returns: (sanitized_filename, extension, mime_type)
        """
        clean_name, ext = cls.validate_filename_and_extension(filename)
        cls.validate_file_size(content)
        mime_type = cls.validate_signature(content, ext)
        return clean_name, ext, mime_type
