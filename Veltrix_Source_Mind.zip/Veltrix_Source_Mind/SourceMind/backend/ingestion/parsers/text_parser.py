"""
VELTRIX SourceMind - Robust Text & Markdown Parser
Parses plain text (.txt) and Markdown (.md) documents with multi-encoding fallback,
header detection, and logical section pagination.
"""

import re
import uuid
from pathlib import Path
from typing import List, Dict, Any, Tuple

from backend.core.exceptions import EmptyDocumentError, CorruptedFileError
from backend.core.logging import logger
from backend.core.security import compute_sha256
from backend.ingestion.base import BaseParser, ExtractedDocument, ExtractedPage
from backend.ingestion.cleaners import TextCleaner


class TextParser(BaseParser):
    """Parser for plain text (.txt) and Markdown (.md) files with encoding resilience."""

    SUPPORTED_EXTENSIONS = {".txt", ".md"}
    # Approximate page length in characters for synthetic page mapping of flat text files
    CHARS_PER_SYNTHETIC_PAGE = 2500

    def can_parse(self, extension: str, mime_type: str) -> bool:
        return extension.lower() in self.SUPPORTED_EXTENSIONS or mime_type in {
            "text/plain",
            "text/markdown"
        }

    @staticmethod
    def decode_bytes(content: bytes, filename: str) -> str:
        """
        Attempts to decode file bytes using common text encodings with fallbacks.
        Tries UTF-8, UTF-8 with BOM, Latin-1, and Windows CP1252.
        """
        encodings = ["utf-8-sig", "utf-8", "latin-1", "cp1252"]
        for enc in encodings:
            try:
                return content.decode(enc)
            except UnicodeDecodeError:
                continue

        # If all strict decodings fail, decode with replacement
        logger.warning(f"Could not cleanly decode '{filename}'. Falling back to UTF-8 with replacement.")
        return content.decode("utf-8", errors="replace")

    @classmethod
    def extract_markdown_metadata(cls, text: str) -> Dict[str, Any]:
        """Extracts document title from top heading or YAML frontmatter if present."""
        metadata: Dict[str, Any] = {}
        # Check for first H1 header: # Title
        h1_match = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
        if h1_match:
            metadata["title"] = h1_match.group(1).strip()
        return metadata

    def parse(self, file_path: Path, content: bytes, filename: str) -> ExtractedDocument:
        if not content or len(content.strip()) == 0:
            raise EmptyDocumentError(f"Text file '{filename}' is empty.")

        raw_text = self.decode_bytes(content, filename)
        cleaned_text = TextCleaner.sanitize_page_text(raw_text)

        if not cleaned_text or len(cleaned_text.strip()) == 0:
            raise EmptyDocumentError(f"Text file '{filename}' contains no readable text after cleaning.")

        metadata = self.extract_markdown_metadata(raw_text)
        extension = Path(filename).suffix.lower()
        mime_type = "text/markdown" if extension == ".md" else "text/plain"

        # Create logical synthetic pages to maintain consistent citation mechanics
        # For markdown, split by major headers (# or ##) if suitable, or chunk by length
        extracted_pages: List[ExtractedPage] = []
        
        # Split into blocks of roughly CHARS_PER_SYNTHETIC_PAGE characters respecting paragraph breaks
        paragraphs = cleaned_text.split("\n\n")
        current_page_paragraphs: List[str] = []
        current_char_count = 0
        page_index = 1

        for para in paragraphs:
            para_len = len(para)
            if current_char_count + para_len > self.CHARS_PER_SYNTHETIC_PAGE and current_page_paragraphs:
                # Flush current page
                page_text = "\n\n".join(current_page_paragraphs)
                extracted_pages.append(
                    ExtractedPage(
                        page_number=page_index,
                        text=page_text,
                        char_count=len(page_text),
                        has_text=True,
                        metadata={"section_type": "text_block"}
                    )
                )
                page_index += 1
                current_page_paragraphs = [para]
                current_char_count = para_len
            else:
                current_page_paragraphs.append(para)
                current_char_count += para_len + 2

        # Flush final page
        if current_page_paragraphs:
            page_text = "\n\n".join(current_page_paragraphs)
            extracted_pages.append(
                ExtractedPage(
                    page_number=page_index,
                    text=page_text,
                    char_count=len(page_text),
                    has_text=True,
                    metadata={"section_type": "text_block"}
                )
            )

        sha256_hash = compute_sha256(content)
        doc_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{filename}_{sha256_hash}"))

        return ExtractedDocument(
            document_id=doc_id,
            filename=filename,
            file_size_bytes=len(content),
            mime_type=mime_type,
            sha256_hash=sha256_hash,
            page_count=len(extracted_pages),
            total_char_count=len(cleaned_text),
            pages=extracted_pages,
            full_text=cleaned_text,
            metadata=metadata,
            is_scanned_pdf=False
        )
