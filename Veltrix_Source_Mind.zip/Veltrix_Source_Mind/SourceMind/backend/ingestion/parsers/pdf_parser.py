"""
VELTRIX SourceMind - Robust PDF Parser
Extracts text page-by-page from PDFs, preserves page structure and metadata,
detects scanned documents without text, and handles corrupted or encrypted files.
"""

import io
import uuid
from pathlib import Path
from typing import List, Dict, Any

from pypdf import PdfReader
from pypdf.errors import PdfReadError

from backend.core.config import settings
from backend.core.exceptions import (
    CorruptedFileError,
    ScannedDocumentError,
    EmptyDocumentError,
    ExtractionError
)
from backend.core.logging import logger
from backend.core.security import compute_sha256
from backend.ingestion.base import BaseParser, ExtractedDocument, ExtractedPage
from backend.ingestion.cleaners import TextCleaner


class PDFParser(BaseParser):
    """Production PDF parser utilizing pypdf with robust page tracking and scanned-PDF detection."""

    def can_parse(self, extension: str, mime_type: str) -> bool:
        return extension.lower() == ".pdf" or mime_type == "application/pdf"

    def parse(self, file_path: Path, content: bytes, filename: str) -> ExtractedDocument:
        """
        Parses a PDF file from bytes.
        Preserves page boundaries, extracts metadata, sanitizes text,
        and detects scanned image documents.
        """
        if not content:
            raise EmptyDocumentError(f"PDF file '{filename}' is empty.")

        file_stream = io.BytesIO(content)

        try:
            reader = PdfReader(file_stream)
        except (PdfReadError, Exception) as exc:
            logger.error(f"Failed to open PDF '{filename}': {str(exc)}")
            raise CorruptedFileError(f"PDF file '{filename}' is corrupted or unreadable: {str(exc)}")

        if reader.is_encrypted:
            try:
                # Attempt empty password decryption
                decrypted = reader.decrypt("")
                if decrypted == 0:
                    raise CorruptedFileError(f"PDF '{filename}' is password-encrypted and cannot be processed.")
            except Exception:
                raise CorruptedFileError(f"PDF '{filename}' is password-encrypted.")

        page_count = len(reader.pages)
        if page_count == 0:
            raise EmptyDocumentError(f"PDF '{filename}' contains 0 pages.")

        # Extract metadata from PDF dictionary
        pdf_metadata: Dict[str, Any] = {}
        if reader.metadata:
            for key, val in reader.metadata.items():
                clean_key = key.lstrip("/").lower()
                pdf_metadata[clean_key] = str(val) if val else ""

        extracted_pages: List[ExtractedPage] = []
        total_chars = 0
        pages_with_text = 0

        for idx, page in enumerate(reader.pages):
            page_num = idx + 1
            try:
                raw_page_text = page.extract_text() or ""
            except Exception as e:
                logger.warning(f"Error extracting text from page {page_num} in '{filename}': {str(e)}")
                raw_page_text = ""

            cleaned_page_text = TextCleaner.sanitize_page_text(raw_page_text)
            char_count = len(cleaned_page_text)
            has_text = char_count >= settings.MIN_PAGE_CHAR_COUNT

            if has_text:
                pages_with_text += 1

            total_chars += char_count
            extracted_pages.append(
                ExtractedPage(
                    page_number=page_num,
                    text=cleaned_page_text,
                    char_count=char_count,
                    has_text=has_text,
                    metadata={"raw_length": len(raw_page_text)}
                )
            )

        # Scanned PDF Detection:
        # If total characters across all pages is 0, or average chars per page is virtually empty
        is_scanned = (total_chars == 0) or (pages_with_text == 0)
        if is_scanned:
            logger.warning(f"Document '{filename}' has {page_count} pages but 0 extractable text characters.")
            raise ScannedDocumentError(
                f"PDF '{filename}' appears to be a scanned image without an embedded digital text layer. "
                f"SourceMind requires digital text to index and ground knowledge."
            )

        # Build concatenated full document text with clear page markers
        full_text_blocks = []
        for p in extracted_pages:
            if p.text:
                full_text_blocks.append(f"--- [Page {p.page_number}] ---\n{p.text}")

        full_text = "\n\n".join(full_text_blocks)
        sha256_hash = compute_sha256(content)
        doc_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{filename}_{sha256_hash}"))

        return ExtractedDocument(
            document_id=doc_id,
            filename=filename,
            file_size_bytes=len(content),
            mime_type="application/pdf",
            sha256_hash=sha256_hash,
            page_count=page_count,
            total_char_count=total_chars,
            pages=extracted_pages,
            full_text=full_text,
            metadata=pdf_metadata,
            is_scanned_pdf=False
        )
