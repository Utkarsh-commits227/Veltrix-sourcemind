"""
VELTRIX SourceMind - Application Entrypoint
FastAPI application initializing CORS, API routes, static asset delivery, and error handling.
"""

from pathlib import Path
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api.router import api_router
from backend.core.config import settings
from backend.core.exceptions import SourceMindException
from backend.core.logging import logger
from backend.core.middleware import RequestTracingMiddleware, RateLimitMiddleware

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="High-Assurance Source-Grounded Generative AI & Study Platform inspired by NotebookLM.",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Request Tracing & Rate Limiting Middleware
app.add_middleware(RateLimitMiddleware)
app.add_middleware(RequestTracingMiddleware)

# CORS Configuration for local web frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Exception handler for domain-specific SourceMind errors
@app.exception_handler(SourceMindException)
async def sourcemind_exception_handler(request: Request, exc: SourceMindException):
    logger.warning(f"Domain exception on {request.url.path}: {exc.code} - {exc.message}")
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=exc.to_dict()
    )


# Catch-all exception handler to prevent internal stack trace leakage
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    req_id = getattr(request.state, "request_id", "unknown")
    logger.error(f"Unhandled exception on {request.url.path} [ID={req_id}]: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected internal server error occurred.",
                "request_id": req_id
            }
        }
    )


# Attach API router
app.include_router(api_router)

# Mount frontend static files and root Single Page Application route
frontend_dir = settings.BASE_DIR / "frontend"
static_dir = frontend_dir / "static"
static_dir.mkdir(parents=True, exist_ok=True)
(static_dir / "css").mkdir(parents=True, exist_ok=True)
(static_dir / "js").mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


@app.get("/", include_in_schema=False)
async def serve_spa_root():
    """Serves the SourceMind Web Studio UI Single Page Application."""
    index_path = frontend_dir / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path))
    return JSONResponse({
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "message": "VELTRIX SourceMind API is active. Open /docs for API documentation."
    })


if __name__ == "__main__":
    import uvicorn
    logger.info(f"Starting {settings.APP_NAME} server on http://127.0.0.1:8000 ...")
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
