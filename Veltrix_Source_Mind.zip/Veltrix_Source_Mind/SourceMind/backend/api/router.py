"""
VELTRIX SourceMind - Central API Router
Aggregates all endpoint routers with /api prefix.
"""

from fastapi import APIRouter
from backend.api.routes.health import router as health_router
from backend.api.routes.documents import router as documents_router
from backend.api.routes.chat import router as chat_router
from backend.api.routes.study import router as study_router
from backend.api.routes.quiz import router as quiz_router

api_router = APIRouter(prefix="/api")

api_router.include_router(health_router)
api_router.include_router(documents_router)
api_router.include_router(chat_router)
api_router.include_router(study_router)
api_router.include_router(quiz_router)
