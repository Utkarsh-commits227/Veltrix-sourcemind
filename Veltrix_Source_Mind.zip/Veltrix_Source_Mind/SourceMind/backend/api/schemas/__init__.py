"""
VELTRIX SourceMind - API Request and Response Schemas
"""
