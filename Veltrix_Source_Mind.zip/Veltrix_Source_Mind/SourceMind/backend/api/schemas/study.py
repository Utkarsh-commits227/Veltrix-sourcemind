"""
VELTRIX SourceMind - Study Suite API Schemas
"""

from typing import Optional
from pydantic import BaseModel, Field
from backend.models.study_models import SummaryLevel, DocumentSummary, SmartNotes, RevisionSheet


class SummaryRequest(BaseModel):
    """Request payload for multi-level summary generation."""
    document_id: str = Field(..., description="ID of the document to summarize")
    level: SummaryLevel = Field(default=SummaryLevel.MEDIUM, description="Summary depth: short | medium | detailed")


class SmartNotesRequest(BaseModel):
    """Request payload for structured Smart Revision Notes."""
    document_id: str = Field(..., description="ID of the document to extract Smart Notes from")


class RevisionSheetRequest(BaseModel):
    """Request payload for 1-minute rapid revision sheet."""
    document_id: str = Field(..., description="ID of the document to condense into a Revision Sheet")
