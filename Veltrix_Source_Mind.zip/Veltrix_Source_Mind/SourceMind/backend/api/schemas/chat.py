"""
VELTRIX SourceMind - Conversational QA & Grounded Chat API Schemas
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    """Payload for grounded conversational queries."""
    query: str = Field(..., min_length=1, description="User question or research prompt")
    document_id: Optional[str] = Field(default=None, description="Optional document ID filter for single-doc scoping")
    conversation_history: Optional[List[Dict[str, str]]] = Field(default=None, description="Prior conversation messages [{'role': 'user'|'assistant', 'content': '...'}]")
    top_k: Optional[int] = Field(default=None, description="Optional override for chunk retrieval count")
    min_similarity: Optional[float] = Field(default=None, description="Optional override for similarity cutoff")


class CitationItem(BaseModel):
    """Structured verifiable citation reference."""
    document_name: str
    page_number: int
    chunk_id: Optional[str] = None
    similarity_score: Optional[float] = None
    verified: bool = True
    claim: Optional[str] = None
    status: Optional[str] = "VERIFIED"


class ChatResponseSchema(BaseModel):
    """Structured response for buffered grounded QA."""
    query: str
    answer: str
    verified_answer: Optional[str] = None
    has_matches: bool
    top_similarity: float
    citations: List[CitationItem] = []
    chunks_used: int = 0
    grounding_fidelity_score: float = 1.0
    has_hallucinated_citations: bool = False
