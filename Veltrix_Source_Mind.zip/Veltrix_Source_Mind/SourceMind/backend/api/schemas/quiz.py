"""
VELTRIX SourceMind - Quiz & Practice Test API Schemas
"""

from typing import Dict, Optional, Any
from pydantic import BaseModel, Field
from backend.models.quiz_models import DifficultyLevel, Quiz, QuizEvaluationResult


class QuizGenerateRequest(BaseModel):
    """Request payload for generating a practice test."""
    document_id: str = Field(..., description="ID of the document to quiz on")
    num_questions: int = Field(default=5, ge=1, le=20, description="Number of questions to generate (1-20)")
    difficulty: DifficultyLevel = Field(default=DifficultyLevel.MEDIUM, description="Difficulty level: easy | medium | hard")


class QuizEvaluateRequest(BaseModel):
    """Request payload for grading user quiz answers."""
    quiz: Quiz = Field(..., description="The quiz object being evaluated")
    user_answers: Dict[str, str] = Field(..., description="Map of question_id to selected option letter (e.g. {'q1': 'A'})")
