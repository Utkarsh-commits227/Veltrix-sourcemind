"""
VELTRIX SourceMind - Document API Schemas
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class DocumentInfo(BaseModel):
    """Summarized metadata for an indexed document."""
    document_id: str
    filename: str
    mime_type: str
    file_size_bytes: int
    page_count: int
    total_char_count: int
    chunk_count: int
    ingested_at: str
    status: str = "INDEXED"


class DocumentListResponse(BaseModel):
    """Collection of indexed documents."""
    documents: List[DocumentInfo]
    total_count: int


class PageDetail(BaseModel):
    """Full page details for Source Inspector reading view."""
    page_number: int
    text: str
    char_count: int
    has_text: bool


class DocumentDetailResponse(BaseModel):
    """Complete document detail with pages for Source Inspector."""
    document: DocumentInfo
    pages: List[PageDetail]


class DocumentUploadResponse(BaseModel):
    """Response returned upon successful document upload and indexing."""
    document: DocumentInfo
    chunks_created: int
    message: str


class DocumentDeleteResponse(BaseModel):
    """Response returned after deleting a document."""
    document_id: str
    deleted: bool
    message: str
