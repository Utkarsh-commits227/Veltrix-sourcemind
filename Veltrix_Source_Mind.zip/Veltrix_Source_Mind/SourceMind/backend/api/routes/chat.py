"""
VELTRIX SourceMind - Conversational Grounded Chat Routes
Provides buffered grounded QA and real-time Server-Sent Events (SSE) token streaming.
"""

import json
from typing import AsyncGenerator
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import StreamingResponse

from backend.api.schemas.chat import (
    ChatRequest,
    ChatResponseSchema,
    CitationItem
)
from backend.core.logging import logger
from backend.services.chat_service import chat_service

router = APIRouter(prefix="/chat", tags=["Chat"])


@router.post("", response_model=ChatResponseSchema)
async def ask_question(request: ChatRequest):
    """
    Executes a buffered, source-grounded QA query:
    1. Retrieves top-K context chunks filtered by document_id (if provided)
    2. Enforces honest refusal if similarity threshold is not met
    3. Assembles strict XML context and prompts LLM
    4. Audits citations using CitationVerifier and sanitizes hallucinations
    5. Returns grounded answer, citation metadata, and fidelity score
    """
    try:
        resp = await chat_service.ask(
            query=request.query,
            document_id=request.document_id,
            conversation_history=request.conversation_history,
            top_k=request.top_k,
            min_similarity=request.min_similarity
        )

        citation_items = [
            CitationItem(
                document_name=c.get("document_name", ""),
                page_number=c.get("page_number", 1),
                chunk_id=c.get("chunk_id"),
                similarity_score=c.get("similarity_score"),
                verified=c.get("is_verified", True),
                status=c.get("status", "VERIFIED")
            )
            for c in resp.citations
        ]

        return ChatResponseSchema(
            query=resp.query,
            answer=resp.answer,
            verified_answer=resp.verified_answer,
            has_matches=resp.has_matches,
            top_similarity=resp.top_similarity,
            citations=citation_items,
            chunks_used=resp.chunks_used,
            grounding_fidelity_score=resp.grounding_fidelity_score,
            has_hallucinated_citations=resp.has_hallucinated_citations
        )

    except Exception as exc:
        logger.error(f"Error processing chat query: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while generating grounded answer: {str(exc)}"
        )


@router.post("/stream")
async def stream_chat(request: ChatRequest):
    """
    Streams grounded answer tokens in real-time via Server-Sent Events (SSE).
    Outputs JSON payloads: `data: {"token": "..."}\n\n` followed by `data: [DONE]\n\n`.
    """
    async def event_generator() -> AsyncGenerator[str, None]:
        try:
            async for token in chat_service.stream_chat(
                query=request.query,
                document_id=request.document_id,
                conversation_history=request.conversation_history,
                top_k=request.top_k,
                min_similarity=request.min_similarity
            ):
                payload = json.dumps({"token": token})
                yield f"data: {payload}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            logger.error(f"Streaming error: {e}", exc_info=True)
            err_payload = json.dumps({"error": str(e)})
            yield f"data: {err_payload}\n\n"
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )
