"""
VELTRIX SourceMind - System Health & Telemetry Route
"""

from fastapi import APIRouter
from backend.core.config import settings
from backend.vectorstore.service import vector_store_service

router = APIRouter(tags=["Health"])


@router.get("/health")
async def health_check():
    """System health, environment status, and vector database stats."""
    try:
        vector_stats = await vector_store_service.get_stats()
    except Exception:
        vector_stats = {"total_chunks": 0, "status": "unavailable"}

    return {
        "status": "healthy",
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT,
        "embedding_provider": settings.EMBEDDING_PROVIDER,
        "generation_model": settings.GENERATION_MODEL,
        "vector_stats": vector_stats
    }
