"""
VELTRIX SourceMind - Interactive Quiz & Practice Test Routes
Handles practice test generation and instant automated grading.
"""

from fastapi import APIRouter, HTTPException, status
from backend.api.schemas.quiz import QuizGenerateRequest, QuizEvaluateRequest
from backend.core.logging import logger
from backend.models.quiz_models import Quiz, QuizEvaluationResult
from backend.services.document_registry import document_registry
from backend.services.quiz_service import quiz_service

router = APIRouter(prefix="/quiz", tags=["Quiz"])


@router.post("/generate", response_model=Quiz)
async def generate_quiz(request: QuizGenerateRequest):
    """
    Generates a structured, source-grounded active-recall practice test:
    - Multiple-choice questions with 4 plausible options (A, B, C, D)
    - Verified correct answers and detailed explanations
    - Source page citations
    """
    doc = document_registry.get_document(request.document_id)
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{request.document_id}' not found in registry."
        )

    try:
        return await quiz_service.generate_quiz(
            document=doc,
            num_questions=request.num_questions,
            difficulty=request.difficulty
        )
    except Exception as exc:
        logger.error(f"Failed to generate quiz: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Quiz generation error: {str(exc)}"
        )


@router.post("/evaluate", response_model=QuizEvaluationResult)
async def evaluate_quiz(request: QuizEvaluateRequest):
    """
    Instantly grades submitted answers against verified answer keys:
    - Calculates exact score percentage and pass/fail status (>= 70%)
    - Provides per-question breakdowns with source page citations and explanations
    """
    try:
        return quiz_service.evaluate_quiz(
            quiz=request.quiz,
            user_answers=request.user_answers
        )
    except Exception as exc:
        logger.error(f"Failed to evaluate quiz: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Quiz evaluation error: {str(exc)}"
        )
