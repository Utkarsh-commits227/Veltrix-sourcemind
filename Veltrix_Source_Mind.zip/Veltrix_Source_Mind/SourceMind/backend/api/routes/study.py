"""
VELTRIX SourceMind - Study Suite Routes
Provides endpoints for multi-level Summaries, Smart Notes, and 1-Minute Revision Sheets.
"""

from fastapi import APIRouter, HTTPException, status
from backend.api.schemas.study import SummaryRequest, SmartNotesRequest, RevisionSheetRequest
from backend.core.logging import logger
from backend.models.study_models import DocumentSummary, SmartNotes, RevisionSheet
from backend.services.document_registry import document_registry
from backend.services.study_service import study_service

router = APIRouter(prefix="/study", tags=["Study Suite"])


@router.post("/summary", response_model=DocumentSummary)
async def generate_summary(request: SummaryRequest):
    """
    Synthesizes a source-grounded multi-level summary:
    - Short: Executive 1-2 paragraph briefing
    - Medium: Analytical 3-5 paragraph breakdown with key takeaways
    - Detailed: Comprehensive section-by-section analysis
    """
    doc = document_registry.get_document(request.document_id)
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{request.document_id}' not found in registry."
        )

    try:
        return await study_service.generate_summary(doc, level=request.level)
    except Exception as exc:
        logger.error(f"Failed to generate summary: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Summary generation error: {str(exc)}"
        )


@router.post("/notes", response_model=SmartNotes)
async def generate_smart_notes(request: SmartNotesRequest):
    """
    Synthesizes structured, exam-oriented Smart Revision Notes:
    - Executive Overview
    - Key Concepts & Core Ideas
    - Formal Definitions with Page Citations
    - Cause-and-Effect / Processes & Mechanisms
    - High-Yield Exam Points & Rapid Review Recap
    """
    doc = document_registry.get_document(request.document_id)
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{request.document_id}' not found in registry."
        )

    try:
        return await study_service.generate_smart_notes(doc)
    except Exception as exc:
        logger.error(f"Failed to generate smart notes: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Smart notes generation error: {str(exc)}"
        )


@router.post("/revision", response_model=RevisionSheet)
async def generate_revision_sheet(request: RevisionSheetRequest):
    """
    Synthesizes a high-yield, 1-minute cram sheet:
    - Non-negotiable core facts ("Must Remember at All Costs")
    - Common misconceptions & subtle confusions clarified
    - Rapid-fire active recall Q&As
    """
    doc = document_registry.get_document(request.document_id)
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document '{request.document_id}' not found in registry."
        )

    try:
        return await study_service.generate_revision_sheet(doc)
    except Exception as exc:
        logger.error(f"Failed to generate revision sheet: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Revision sheet generation error: {str(exc)}"
        )
