"""
VELTRIX SourceMind - Document Ingestion & Management Routes
Handles upload, indexing, retrieval of original page contents, and deletion.
"""

from fastapi import APIRouter, UploadFile, File, HTTPException, status
from typing import List

from backend.api.schemas.document import (
    DocumentInfo,
    DocumentListResponse,
    DocumentDetailResponse,
    DocumentUploadResponse,
    DocumentDeleteResponse,
    PageDetail
)
from backend.core.exceptions import SourceMindException
from backend.core.logging import logger
from backend.embeddings.service import embedding_service
from backend.services.document_registry import document_registry
from backend.services.ingestion_service import ingestion_service
from backend.vectorstore.service import vector_store_service

router = APIRouter(prefix="/documents", tags=["Documents"])


@router.post("/upload", response_model=DocumentUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(file: UploadFile = File(...)):
    """
    Ingests and indexes a new source document (PDF, TXT, MD):
    1. Validates magic bytes, size, and extension
    2. Parses text and tracks exact page numbers
    3. Semantically chunks content with overlaps
    4. Computes high-dimensional vector embeddings
    5. Persists vectors into ChromaDB and registers metadata
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="Uploaded file must have a valid filename.")

    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes).")

    try:
        # Ingestion & Semantic Chunking
        extracted_doc, chunks = ingestion_service.ingest_and_chunk(
            filename=file.filename,
            content=content,
            save_to_disk=True
        )

        # Vector Embedding & ChromaDB Indexing
        embeddings = await embedding_service.embed_chunks(chunks)
        await vector_store_service.index_chunks(chunks, embeddings)

        # Register in persistent document registry
        document_registry.register_document(extracted_doc, chunk_count=len(chunks))

        doc_info = DocumentInfo(
            document_id=extracted_doc.document_id,
            filename=extracted_doc.filename,
            mime_type=extracted_doc.mime_type,
            file_size_bytes=extracted_doc.file_size_bytes,
            page_count=extracted_doc.page_count,
            total_char_count=extracted_doc.total_char_count,
            chunk_count=len(chunks),
            ingested_at=extracted_doc.ingested_at.isoformat(),
            status="INDEXED"
        )

        return DocumentUploadResponse(
            document=doc_info,
            chunks_created=len(chunks),
            message=f"Successfully indexed '{extracted_doc.filename}' ({extracted_doc.page_count} pages, {len(chunks)} chunks)."
        )

    except SourceMindException as sme:
        logger.warning(f"Ingestion rejected for {file.filename}: {sme.message}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={"code": sme.code, "message": sme.message, "details": sme.details}
        )
    except Exception as exc:
        logger.error(f"Unexpected error during document ingestion: {exc}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An unexpected internal error occurred while processing '{file.filename}'."
        )


@router.get("", response_model=DocumentListResponse)
async def list_documents():
    """Lists all indexed documents available in the knowledge vault."""
    docs = document_registry.list_documents()
    return DocumentListResponse(
        documents=[DocumentInfo(**d) for d in docs],
        total_count=len(docs)
    )


@router.get("/{document_id}", response_model=DocumentDetailResponse)
async def get_document(document_id: str):
    """Retrieves full document metadata and page text for the Source Inspector."""
    doc = document_registry.get_document(document_id)
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document with ID '{document_id}' not found."
        )

    doc_info = DocumentInfo(
        document_id=doc.document_id,
        filename=doc.filename,
        mime_type=doc.mime_type,
        file_size_bytes=doc.file_size_bytes,
        page_count=doc.page_count,
        total_char_count=doc.total_char_count,
        chunk_count=document_registry._chunk_counts.get(document_id, 0),
        ingested_at=doc.ingested_at.isoformat(),
        status="INDEXED"
    )

    pages = [
        PageDetail(
            page_number=p.page_number,
            text=p.text,
            char_count=p.char_count,
            has_text=p.has_text
        )
        for p in doc.pages
    ]

    return DocumentDetailResponse(document=doc_info, pages=pages)


@router.delete("/{document_id}", response_model=DocumentDeleteResponse)
async def delete_document(document_id: str):
    """Removes a document from memory, vector store, and physical disk storage."""
    deleted = await document_registry.delete_document(document_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document with ID '{document_id}' not found."
        )

    return DocumentDeleteResponse(
        document_id=document_id,
        deleted=True,
        message=f"Document '{document_id}' and all associated vector embeddings successfully deleted."
    )
