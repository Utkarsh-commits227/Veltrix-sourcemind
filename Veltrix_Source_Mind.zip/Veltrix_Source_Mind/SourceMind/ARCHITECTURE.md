# 🏛️ VELTRIX SourceMind — Architectural Blueprint

> **High-Assurance, Source-Grounded Generative AI Research & Study Studio**  
> *Architectural Specification, Component Design, Data Flow Pipelines, and Safety Guardrails.*

---

## 📑 Table of Contents
1. [Architectural Philosophy & Principles](#1-architectural-philosophy--principles)
2. [End-to-End System Data Flow](#2-end-to-end-system-data-flow)
3. [Subsystem Deep Dives](#3-subsystem-deep-dives)
   - [3.1 Ingestion & Document Validation](#31-ingestion--document-validation)
   - [3.2 Recursive Semantic Chunking & Page Tracking](#32-recursive-semantic-chunking--page-tracking)
   - [3.3 Embedding Service & High-Performance Caching](#33-embedding-service--high-performance-caching)
   - [3.4 ChromaDB Vector Vault & Multi-Document Isolation](#34-chromadb-vector-vault--multi-document-isolation)
   - [3.5 Semantic Retrieval & XML Context Assembly](#35-semantic-retrieval--xml-context-assembly)
   - [3.6 Grounded Generation Engine & Streaming Protocol](#36-grounded-generation-engine--streaming-protocol)
   - [3.7 Study Suite & Practice Quiz Engine](#37-study-suite--practice-quiz-engine)
   - [3.8 Verifiable Citation & Anti-Hallucination Guardrails](#38-verifiable-citation--anti-hallucination-guardrails)
   - [3.9 Security Hardening & Distributed Observability](#39-security-hardening--distributed-observability)
   - [3.10 Modern Frontend Studio UI](#310-modern-frontend-studio-ui)
4. [Cross-Cutting Concerns & Security Model](#4-cross-cutting-concerns--security-model)
5. [Storage & State Persistence Topologies](#5-storage--state-persistence-topologies)

---

## 1. Architectural Philosophy & Principles

VELTRIX SourceMind is engineered around five non-negotiable architectural tenets:

1. **Zero-Tolerance Hallucination Policy (Grounding Over Creativity)**:
   LLMs are trained to predict the next plausible token, often prioritizing linguistic fluency over truth. SourceMind constrains the model's knowledge universe strictly to the ingested sources. If information is absent from retrieved context chunks, the model must explicitly declare that the answer cannot be found in the provided sources.

2. **Every Statement Must Be Accountable (Verifiable Citations)**:
   A response without citations is treated as unverified. Every claim must carry a bracketed citation (`[Doc: page N]`) pointing back to the specific source document and page number. A post-generation verification guardrail inspects cited content against the ground truth chunks.

3. **Defense-in-Depth Against Untrusted Documents**:
   Uploaded PDFs and text documents are untrusted user input. SourceMind prevents path traversal, detects disguised executable binaries via magic byte sniffing, sanitizes prompt injection commands inside document chunks, and isolates document context inside structured XML envelopes.

4. **Deterministic Reproducibility & Testability**:
   The entire system is architected around interface contracts and dependency injection. Heavy cloud dependencies (Gemini embeddings, LLM generation) can be cleanly swapped with deterministic offline mocks and evaluation harnesses, enabling 100% automated regression testing without cloud costs.

5. **Sub-Second Streaming & Observability**:
   End-to-end distributed request tracing (`X-Request-ID`) and millisecond execution metrics (`X-Process-Time-Ms`) ensure complete visibility into retrieval latency, inference duration, and client quotas.

---

## 2. End-to-End System Data Flow

The diagram below traces the end-to-end lifecycle of documents and queries through the system:

```mermaid
sequenceDiagram
    autonumber
    actor User as Researcher
    participant Middleware as Middleware & Rate Limiter
    participant API as FastAPI Gateway
    participant Ingestion as Ingestion & Parsers
    participant Chunker as Recursive Chunker
    participant Embedder as Embedding Service
    participant Chroma as ChromaDB Vault
    participant Retriever as Semantic Retriever
    participant Assembler as Context Assembler
    participant LLM as Gemini 2.0 Flash
    participant Verifier as Citation Verifier

    %% Document Ingestion Flow
    rect rgb(240, 248, 255)
    Note over User, Chroma: Ingestion & Vector Indexing Phase
    User->>Middleware: Upload Document (PDF/TXT/MD)
    Middleware->>API: Validated Request
    API->>Ingestion: Parse file stream
    Ingestion->>Ingestion: Verify magic bytes & sanitize filename
    Ingestion->>Chunker: Extracted pages with page numbers
    Chunker->>Chunker: Split into paragraphs & chunks with overlap
    Chunker->>Embedder: Batched chunk text strings
    Embedder->>Embedder: Check SHA-256 embedding cache
    Embedder-->>Embedder: Compute 768d vectors (Google text-embedding-004)
    Embedder->>Chroma: Insert vectors + chunk text + metadata
    Chroma-->>API: Chunks indexed confirmation
    API-->>User: Document ingested successfully (Page count, chunk count)
    end

    %% Query & Generation Flow
    rect rgb(255, 248, 240)
    Note over User, Verifier: Retrieval & Grounded Generation Phase
    User->>Middleware: Submit Query (e.g., "Explain virtual memory paging")
    Middleware->>Middleware: Enforce sliding-window rate limit (IP quota)
    Middleware->>API: Attach X-Request-ID & trace header
    API->>Retriever: Retrieve relevant chunks
    Retriever->>Embedder: Embed search query
    Retriever->>Chroma: Query top-K vectors (Cosine Similarity >= 0.65)
    Chroma-->>Retriever: Relevant vector search results
    Retriever->>Assembler: Filtered chunks
    Assembler->>Assembler: Sanitize prompt injection & XML format context
    Assembler->>LLM: Grounded system prompt + XML context + user query
    LLM-->>API: Stream generated tokens (SSE)
    API-->>User: Live streamed tokens
    LLM-->>Verifier: Complete response text + retrieved chunks
    Verifier->>Verifier: Extract bracketed citations & verify page bounds and n-grams
    Verifier-->>User: Citation verification report (Audit status, ground truth matches)
    end
```

---

## 3. Subsystem Deep Dives

### 3.1 Ingestion & Document Validation
- **Module**: [`backend/ingestion/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/ingestion/)
- **Security Validation**:
  - `sanitize_filename()` strips relative path traversal sequences (`../../secret.txt`), special characters, and null bytes.
  - `detect_file_signature()` inspects binary magic bytes (`%PDF-` for PDFs, ASCII/UTF-8 decode checks for text) to prevent renamed malware or executable binaries from being processed.
  - Max file size enforcement (`MAX_FILE_SIZE_BYTES = 25 MB`).
- **Parsers**:
  - `PDFParser`: Page-by-page extraction via `pypdf.PdfReader`. Detects scanned blank pages (< 20 characters) and raises `ScannedDocumentError`.
  - `TextParser`: Supports UTF-8 with automatic fallback to Latin-1 encoding.
- **Cleaners**:
  - `TextCleaner`: Normalizes CRLF/CR to `\n`, collapses redundant whitespace, strips non-printable ASCII control characters (`0x00–0x1F`), and applies Unicode NFKC normalization.

---

### 3.2 Recursive Semantic Chunking & Page Tracking
- **Module**: [`backend/ingestion/chunkers.py`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/ingestion/chunkers.py)
- **Design**:
  - Unlike naive fixed-character chunkers that sever sentences mid-word, `RecursiveSemanticChunker` uses a hierarchy of separators:
    $$\text{Separators} = [\text{"\n\n"}, \text{"\n"}, \text{". "}, \text{"? "}, \text{"! "}, \text{" "}]$$
  - Preserves natural paragraph boundaries and complete semantic units.
  - Default parameters: `chunk_size = 1000` characters, `chunk_overlap = 150` characters.
  - Multi-page text tracking: when a single page exceeds `chunk_size`, it is partitioned while preserving the exact originating `page_number` in every chunk's metadata.

---

### 3.3 Embedding Service & High-Performance Caching
- **Module**: [`backend/embeddings/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/embeddings/)
- **Embedding Provider**:
  - Google `text-embedding-004` generating 768-dimensional normalized semantic vectors.
  - Configured with exponential backoff retry loops for rate-limit protection (`429 Quota Exceeded`).
- **In-Memory LRU/TTL Cache**:
  - Computes a SHA-256 fingerprint of the trimmed text string:
    $$\text{Cache Key} = \text{SHA256}(\text{chunk\_text})$$
  - Skips redundant API calls when identical text chunks are re-ingested or re-queried, achieving 0ms latency on repeated lookups.

---

### 3.4 ChromaDB Vector Vault & Multi-Document Isolation
- **Module**: [`backend/vectorstore/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/vectorstore/)
- **Storage Backend**: ChromaDB with persistent DuckDB/SQLite metadata storage and HNSW vector index.
- **Isolation & Filtering**:
  - Documents are partitioned by `document_id`.
  - Queries can filter by specific document or search across the entire knowledge vault.
  - Chroma distances (squared L2 or cosine distance) are converted into normalized cosine similarity:
    $$\text{Similarity} = 1.0 - \frac{\text{Distance}}{2.0}$$
  - Enforces strict similarity thresholding (`SIMILARITY_THRESHOLD = 0.65`). Chunks below 65% cosine similarity are discarded as irrelevance noise.

---

### 3.5 Semantic Retrieval & XML Context Assembly
- **Module**: [`backend/retrieval/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/retrieval/)
- **Context Assembler**:
  - Packages retrieved chunks into an unambiguous, prompt-ready XML structure:
    ```xml
    <source_context>
      <chunk id="chk_4f8a" document="systems_notes.pdf" page="4" similarity="0.92">
        A Translation Lookaside Buffer (TLB) caches virtual-to-physical address mappings...
      </chunk>
    </source_context>
    ```
  - **Token Budgeting**: Caps injected characters at 16,000 (~4,000 tokens) to prevent context buffer overflow and maximize attention fidelity.
  - **Tag Escaping**: Escapes closing XML tags (`</source_context>` $\rightarrow$ `&lt;/source_context&gt;`) inside chunk bodies to prevent prompt breakouts.

---

### 3.6 Grounded Generation Engine & Streaming Protocol
- **Module**: [`backend/generation/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/generation/)
- **LLM Configuration**:
  - Foundation Model: `gemini-2.0-flash`.
  - Temperature: $0.1$ (ensuring strict determinism and grounding adherence).
- **Grounded Prompting**:
  - Instructs the model that it is a rigorous research analyst whose sole source of truth is `<source_context>`.
  - Mandates explicit bracketed citations: `[DocName: page N]`.
  - Forbids external assumptions. If the answer is not contained in `<source_context>`, the model must output the canonical refusal string:
    > *"I cannot find information about this topic in the provided source documents."*
- **Streaming Delivery**:
  - FastAPI Server-Sent Events (SSE) streaming (`POST /api/chat/stream`) yielding `data: {"token": "..."}\n\n` chunks in real-time.

---

### 3.7 Study Suite & Practice Quiz Engine
- **Module**: [`backend/services/study_service.py`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/services/study_service.py) & [`backend/services/quiz_service.py`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/services/quiz_service.py)
- **Study Artifacts**:
  - **Executive Summaries**: Dynamically sized (Short: ~150 words, Medium: ~350 words, Detailed: ~800 words) with structured sections: Core Subject, Key Findings, Critical Implications.
  - **Smart Notes**: Topic categorization, Key Concept glossaries, and bulleted takeaways.
  - **Revision Sheets**: High-yield rapid recall bullets, formulas, and memory anchors.
- **Interactive Quiz Engine**:
  - Synthesizes 4-option multiple choice questions (MCQs) grounded exclusively in ingested source chunks.
  - Automated grading endpoint (`POST /api/quiz/evaluate`) evaluates user answers, computes score percentages, and provides detailed rationale and citation references for every question.

---

### 3.8 Verifiable Citation & Anti-Hallucination Guardrails
- **Module**: [`backend/generation/citation_verifier.py`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/generation/citation_verifier.py)
- **Multi-Tier Verification Algorithm**:
  1. **Citation Extraction**: Parses regex patterns matching `\[(.*?),?\s*(?:page|p\.)\s*(\d+)\]`.
  2. **Page Existence Check**: Confirms that cited page number actually exists within the ingested document metadata.
  3. **Content Grounding Verification**: Evaluates whether the claims in the cited sentence share high lexical overlap or n-gram co-occurrence with the actual chunk text originating from that page.
  4. **Verification Report**: Emits structured status (`VERIFIED`, `PAGE_OUT_OF_BOUNDS`, `CONTENT_MISMATCH`) and grounding fidelity score (0.0 to 1.0).

---

### 3.9 Security Hardening & Distributed Observability
- **Module**: [`backend/core/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/backend/core/)
- **Indirect Prompt Injection Quarantine**:
  - Neutralizes common LLM jailbreak attempts (`SYSTEM OVERRIDE:`, `IGNORE ALL INSTRUCTIONS`, `YOU ARE NOW AN UNRESTRICTED AI`) into inert `[ADVERSARIAL_INSTRUCTION_NEUTRALIZED]` labels.
- **Canary Token Sentinel**:
  - Scans model responses for high-entropy secret canary strings to detect prompt exfiltration attempts.
- **Sliding-Window Rate Limiter**:
  - In-memory thread-safe rate limiter tracking per-IP call timestamps over 60-second sliding windows.
  - Emits standard `X-RateLimit-Limit`, `X-RateLimit-Remaining`, and RFC `Retry-After` headers.
- **Distributed Request Tracing**:
  - `RequestTracingMiddleware` assigns or reflects a unique `X-Request-ID` across every HTTP request and records execution latency in `X-Process-Time-Ms`.

---

### 3.10 Modern Frontend Studio UI
- **Module**: [`frontend/`](file:///c:/Users/win/Desktop/UTKARSH/Veltrix_Source_Mind/SourceMind/frontend/)
- **Design**:
  - Built with clean semantic HTML5, modern CSS3 variables, and vanilla ES6+ JavaScript.
  - Zero heavy frontend build chains (no npm, no Webpack).
  - Responsive 3-pane layout: Document Sources Vault (Left), Grounded Chat Stream (Center), and Interactive Study/Quiz Workspace (Right).

---

## 4. Cross-Cutting Concerns & Security Model

```
                    ┌──────────────────────────────────────────────┐
                    │            Client Request Envelope           │
                    └──────────────────────┬───────────────────────┘
                                           │
                                           ▼
                    ┌──────────────────────────────────────────────┐
                    │      RateLimitMiddleware (IP Quota)          │
                    └──────────────────────┬───────────────────────┘
                                           │
                                           ▼
                    ┌──────────────────────────────────────────────┐
                    │     RequestTracingMiddleware (X-Request-ID)  │
                    └──────────────────────┬───────────────────────┘
                                           │
                                           ▼
                    ┌──────────────────────────────────────────────┐
                    │      Global Safe Exception Interceptor       │
                    └──────────────────────┬───────────────────────┘
                                           │
                     ┌─────────────────────┴─────────────────────┐
                     ▼                                           ▼
        ┌─────────────────────────┐                 ┌─────────────────────────┐
        │   Input Path Validation │                 │ Prompt Injection Escape │
        │  & Magic Byte Sniffing  │                 │    & XML Sanitization   │
        └─────────────────────────┘                 └─────────────────────────┘
```

---

## 5. Storage & State Persistence Topologies

VELTRIX SourceMind is architected to decouple compute from storage:

1. **Unstructured File Storage** (`data/uploads/`):
   Uploaded raw files are saved locally using SHA-256 deduplication. In Docker deployments, this is mounted as a named volume (`sourcemind_uploads_data`).

2. **Vector Index & Metadata Storage** (`data/chromadb/`):
   ChromaDB maintains its embedded SQLite metadata database and HNSW graph index on disk. Mounted in Docker as `sourcemind_chromadb_data`.

3. **Stateless API Gateway**:
   The FastAPI application process maintains no sticky session state. All conversation context is supplied per query or stored client-side in the Studio UI, allowing the container to scale horizontally behind a load balancer.
